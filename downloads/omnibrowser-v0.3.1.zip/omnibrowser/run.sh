#!/usr/bin/env bash
# run.sh
cd "$(dirname "$0")" && uv run poe dev
