"""AI(가짜 제공자로 네트워크 없이)와 크롤러(로컬 테스트 사이트) 테스트"""
import http.server
import threading
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

H = {"X-Omni-Token": "test-token"}


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("OMNI_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("OMNI_CORE_TOKEN", "test-token")
    monkeypatch.setenv("OMNI_ALLOW_MOCK_AI", "true")
    from omni_core.config import get_settings

    get_settings.cache_clear()
    from omni_core.main import create_app

    with TestClient(create_app(), base_url="http://127.0.0.1") as c:
        yield c


# ───────── AI ─────────
def test_ai_providers_and_presets(client):
    names = [p["name"] for p in client.get("/ai/providers", headers=H).json()]
    assert names[:3] == ["openai", "anthropic", "gemini"] and "mock" in names
    ids = [p["id"] for p in client.get("/ai/presets", headers=H).json()]
    assert {"summarize", "translate", "organize"} <= set(ids)


def test_ai_key_missing_is_friendly(client, monkeypatch):
    from omni_core.services.ai import providers

    monkeypatch.setattr(providers, "get_secret", lambda name: None)
    r = client.post("/ai/stream", headers=H, json={"provider": "gemini", "preset": "summarize", "input": "안녕"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "AI_KEY_MISSING"


def test_ai_stream_mock(client):
    r = client.post("/ai/stream", headers=H, json={"provider": "mock", "preset": "summarize", "input": "브라우저 설계서 본문"})
    assert r.status_code == 200 and r.text.startswith("[mock 응답]") and "브라우저 설계서 본문" in r.text


def test_ai_question_needs_text(client):
    r = client.post("/ai/stream", headers=H, json={"provider": "mock"})
    assert r.json()["error"]["code"] == "AI_NO_INPUT"


def test_ai_translate_segments_mock(client):
    segs = [{"id": 1, "text": "Hello world"}, {"id": 2, "text": "Second\nline"}]
    r = client.post("/ai/translate-segments", headers=H, json={"provider": "mock", "segments": segs}).json()
    assert r["translations"] == {"1": "[번역] Hello world", "2": "[번역] Second line"} and r["missing"] == []


def test_ai_monthly_limit(client):
    client.put("/settings/ai.monthly_char_limit", headers=H, json={"value": 10})
    r = client.post("/ai/stream", headers=H, json={"provider": "mock", "preset": "summarize", "input": "긴 글" * 50})
    assert r.status_code == 429 and r.json()["error"]["code"] == "AI_MONTHLY_LIMIT"


# ───────── 크롤러 ─────────
SITE = {
    "robots.txt": "User-agent: *\nDisallow: /docs/secret/\n",
    "docs/index.html": """<html><head><title>자료실</title></head><body><main><h1>자료실 안내</h1>
        <p>방사선 안전 관리 자료를 모아 둔 페이지입니다. 아래 링크에서 문서를 내려받을 수 있습니다.</p>
        <a href="a.html">하위 A</a> <a href="sub/b.html">하위 B</a> <a href="/other/c.html">범위 밖</a>
        <a href="secret/x.html">비공개</a>
        <a href="files/report.pdf">보고서 PDF</a> <a href="files/%ED%95%9C%EA%B8%80.hwp">한글 문서</a>
        <img src="files/pic.png"></main></body></html>""",
    "docs/a.html": "<html><head><title>페이지 A</title></head><body><article><h1>A 제목</h1><p>A 페이지의 본문입니다. 충분히 긴 문장을 넣어 본문 추출이 되도록 합니다.</p><a href='files/table.xlsx'>표</a></article></body></html>",
    "docs/sub/b.html": "<html><head><title>페이지 B</title></head><body><p>B 본문 내용입니다. 이것도 본문으로 추출되어야 합니다.</p></body></html>",
    "docs/secret/x.html": "<html><body>secret</body></html>",
    "other/c.html": "<html><body>out of scope</body></html>",
    "docs/files/report.pdf": "%PDF-1.4 fake",
    "docs/files/한글.hwp": "HWP fake",
    "docs/files/table.xlsx": "XLSX fake",
    "docs/files/pic.png": "PNG fake",
}


@pytest.fixture(scope="module")
def site(tmp_path_factory):
    root = tmp_path_factory.mktemp("site")
    for rel, content in SITE.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=str(root), **kw)

        def log_message(self, *a):
            pass

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()


def _wait(client, job_id, states=("done", "scanned", "error", "cancelled")):
    for _ in range(100):
        s = client.get(f"/crawl/{job_id}", headers=H, params={"files": True}).json()
        if s["state"] in states:
            return s
        time.sleep(0.1)
    raise AssertionError(s)


def test_crawl_subpath_run(client, site, tmp_path):
    body = {"start_url": f"{site}/docs/index.html", "scope": "subpath", "max_depth": 2, "delay_ms": 0,
            "page_formats": ["md", "html", "merged"], "file_types": ["pdf", "hwp", "excel"],
            "output_dir": str(tmp_path / "out"), "make_zip": True}
    job = client.post("/crawl/start", headers=H, json=body).json()
    s = _wait(client, job["id"])
    assert s["state"] == "done", s
    assert s["pages_done"] == 3  # index, a, sub/b (범위 밖·robots 금지 제외)
    done = {f["ext"]: f for f in s["files"] if f["status"] == "done"}
    assert set(done) == {"pdf", "hwp", "xlsx"}  # png는 선택하지 않음
    root = Path(s["output_dir"])
    assert (root / "_전체합본.md").read_text(encoding="utf-8").count("원본:") >= 3
    assert "A 페이지의 본문" in (root / "_전체합본.md").read_text(encoding="utf-8")
    assert any(p.name == "한글.hwp" for p in root.rglob("*.hwp"))  # 한글 파일 이름 유지
    assert (root / "_목록_files.csv").exists() and Path(s["zip_path"]).exists()
    assert any("robots.txt 금지" in e for e in s["errors"])


def test_crawl_scan_then_select(client, site, tmp_path):
    body = {"start_url": f"{site}/docs/index.html", "scope": "page", "mode": "scan", "delay_ms": 0,
            "page_formats": [], "file_types": ["pdf", "hwp", "image"], "output_dir": str(tmp_path / "out2")}
    s = _wait(client, client.post("/crawl/start", headers=H, json=body).json()["id"])
    assert s["state"] == "scanned" and {f["ext"] for f in s["files"]} == {"pdf", "hwp", "png"}
    assert all(f["status"] == "found" for f in s["files"])  # 스캔은 받지 않음
    pdf = next(f["url"] for f in s["files"] if f["ext"] == "pdf")
    client.post(f"/crawl/{s['id']}/download", headers=H, json={"urls": [pdf]})
    s = _wait(client, s["id"], states=("done", "error"))
    assert [f["ext"] for f in s["files"] if f["status"] == "done"] == ["pdf"]


def test_crawl_rejects_non_http(client, tmp_path):
    r = client.post("/crawl/start", headers=H, json={"start_url": "file:///etc/passwd", "output_dir": str(tmp_path)})
    assert r.status_code == 422


def test_to_markdown_and_notes(client):
    html = "<html><head><title>T</title></head><body><article><h1>제목</h1><p>본문 문단입니다. 충분히 긴 본문 문장을 여기에 적습니다.</p></article></body></html>"
    md = client.post("/crawl/to-markdown", headers=H, json={"html": html}).json()["markdown"]
    assert "본문 문단" in md
    client.post("/notes", headers=H, json={"url": "https://e.com", "body": "AI 요약 결과", "title": "예제"})
    assert client.get("/notes", headers=H, params={"url": "https://e.com"}).json()[0]["body"] == "AI 요약 결과"
    assert "AI 요약 결과" in client.get("/notes/export", headers=H).text


def test_safe_name_and_disposition():
    from omni_core.services.crawler.engine import filename_from_disposition, safe_name

    assert safe_name("CON.txt") == "_CON.txt" and safe_name('a:b*?.pdf') == "a_b__.pdf"
    assert filename_from_disposition("attachment; filename*=UTF-8''%ED%95%9C%EA%B8%80.pdf") == "한글.pdf"
    raw = "보고서.hwp".encode("cp949").decode("latin-1")  # EUC-KR로 보내는 국내 서버 흉내
    assert filename_from_disposition(f'attachment; filename="{raw}"') == "보고서.hwp"


def test_crawl_via_browser_proxy(client, site, tmp_path):
    """브라우저 경유 모드: Main의 가져오기 서비스를 흉내 낸 프록시를 거쳐도 같은 결과"""
    import urllib.parse
    import urllib.request

    seen: list[str] = []

    class Proxy(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if self.headers.get("X-Omni-Token") != "tok":
                self.send_response(401)
                self.end_headers()
                return
            assert q["p"] == ["persist:ws-x"]  # 워크스페이스 정보 유지
            seen.append(q["url"][0])
            try:
                with urllib.request.urlopen(q["url"][0]) as r:
                    body, status, ctype, final = r.read(), r.status, r.headers.get("content-type", ""), r.url
            except urllib.error.HTTPError as e:
                body, status, ctype, final = b"", e.code, "text/plain", q["url"][0]
            self.send_response(status)
            self.send_header("content-type", ctype)
            self.send_header("x-final-url", final)
            self.end_headers()
            self.wfile.write(body)

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Proxy)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    via = f"http://127.0.0.1:{srv.server_address[1]}/fetch?p=persist%3Aws-x"
    body = {"start_url": f"{site}/docs/index.html", "scope": "subpath", "delay_ms": 0, "page_formats": ["md"],
            "file_types": ["pdf"], "output_dir": str(tmp_path / "o3"), "fetch_via": via, "fetch_token": "tok"}
    s = _wait(client, client.post("/crawl/start", headers=H, json=body).json()["id"])
    srv.shutdown()
    assert s["state"] == "done" and s["pages_done"] == 3
    assert [f["ext"] for f in s["files"] if f["status"] == "done"] == ["pdf"]
    assert any(u.endswith("robots.txt") for u in seen) and any(u.endswith(".pdf") for u in seen)


def test_tts_providers_voices_and_local_dir(client, tmp_path):
    names = [p["name"] for p in client.get("/tts/providers", headers=H).json()]
    assert names == ["supertonic", "openai", "gemini"]
    assert "Kore" in client.get("/tts/voices", headers=H, params={"provider": "gemini"}).json()
    st = client.get("/tts/local/status", headers=H, params={"dir": str(tmp_path / "none")}).json()
    assert st["installed"] is False and st["dir"].endswith("none")
    # onnx 하위 폴더를 골라도 모델 루트로 인식
    onnx = tmp_path / "m" / "onnx"
    onnx.mkdir(parents=True)
    (onnx / "tts.json").write_text("{}")
    st = client.get("/tts/local/status", headers=H, params={"dir": str(onnx)}).json()
    assert st["dir"] == str(tmp_path / "m")


def test_gemini_tts_wav(client, monkeypatch, tmp_path):
    import base64
    import wave

    from omni_core.services.tts import gemini_tts

    pcm = b"\x00\x01" * 2400

    class FakeResp:
        status_code = 200

        def json(self):
            return {"candidates": [{"content": {"parts": [{"inlineData": {
                "mimeType": "audio/L16;codec=pcm;rate=24000", "data": base64.b64encode(pcm).decode()}}]}}]}

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

        async def post(self, url, headers, json):
            assert json["generationConfig"]["responseModalities"] == ["AUDIO"]
            assert json["generationConfig"]["speechConfig"]["voiceConfig"]["prebuiltVoiceConfig"]["voiceName"] == "Puck"
            return FakeResp()

    monkeypatch.setattr(gemini_tts, "get_secret", lambda n: "k")
    monkeypatch.setattr(gemini_tts.httpx, "AsyncClient", FakeClient)
    r = client.post("/tts/synthesize", headers=H, json={"provider": "gemini", "voice": "Puck", "text": "안녕하세요"})
    assert r.status_code == 200 and r.headers["content-type"] == "audio/wav"
    out = tmp_path / "a.wav"
    out.write_bytes(r.content)
    with wave.open(str(out)) as w:
        assert w.getframerate() == 24000 and w.getnframes() == 2400


def test_model_recommend():
    from omni_core.services.ai.providers import recommend

    ms = [{"id": i, "name": i, "created": 0} for i in
          ["gemini-3.6-flash", "gemini-3.8-flash", "gemini-3.8-flash-lite", "gemini-4.0-flash-preview", "gemini-3.1-pro-preview"]]
    assert recommend("gemini", ms) == "gemini-3.8-flash"
    ms = [{"id": "gpt-5.4-mini", "name": "", "created": 1}, {"id": "gpt-5.6-mini", "name": "", "created": 2},
          {"id": "gpt-6", "name": "", "created": 3}]
    assert recommend("openai", ms) == "gpt-5.6-mini"


def test_models_cache_and_auto_latest(client, monkeypatch):
    from omni_core.routers import ai

    async def fake_list(provider, kind="chat"):
        return [{"id": "gemini-9.0-flash", "name": "G9", "created": 0}]

    monkeypatch.setattr(ai, "list_models", fake_list)
    d = client.get("/ai/models", headers=H, params={"provider": "gemini", "refresh": True}).json()
    assert d["recommended"] == "gemini-9.0-flash" and d["default"] == "gemini-3.6-flash"
    assert "cache.models.chat.gemini" not in client.get("/settings", headers=H).json()  # 설정 화면엔 안 보임
    # 기본 모델이 목록에 없으면(단종) 추천 최신 모델로 자동 대체
    assert ai._resolve("gemini", None) == ("gemini", "gemini-9.0-flash")


def test_local_model_own_folder_copies_from_shared(client, tmp_path, monkeypatch):
    """다른 Supertonic 앱과 공용 폴더를 함께 쓰지 않는다: 전용 폴더가 기본, 공용 폴더의 모델은 복사만"""
    from supertonic.loader import get_all_onnx_module_relative_paths

    from omni_core.services.tts import supertonic_local as local

    shared = tmp_path / "shared" / "supertonic3"
    for rel in get_all_onnx_module_relative_paths():
        (shared / rel).parent.mkdir(parents=True, exist_ok=True)
        (shared / rel).write_bytes(b"x")
    (shared / "voice_styles").mkdir()
    (shared / "voice_styles" / "F1.json").write_text("{}")
    monkeypatch.setattr(local, "shared_dir", lambda model: shared)
    st = client.get("/tts/local/status", headers=H).json()
    assert st["dir"].endswith(str(local.Path("models") / "supertonic-3")) and st["shared_installed"] is True
    assert st["installed"] is False
    model, d = local.resolve()
    assert local.ensure_model(model, d, auto_download=False) == "copied"
    assert local.ensure_model(model, d, auto_download=False) == "ready"
    st = client.get("/tts/local/status", headers=H).json()
    assert st["installed"] is True and st["voices"] == ["F1"]
    before = sorted(p.name for p in shared.rglob("*"))
    assert before == sorted(p.name for p in shared.rglob("*"))  # 공용 폴더는 그대로
