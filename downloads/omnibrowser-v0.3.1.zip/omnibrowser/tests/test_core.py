import pytest
from fastapi.testclient import TestClient

H = {"X-Omni-Token": "test-token"}


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("OMNI_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("OMNI_CORE_TOKEN", "test-token")
    from omni_core.config import get_settings
    get_settings.cache_clear()                              # 테스트마다 새 설정
    from omni_core.main import create_app
    # base_url을 127.0.0.1로: 기본값(testserver)은 TrustedHostMiddleware에서 거부됨
    with TestClient(create_app(), base_url="http://127.0.0.1") as c:
        yield c


def test_health(client):
    assert client.get("/health").json()["status"] == "ok"


def test_token_required(client):
    assert client.get("/history").status_code == 401


def test_history_korean_search(client):
    r = client.post("/history", headers=H,
                    json={"url": "https://example.com/a", "title": "브라우저 설계 기초"})
    assert r.status_code == 200
    hits = client.get("/history", params={"q": "브라우저"}, headers=H).json()
    assert hits and hits[0]["title"] == "브라우저 설계 기초"


def test_error_format(client):
    r = client.post("/tts/synthesize", headers=H, json={"provider": "nope", "text": "안녕"})
    assert r.status_code == 400
    assert r.json()["error"]["code"] == "TTS_UNKNOWN_PROVIDER"   # 무엇이/왜/어떻게 형식


def test_cloud_tts_without_key(client, monkeypatch):
    from omni_core.services.tts import openai_tts
    monkeypatch.setattr(openai_tts, "get_secret", lambda name: None)   # "키 없음" 상황 재현
    r = client.post("/tts/synthesize", headers=H, json={"provider": "openai", "text": "안녕"})
    assert r.json()["error"]["code"] == "OPENAI_KEY_MISSING"


def test_settings_defaults_and_update(client):
    assert client.get("/settings", headers=H).json()["tts.provider"] == "supertonic"
    client.put("/settings/tts.rate", headers=H, json={"value": 1.3})
    assert client.get("/settings", headers=H).json()["tts.rate"] == 1.3


def test_site_settings_rate_memory(client):
    origin = "https://www.example.com"
    client.put("/site-settings", headers=H, json={"origin": origin, "key": "media.rate", "value": 1.75})
    client.put("/site-settings", headers=H, json={"origin": origin, "key": "media.rate", "value": 2.0})
    assert client.get("/site-settings", params={"origin": origin}, headers=H).json() == {"media.rate": 2.0}
    assert len(client.get("/site-settings/all", headers=H).json()) == 1   # 덮어쓰기 (중복 없음)


def test_bookmarks_crud(client):
    r = client.post("/bookmarks", headers=H, json={"title": "예제", "url": "https://example.com"})
    bid = r.json()["id"]
    again = client.post("/bookmarks", headers=H, json={"title": "예제", "url": "https://example.com"})
    assert again.json() == {"id": bid, "created": False}                   # 같은 주소는 한 번만
    assert client.delete(f"/bookmarks/{bid}", headers=H).status_code == 200
    assert client.get("/bookmarks", headers=H).json() == []


def test_session_roundtrip(client):
    assert client.get("/sessions/latest", headers=H).json() is None
    payload = {"activeWorkspace": "default", "tabs": [{"url": "https://example.com", "workspaceId": "default"}]}
    client.put("/sessions/latest", headers=H, json={"reason": "quit", "payload": payload})
    assert client.get("/sessions/latest", headers=H).json()["payload"] == payload


def test_workspaces(client):
    assert [w["id"] for w in client.get("/workspaces", headers=H).json()] == ["default"]
    w = client.post("/workspaces", headers=H, json={"name": "공부", "color": "#16a34a"}).json()
    assert w["partition"] == f"persist:ws-{w['id']}"
    assert client.delete("/workspaces/default", headers=H).json()["error"]["code"] == "WS_DEFAULT_LOCKED"


def test_tts_split_korean():
    from omni_core.services.tts.splitter import split_sentences
    s = split_sentences("안녕하세요. 브라우저 설계서입니다!\n\n두 번째 문단이에요? 네.")
    assert s == ["안녕하세요.", "브라우저 설계서입니다!", "두 번째 문단이에요?", "네."]
    long = split_sentences("가" * 700)
    assert all(len(x) <= 300 for x in long) and "".join(long) == "가" * 700


def test_history_delete(client):
    client.post("/history", headers=H, json={"url": "https://a.com", "title": "a"})
    assert client.delete("/history", headers=H).json()["deleted"] == 1
