@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title OmniBrowser 개발 환경 설치

echo ============================================
echo   OmniBrowser 개발 환경 설치 (uv 기반)
echo ============================================

rem [1/5] uv 확인 및 설치
where uv >nul 2>nul
if errorlevel 1 (
  echo [1/5] uv가 없어 설치합니다...
  powershell -NoProfile -ExecutionPolicy Bypass -c "irm https://astral.sh/uv/install.ps1 | iex"
  set "PATH=%USERPROFILE%\.local\bin;%PATH%"
) else (
  echo [1/5] uv 확인 완료
)
uv --version || goto :fail

rem [2/5] Python 3.12 + 패키지 + Node.js(nodejs-wheel) 설치
echo [2/5] Python 패키지 설치 중... (처음에는 몇 분 걸릴 수 있습니다)
uv sync --extra tts-local --extra ai || goto :fail

rem [3/5] 환경 변수 파일 준비
if not exist ".env" copy ".env.example" ".env" >nul
echo [3/5] .env 준비 완료

rem [4/5] Electron UI 패키지 설치
echo [4/5] Electron UI 패키지 설치 중...
uv run poe setup-ui || goto :fail

rem [5/5] 환경 점검
echo [5/5] 환경 점검...
uv run poe doctor
echo.
echo  로컬 TTS(Supertonic 3) 모델을 미리 받으려면:  uv run poe fetch-models
echo  설치 완료! run.bat 을 실행하세요.
pause
exit /b 0

:fail
echo.
echo [오류] 설치가 중단되었습니다. 위 메시지와 설계서 15장(FAQ)을 확인하세요.
pause
exit /b 1
