"""❌ 항목에는 해결 방법(→)이 함께 출력된다."""
import importlib.util
import os
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
result = {"ok": 0, "fail": 0}


def check(name: str, passed: bool, hint: str = "", optional: bool = False) -> None:
    if passed:
        result["ok"] += 1
        print(f"  ✅ {name}")
    elif optional:
        print(f"  ➖ {name} (선택 기능)  → {hint}")
    else:
        result["fail"] += 1
        print(f"  ❌ {name}\n     → {hint}")


def version_of(cmd: str) -> str | None:
    exe = shutil.which(cmd)
    if not exe:
        return None
    try:
        return subprocess.run([exe, "--version"], capture_output=True, text=True,
                              timeout=30).stdout.strip() or "?"
    except Exception:
        return None


print("OmniBrowser 개발 환경 점검\n")
check(f"Python {sys.version.split()[0]} (3.12.x 필요)", sys.version_info[:2] == (3, 12),
      "uv python install 3.12 → uv sync")
check("가상환경(.venv) 사용 중", sys.prefix != sys.base_prefix, "uv run poe doctor 로 실행하세요")
uv_v, node_v, npm_v = version_of("uv"), version_of("node"), version_of("npm")
check(f"uv ({uv_v or '없음'})", uv_v is not None, "9.2절 방법으로 설치 후 터미널 재시작")
check(f"Node.js ({node_v or '없음'})", node_v is not None, "uv sync (nodejs-wheel) 또는 Node LTS 설치")
check(f"npm ({npm_v or '없음'})", npm_v is not None, "uv sync 재실행")
check("Electron UI 패키지 (desktop/node_modules)", (ROOT / "desktop" / "node_modules").exists(),
      "uv run poe setup-ui")
check(".env 파일", (ROOT / ".env").exists(), "copy .env.example .env")

try:
    sqlite3.connect(":memory:").execute("CREATE VIRTUAL TABLE t USING fts5(x, tokenize='trigram')")
    fts_ok = True
except sqlite3.Error:
    fts_ok = False
check(f"SQLite {sqlite3.sqlite_version} FTS5·trigram", fts_ok,
      "uv python install 3.12 --reinstall 후 uv sync")

try:
    import keyring
    kr = keyring.get_keyring()
    backend = f"{type(kr).__module__}.{type(kr).__name__}"
    check(f"OS 키체인 ({backend})", "fail" not in backend,
          "Linux: gnome-keyring 설치 (개발 모드에서는 .env 폴백으로 대체 가능)", optional=True)
except Exception as e:  # 어떤 오류든 점검 결과로 표시하고 계속 진행
    check("OS 키체인", False, str(e), optional=True)

check("로컬 TTS (supertonic)", importlib.util.find_spec("supertonic") is not None,
      "uv sync --extra tts-local", optional=True)
check("AI SDK (anthropic, openai)", importlib.util.find_spec("anthropic") is not None,
      "uv sync --extra ai", optional=True)
check("로컬 OCR (easyocr)", importlib.util.find_spec("easyocr") is not None,
      "uv sync --extra ocr", optional=True)
if os.getenv("HTTPS_PROXY"):
    print(f"\n  ℹ 프록시 사용 중: {os.getenv('HTTPS_PROXY')}")

print(f"\n결과: ✅ {result['ok']}개 통과, ❌ {result['fail']}개 실패")
sys.exit(1 if result["fail"] else 0)
