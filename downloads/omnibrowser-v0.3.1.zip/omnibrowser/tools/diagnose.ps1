﻿<#
  OmniBrowser 동시 실행 진단 도구 (Windows PowerShell 5.1 이상)
  - 다른 프로그램(예: supertonic3-local-tts)과 함께 켤 때 한쪽이 꺼지는 원인을 자동으로 조사한다.
  - 사용: diagnose.bat 더블클릭 (다른 앱 폴더를 diagnose.bat 위에 끌어다 놓으면 그 앱도 비교)
  - 결과: 바탕화면 "OmniBrowser_진단_날짜.txt" (개인 정보: 사용자 폴더 경로·프로세스 명령줄 포함 → 공유 전 확인)
  - 이 도구는 아무것도 바꾸거나 종료하지 않는다 (읽기 전용).
#>
param([string]$OtherApp = "")

$ErrorActionPreference = 'Continue'
$OmniRoot = Split-Path -Parent $PSScriptRoot
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$Out = Join-Path ([Environment]::GetFolderPath('Desktop')) ("OmniBrowser_진단_" + $Stamp + ".txt")
$sb = New-Object System.Text.StringBuilder
$findings = New-Object System.Collections.ArrayList
$TemplateIconMd5 = 'a2cf889708d9c4959c6808b4584848e4'   # electron-vite 템플릿 기본 아이콘(Electron 로고)

function Line([string]$s) { [void]$sb.AppendLine($s) }
function Section([string]$s) { Line ''; Line ('=' * 72); Line ('■ ' + $s); Line ('=' * 72) }
function AddFinding([string]$level, [string]$msg, [string]$fix) {
  [void]$findings.Add([pscustomobject]@{ Level = $level; Msg = $msg; Fix = $fix })
}
function Cut([string]$s, [int]$n) { if ($null -eq $s) { return '' }; if ($s.Length -gt $n) { return $s.Substring(0, $n) + '…' }; return $s }
function Md5([string]$path) {
  try { return (Get-FileHash -Algorithm MD5 -LiteralPath $path).Hash.ToLower() } catch { return '' }
}

Write-Host '진단 중입니다… (30초 정도 걸릴 수 있습니다)' -ForegroundColor Cyan

# ───────────────── 1. 기본 정보 ─────────────────
Section '1. 기본 정보'
Line ('시각: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
try { $os = Get-CimInstance Win32_OperatingSystem; Line ('Windows: ' + $os.Caption + ' ' + $os.Version) } catch { Line 'Windows: (확인 실패)' }
Line ('OmniBrowser 폴더: ' + $OmniRoot)
Line ('PowerShell: ' + $PSVersionTable.PSVersion.ToString())

# ───────────────── 2. 실행 중인 관련 프로세스 ─────────────────
Section '2. 실행 중인 관련 프로세스 (Electron·Python·Node·uv)'
$procs = @()
try {
  $procs = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(electron|OmniBrowser|omni-core|python|pythonw|uv|node)\.exe$' })
} catch { Line ('  (확인 실패: ' + $_.Exception.Message + ')') }
if ($procs.Count -eq 0) { Line '  관련 프로세스 없음 (모든 앱이 꺼진 상태)' }
foreach ($p in $procs) {
  Line ('  PID ' + $p.ProcessId + ' (부모 ' + $p.ParentProcessId + ')  ' + $p.Name)
  Line ('      ' + (Cut $p.CommandLine 260))
}

# Electron 앱 폴더 추정: ...\<앱폴더>\node_modules\electron\dist\electron.exe
$appDirs = @{}
foreach ($p in $procs) {
  if ($p.Name -eq 'electron.exe' -and $p.CommandLine -match '"?([A-Za-z]:\\[^"]*?)\\node_modules\\electron\\dist\\electron\.exe') {
    $appDirs[$Matches[1].ToLower()] = $Matches[1]
  }
}
$omniKey = $null
foreach ($k in @($appDirs.Keys)) {
  if ($k -like ($OmniRoot.ToLower() + '*')) { $omniKey = $k }
}
$others = @($appDirs.Keys | Where-Object { $_ -ne $omniKey } | ForEach-Object { $appDirs[$_] })
if ($OtherApp -and (Test-Path -LiteralPath $OtherApp)) { $others = @($OtherApp) + $others }
$uniq = @{}
foreach ($o in $others) { if ($o -and (Test-Path -LiteralPath $o)) { $uniq[$o.TrimEnd('\').ToLower()] = $o.TrimEnd('\') } }
$others = @($uniq.Values)
Line ''
Line ('  실행 중인 OmniBrowser(개발 모드): ' + $(if ($omniKey) { '있음' } else { '없음' }))
Line ('  비교할 다른 Electron 앱 폴더: ' + $(if ($others.Count) { ($others -join ' | ') } else { '없음 (diagnose.bat 위에 그 앱 폴더를 끌어다 놓으면 비교합니다)' }))

# ───────────────── 3. 포트 ─────────────────
Section '3. 열려 있는 포트 (충돌 확인)'
$pidName = @{}
foreach ($p in $procs) { $pidName[[int]$p.ProcessId] = $p }
try {
  $listen = @(Get-NetTCPConnection -State Listen -ErrorAction Stop)
  $watch = @(5173, 5174, 5175, 7860, 8000, 8080, 8765, 47800)
  foreach ($c in $listen) {
    $own = $pidName[[int]$c.OwningProcess]
    if ($own -or ($watch -contains [int]$c.LocalPort)) {
      $desc = '(관련 없는 프로그램)'
      if ($own) { $desc = $own.Name + ' ' + (Cut $own.CommandLine 120) }
      else { try { $desc = (Get-Process -Id $c.OwningProcess -ErrorAction Stop).ProcessName } catch {} }
      Line ('  ' + $c.LocalAddress + ':' + $c.LocalPort + '  PID ' + $c.OwningProcess + '  ' + $desc)
    }
  }
  $dup = $listen | Group-Object LocalPort | Where-Object { $_.Count -gt 1 -and ($watch -contains [int]$_.Name) }
  foreach ($d in $dup) { AddFinding 'WARN' ('포트 ' + $d.Name + '을(를) 여러 프로그램이 동시에 열고 있습니다') '해당 앱 중 하나의 포트를 바꾸세요' }
} catch { Line ('  (확인 실패: ' + $_.Exception.Message + ')') }

# ───────────────── 4. 환경 변수 ─────────────────
Section '4. 영향을 주는 환경 변수'
foreach ($n in @('ELECTRON_RUN_AS_NODE', 'ELECTRON_NO_ATTACH_CONSOLE', 'NODE_OPTIONS', 'SUPERTONIC_CACHE_DIR', 'HF_HOME', 'HF_HUB_OFFLINE', 'VIRTUAL_ENV', 'UV_PROJECT_ENVIRONMENT', 'PYTHONPATH', 'PYTHONHOME')) {
  $v = [Environment]::GetEnvironmentVariable($n)
  if ($v) { Line ('  ' + $n + ' = ' + $v) }
}
if ([Environment]::GetEnvironmentVariable('ELECTRON_RUN_AS_NODE')) {
  AddFinding 'ERROR' 'ELECTRON_RUN_AS_NODE 환경 변수가 설정되어 있습니다 → Electron 앱이 창 없이 바로 꺼집니다' '시스템 속성 → 환경 변수에서 ELECTRON_RUN_AS_NODE 삭제 후 다시 로그인'
}
foreach ($n in @('PYTHONHOME', 'PYTHONPATH')) {
  if ([Environment]::GetEnvironmentVariable($n)) { AddFinding 'WARN' ($n + ' 환경 변수가 설정되어 있어 uv 가상환경의 Python이 다른 라이브러리를 읽을 수 있습니다') ($n + ' 삭제 권장') }
}

# ───────────────── 5. Supertonic 모델 폴더 ─────────────────
Section '5. Supertonic 모델 폴더 (여러 앱이 함께 쓰면 충돌 가능)'
$cache = Join-Path $env:USERPROFILE '.cache'
$own = Join-Path $env:APPDATA 'OmniBrowser\core\models'
$folders = @()
if (Test-Path $cache) { $folders += @(Get-ChildItem -LiteralPath $cache -Force -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'supertonic' }) }
if (Test-Path $own) { $folders += @(Get-ChildItem -LiteralPath $own -Force -Directory -ErrorAction SilentlyContinue) }
if ($env:SUPERTONIC_CACHE_DIR -and (Test-Path $env:SUPERTONIC_CACHE_DIR)) { $folders += @(Get-Item -LiteralPath $env:SUPERTONIC_CACHE_DIR) }
if ($folders.Count -eq 0) { Line '  Supertonic 모델 폴더 없음' }
foreach ($f in $folders) {
  $files = @(Get-ChildItem -LiteralPath $f.FullName -Recurse -File -Force -ErrorAction SilentlyContinue)
  $mb = [math]::Round((($files | Measure-Object Length -Sum).Sum) / 1MB, 1)
  $onnx = @($files | Where-Object { $_.Extension -eq '.onnx' })
  Line ('  ' + $f.FullName + '  (' + $files.Count + '개 파일, ' + $mb + 'MB, onnx ' + $onnx.Count + '개)')
  if ($f.Name -match '^\..*\.(tmp|copying)$') {
    AddFinding 'WARN' ('모델 다운로드/복사 임시 폴더가 남아 있습니다: ' + $f.FullName) '두 앱을 모두 끈 뒤 이 폴더를 삭제하세요 (다운로드가 중간에 끊겼거나 두 앱이 동시에 받으려 한 흔적)'
  }
  foreach ($o in $onnx) {
    try { $s = [IO.File]::Open($o.FullName, 'Open', 'Read', 'None'); $s.Close() }
    catch { Line ('      사용 중(잠김): ' + $o.Name + '  ← 다른 프로그램이 이 모델을 열고 있음') }
  }
}
$sharedUsed = Test-Path (Join-Path $cache 'supertonic3')
if ($sharedUsed) { Line ('  ※ 공용 폴더 ' + (Join-Path $cache 'supertonic3') + ' 는 Supertonic을 쓰는 모든 앱의 기본 위치입니다.') }

# ───────────────── 6. Windows 오류 기록 (최근 2일) ─────────────────
Section '6. Windows 이벤트 로그: 프로그램 비정상 종료 기록 (최근 2일)'
try {
  $ev = @(Get-WinEvent -FilterHashtable @{ LogName = 'Application'; StartTime = (Get-Date).AddDays(-2) } -MaxEvents 3000 -ErrorAction Stop |
      Where-Object { (@(1000, 1001, 1002, 1026) -contains $_.Id) -and ($_.Message -match 'electron|OmniBrowser|python|node\.exe|uv\.exe|omni-core') } |
      Select-Object -First 15)
  if ($ev.Count -eq 0) { Line '  관련 기록 없음' }
  foreach ($e in $ev) {
    Line ('  [' + $e.TimeCreated.ToString('MM-dd HH:mm:ss') + '] 이벤트 ' + $e.Id + ' ' + $e.ProviderName)
    Line ('      ' + (Cut (($e.Message -replace '\s+', ' ')) 380))
  }
  if (@($ev | Where-Object { $_.Id -eq 1000 }).Count -gt 0) { AddFinding 'WARN' '최근 프로그램 충돌(이벤트 1000) 기록이 있습니다 — 6번 항목의 "오류 모듈"을 확인하세요' '이 진단 파일을 Claude에게 첨부' }
} catch { Line ('  (확인 실패: ' + $_.Exception.Message + ')') }

# ───────────────── 7. OmniBrowser 로그 ─────────────────
Section '7. OmniBrowser 로그'
$log = Join-Path $env:APPDATA 'OmniBrowser\logs\main.log'
if (Test-Path $log) {
  $lines = @(Get-Content -LiteralPath $log -Tail 4000 -Encoding UTF8 -ErrorAction SilentlyContinue)
  $hits = @($lines | Where-Object { $_ -match 'error|fail|exited|SIGTRAP|crash|이미 실행|실패|Traceback|WinError|PermissionError' } | Select-Object -Last 30)
  Line ('  최근 문제 관련 줄 ' + $hits.Count + '개:')
  foreach ($l in $hits) { Line ('    ' + (Cut $l 240)) }
  Line '  --- 마지막 40줄 ---'
  foreach ($l in @($lines | Select-Object -Last 40)) { Line ('    ' + (Cut $l 240)) }
  if (@($lines | Where-Object { $_ -match '다른 OmniBrowser가 이미 실행 중' }).Count -gt 0) {
    AddFinding 'INFO' 'OmniBrowser를 두 번 실행해 두 번째 창이 기존 창으로 합쳐진 기록이 있습니다 (정상 동작)' '작업 표시줄의 기존 OmniBrowser 창을 사용하세요'
  }
  if (@($lines | Where-Object { $_ -match 'WinError 32|PermissionError|사용 중' }).Count -gt 0) {
    AddFinding 'ERROR' '파일이 다른 프로세스에 의해 사용 중이라 실패한 기록이 있습니다 (모델 폴더 공유 충돌 가능)' 'OmniBrowser v0.3.1 이상은 전용 모델 폴더를 사용합니다. 다른 앱은 SUPERTONIC_CACHE_DIR로 분리 (안내서 참고)'
  }
} else { Line '  로그 없음 (OmniBrowser를 한 번도 실행하지 않았거나 다른 계정)' }
$crash = Join-Path $env:APPDATA 'OmniBrowser\Crashpad\reports'
if (Test-Path $crash) {
  $d = @(Get-ChildItem -LiteralPath $crash -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
  Line ('  충돌 보고서(덤프) ' + $d.Count + '개' + $(if ($d.Count) { ', 최근: ' + $d[0].LastWriteTime.ToString('MM-dd HH:mm') } else { '' }))
  if ($d.Count -gt 0 -and $d[0].LastWriteTime -gt (Get-Date).AddDays(-2)) { AddFinding 'WARN' 'OmniBrowser 자체 충돌 보고서가 최근에 생성되었습니다' '7번 항목 로그와 함께 Claude에게 첨부' }
}

# ───────────────── 8. 다른 앱과 비교 ─────────────────
Section '8. 다른 Electron 앱과 비교 (아이콘·이름·단일 실행·강제 종료 코드·고정 포트)'
$omniPkg = $null
try { $omniPkg = Get-Content -LiteralPath (Join-Path $OmniRoot 'desktop\package.json') -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
$omniIcon = Md5 (Join-Path $OmniRoot 'desktop\resources\icon.png')
foreach ($dir in $others) {
  Line ''
  Line ('  ▶ ' + $dir)
  $pkgPath = Join-Path $dir 'package.json'
  if (-not (Test-Path $pkgPath)) { $pkgPath = Join-Path $dir 'desktop\package.json' }
  $pkg = $null
  try { $pkg = Get-Content -LiteralPath $pkgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
  if ($pkg) {
    Line ('    package.json name=' + $pkg.name + '  productName=' + $pkg.productName + '  main=' + $pkg.main)
    $otherId = $(if ($pkg.productName) { $pkg.productName } else { $pkg.name })
    $omniId = $(if ($omniPkg -and $omniPkg.productName) { $omniPkg.productName } else { 'OmniBrowser' })
    if ($otherId -and ($otherId -eq $omniId)) {
      AddFinding 'ERROR' ('다른 앱의 이름(' + $otherId + ')이 OmniBrowser와 같습니다 → 데이터 폴더·단일 실행 잠금을 공유해 나중에 켠 쪽이 바로 꺼집니다') '그 앱 package.json의 name·productName을 고유한 이름으로 변경'
    }
    if (@('electron-app', 'my-app', 'electron-vite-app') -contains $pkg.name) {
      AddFinding 'WARN' ('다른 앱이 템플릿 기본 이름(' + $pkg.name + ')을 그대로 씁니다 → 같은 템플릿의 다른 앱과 데이터 폴더·단일 실행 잠금이 겹칠 수 있음') '그 앱 package.json의 name·productName 변경'
    }
  } else { Line '    package.json 없음' }
  foreach ($ico in @('resources\icon.png', 'build\icon.png', 'desktop\resources\icon.png')) {
    $ip = Join-Path $dir $ico
    if (Test-Path $ip) {
      $h = Md5 $ip
      Line ('    아이콘 ' + $ico + ' md5=' + $h)
      if ($h -eq $TemplateIconMd5) { AddFinding 'INFO' ('"같은 아이콘"의 원인: ' + (Split-Path -Leaf $dir) + ' 앱이 electron-vite 템플릿 기본 아이콘(Electron 로고)을 그대로 씁니다') '그 앱의 resources\icon.png·build\icon.ico를 고유 아이콘으로 교체 (OmniBrowser는 v0.3.1에서 교체 완료)' }
      if ($h -eq $omniIcon) { AddFinding 'INFO' '다른 앱이 OmniBrowser와 같은 아이콘 파일을 씁니다' '아이콘 교체' }
      break
    }
  }
  # 소스 검사 (node_modules·가상환경 제외, 최대 600개 파일)
  $src = @(Get-ChildItem -LiteralPath $dir -Recurse -File -Include *.bat, *.cmd, *.ps1, *.js, *.cjs, *.mjs, *.ts, *.py, *.json, *.yml -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -notmatch '\\(node_modules|\.venv|venv|out|dist|\.git|__pycache__)\\' -and $_.Length -lt 1MB } | Select-Object -First 600)
  $rules = @(
    @{ re = 'taskkill[^\r\n]*/im\s+"?(electron|python|pythonw|node|uv)\.exe'; lv = 'ERROR'; msg = '실행할 때 같은 이름의 프로그램(electron/python/node)을 모두 강제 종료하는 코드 → OmniBrowser도 같이 꺼집니다'; fix = '그 줄을 PID 기반 종료(자기 프로세스만)로 바꾸거나 삭제' },
    @{ re = 'Stop-Process[^\r\n]*-Name\s+"?(electron|python|node)'; lv = 'ERROR'; msg = '실행할 때 같은 이름의 프로세스를 모두 종료하는 PowerShell 코드'; fix = '자기 PID만 종료하도록 수정' },
    @{ re = 'kill-port|fkill|tree-kill.*(5173|8000)'; lv = 'WARN'; msg = '포트를 차지한 프로그램을 강제 종료하는 코드 (다른 앱이 같은 포트를 쓰면 그 앱이 꺼짐)'; fix = '고정 포트 대신 빈 포트 자동 선택' },
    @{ re = 'localhost:5173|127\.0\.0\.1:5173'; lv = 'WARN'; msg = '개발 서버 주소(5173)를 직접 적어 둔 코드 → 다른 electron-vite 앱이 먼저 5173을 쓰면 엉뚱한 화면을 불러와 오류'; fix = 'process.env.ELECTRON_RENDERER_URL 사용' },
    @{ re = 'strictPort\s*:\s*true'; lv = 'WARN'; msg = 'Vite strictPort: 포트가 이미 쓰이면 시작하지 못하고 종료'; fix = 'strictPort 제거 또는 다른 포트' },
    @{ re = 'from\s+supertonic\s+import|import\s+supertonic|supertonic\.TTS|TTS\(\s*auto_download'; lv = 'WARN'; msg = 'Supertonic 패키지 사용 → 기본값이면 공용 폴더(사용자\.cache\supertonic3)를 씀'; fix = '그 앱 실행 배치 파일에 set SUPERTONIC_CACHE_DIR=<전용 폴더> 추가 (안내서 참고)' }
  )
  $hit = 0
  foreach ($f in $src) {
    $text = $null
    try { $text = [IO.File]::ReadAllText($f.FullName) } catch { continue }
    foreach ($r in $rules) {
      $m = [regex]::Match($text, $r.re, 'IgnoreCase')
      if ($m.Success) {
        $line = ($text.Substring(0, $m.Index) -split "`n").Count
        Line ('    ' + $r.lv + '  ' + $f.FullName.Substring($dir.Length) + ':' + $line + '  ' + (Cut $m.Value 100))
        AddFinding $r.lv ((Split-Path -Leaf $dir) + ': ' + $r.msg + ' [' + $f.Name + ':' + $line + ']') $r.fix
        $hit++
      }
    }
    if ($f.Name -match '\.(ts|js|py)$' -and $text -match '(?i)port\s*[=:]\s*(\d{4,5})\b') { Line ('    포트 지정: ' + $f.Name + '  port=' + $Matches[1]) }
  }
  Line ('    소스 ' + $src.Count + '개 검사, 문제 후보 ' + $hit + '건')
}

# ───────────────── 결과 저장 ─────────────────
$head = New-Object System.Text.StringBuilder
[void]$head.AppendLine('OmniBrowser 동시 실행 진단 결과  (' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ')')
[void]$head.AppendLine('')
[void]$head.AppendLine('■ 자동 판정 요약 (ERROR = 원인일 가능성 높음, WARN = 의심, INFO = 참고)')
if ($findings.Count -eq 0) {
  [void]$head.AppendLine('  자동 판정으로 원인을 특정하지 못했습니다.')
  [void]$head.AppendLine('  → 한쪽이 꺼진 "직후" 다시 실행하고, 이 파일을 Claude에게 첨부해 주세요.')
}
$order = @{ 'ERROR' = 0; 'WARN' = 1; 'INFO' = 2 }
$seen = @{}
foreach ($f in ($findings | Sort-Object { $order[$_.Level] })) {
  if ($seen.ContainsKey($f.Msg)) { continue }
  $seen[$f.Msg] = 1
  [void]$head.AppendLine('  [' + $f.Level + '] ' + $f.Msg)
  [void]$head.AppendLine('          조치: ' + $f.Fix)
}
[void]$head.AppendLine('')
[void]$head.AppendLine('※ 이 파일에는 사용자 폴더 경로와 프로그램 명령줄이 들어 있습니다. 공유 전에 확인하세요.')
$utf8Bom = New-Object System.Text.UTF8Encoding($true)
[IO.File]::WriteAllText($Out, $head.ToString() + $sb.ToString(), $utf8Bom)
Write-Host ''
Write-Host ('결과 파일: ' + $Out) -ForegroundColor Green
foreach ($k in $seen.Keys) { Write-Host ('- ' + $k) }
try { Start-Process notepad.exe -ArgumentList ('"' + $Out + '"') } catch {}
