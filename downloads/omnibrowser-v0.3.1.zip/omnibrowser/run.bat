@echo off
chcp 65001 >nul
cd /d "%~dp0"
uv run poe dev
if errorlevel 1 (
  echo 실행 중 오류가 발생했습니다.  uv run poe doctor  로 점검하세요.
  pause
)
