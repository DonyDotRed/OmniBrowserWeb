# OmniBrowser v0.3.1 — 개인 전용 만능 웹 브라우저

설계서 `docs/OmniBrowser_Design_Spec_v3.2.md` 기반. Electron(화면·탭) + Python Core(데이터·TTS·AI·크롤러, uv로 관리) 구조입니다.
v0.2에서 **AI 3사(Gemini·OpenAI·Claude) 연동, 웹 크롤러·일괄 다운로드**와 여러 편의 기능을 추가했고,
v0.3에서는 **사이트 차단("Web Page Blocked!") 대응 강화, Google Gemini TTS, 로컬 TTS 모델 폴더 변경, AI·TTS 모델 최신 목록 갱신**을 추가했습니다.

### v0.3.1 변경 사항 (다른 프로그램과 동시 실행 문제)
- **고유 아이콘·작업 표시줄 ID**: 템플릿 기본 아이콘(Electron 로고)을 쓰던 다른 앱과 같은 아이콘으로 보이던 문제 해결
- **Supertonic 모델 전용 폴더**: 다른 Supertonic 앱과 `사용자 폴더\.cache\supertonic3`를 함께 쓰다 충돌하던 문제 방지 (공용 폴더의 모델은 읽어서 복사만, 다운로드·복사에 파일 잠금)
- **`diagnose.bat` 진단 도구**: 한쪽이 꺼지는 원인을 자동 조사해 바탕화면에 보고서 작성 (다른 앱 폴더를 끌어다 놓으면 그 앱 코드까지 비교) — 자세한 내용은 `docs\동시실행_문제해결.md`

### v0.3 변경 사항
- **사이트 호환 강화**: 최신 Chrome 안정판 버전을 Google에서 확인해 사용(3일마다), 요청 헤더·자바스크립트 브라우저 정보·`window.chrome`까지 실제 Chrome과 일치, 차단 화면 자동 감지 → [Edge로 다시 시도]/[외부 브라우저로 열기], 사용자 지정 UA, 크롤러 "브라우저 네트워크로 받기"(기본)
- **Gemini TTS**: 음성 30종, 말투 지시, TTS 모델 선택 — 설정 → 읽어주기 (AI와 같은 Gemini 키 사용)
- **로컬 TTS 모델 폴더**: 다른 폴더 선택(설치 여부 자동 검사) · 이 폴더로 모델 받기 · 다른 폴더로 복사해 사용 · 기본 폴더로
- **모델 최신 목록**: 🔄 버튼(설정·AI 패널), 모든 AI·TTS 목록 일괄 갱신, 하루 한 번 자동 갱신, ⭐ 추천 최신 모델, 기본 모델 단종 시 자동 대체

## 1. 설치와 실행 (Windows)

1. 이 폴더를 **영문 경로**에 둡니다. 예: `C:\dev\omnibrowser` (한글 경로·OneDrive 폴더는 피하세요)
2. `setup.bat` 더블클릭 → uv, Python 3.12, Node.js, 모든 패키지가 자동 설치됩니다 (처음 5~10분)
3. `run.bat` 더블클릭 → 하단 상태바에 **`Core ✓`** 가 보이면 성공

> 이전 버전 폴더에 덮어쓴 경우에도 `setup.bat`을 **한 번 다시 실행**하세요.

macOS/Linux는 `./setup.sh` → `./run.sh`.

## 2. AI 키 등록 (처음 한 번)

⚙ 설정 → **🤖 AI** 에서 쓸 회사의 키를 붙여넣고 저장합니다 (Windows 자격 증명 관리자에 암호화 저장).

| 회사 | 키 발급 | 기본 모델 (설정에서 변경 가능) |
|---|---|---|
| Google Gemini (기본) | https://aistudio.google.com/apikey | gemini-3.6-flash |
| OpenAI | https://platform.openai.com/api-keys | gpt-5.4-mini |
| Anthropic Claude | https://console.anthropic.com/settings/keys | claude-haiku-4-5-20251001 |

모델 이름 오류(404)가 나면 모델 선택 상자 옆 **🔄**으로 최신 목록을 받아 ⭐ 추천 모델을 고르세요. 월 사용 한도(기본 300만 자)도 설정에서 바꿀 수 있습니다.

## 3. 주요 기능

| 분류 | 기능 |
|---|---|
| **사이트 호환** | 최신 Chrome과 같은 UA·Client Hints·자바스크립트 정보 → "Web Page Blocked! … latest version of your browser" 차단 대응, 차단 화면 자동 감지·재시도. 설정에서 Chrome/Edge/직접 입력/Electron 선택 |
| **AI 도우미** 🤖 | 요약·번역·정리 노트·핵심 3줄·쉽게 설명·용어 사전·퀴즈·교정·할 일 추출 (페이지 전체 또는 선택 텍스트), 페이지에 대해 질문·이어서 대화, 결과 복사·메모·.md 저장·읽어주기 |
| **페이지 번역** 🌐 | `Alt+T` 원문 아래에 번역 표시(대역) / 번역만 / `Alt+Shift+T` 원문 복원. 결과 언어 7개 |
| **크롤러** 🕸 | 하위 페이지까지 Markdown·HTML·텍스트·JSON·**전체 합본**·PDF로 저장, PDF·**HWP**·Word·Excel·PPT·압축·이미지 등 **종류를 골라 한 번에 다운로드**, 스캔 후 골라 받기, 원클릭 5종, 로그인 사이트 지원, robots.txt 준수, ZIP |
| 읽어주기 | Supertonic 3(로컬·무료, **모델 폴더 변경 가능**) · **Google Gemini TTS** · OpenAI TTS, 엔진별 음성, 들어 보기 |
| 읽기 | **리더 모드**(`F9`, 글자 크기·테마·읽어주기·AI 요약), 본문 전체 읽어주기, 선택 텍스트 읽기(`Alt+R`) |
| 저장 | PDF · 전체 페이지 PNG · Markdown · MHTML · HTML, 본문 Markdown 복사, 화면 복사 (`Ctrl+S`) |
| 편의 | **명령 팔레트**(`Ctrl+K`), 메모(`Ctrl+Shift+N`, Markdown 내보내기), 다운로드 목록(`Ctrl+J`), 방문 기록(`Ctrl+H`), 사이트별 다크 모드, 광고·추적기 차단, 쿠키·캐시 삭제, 주소창 `?질문` |
| v0.1 기능 | 세로 탭·세션 복원·워크스페이스(로그인 분리)·배속 0.1~10x(사이트별 기억, iframe 인강 지원)·PiP·TTS(Supertonic 로컬/OpenAI)·북마크·찾기·확대 |

주요 단축키: `Ctrl+K` 명령 팔레트 · `Ctrl+Shift+A` AI · `Alt+S` 페이지 요약 · `Alt+T` 페이지 번역 · `F9` 리더 · `Ctrl+Shift+L` 크롤러 · `Ctrl+S` 저장 · `S`/`D` 배속. 전체 목록은 ⚙ 설정 맨 아래.

## 4. 크롤러 사용법

1. 모을 자료가 있는 **목록 페이지**(자료실 첫 화면 등)를 엽니다.
2. 툴바 🕸 → "⚡ 한 번에 받기"에서 원하는 버튼 클릭. 예: *이 페이지의 문서 전부 받기*, *하위 페이지 전체 → Markdown + 합본*.
3. 세밀하게 고르려면 "세부 설정"에서 범위·깊이·형식·파일 종류를 고르고 **🔍 먼저 스캔** → "📋 파일 고르기"에서 체크 → 받기.
4. 결과: `다운로드\OmniBrowser\<사이트>_<날짜>\` — `pages\`, `files\`, `pdf\`, `_전체합본.md`, `_목록_files.csv`(엑셀에서 열림).

> 저작권·이용 약관을 지켜 주세요. 요청 간격(기본 0.3초)을 너무 줄이면 사이트에 부담을 주고 차단될 수 있습니다.

## 4-1. 다른 프로그램과 함께 켜면 한쪽이 꺼질 때

`diagnose.bat` 위에 다른 프로그램 폴더를 끌어다 놓으면 원인을 자동으로 조사합니다. 결과와 조치 방법은 `docs\동시실행_문제해결.md`를 보세요. 원인이 분명하지 않으면 바탕화면에 생긴 진단 파일을 Claude에게 첨부하면 됩니다.

## 5. 개발 명령 (`uv run poe <이름>`)

| 명령 | 하는 일 |
|---|---|
| `dev` | 브라우저 실행 (= run.bat) |
| `doctor` | 개발 환경 점검 |
| `check` | 커밋 전 전체 검사 (Python 린트·테스트 29개 + TypeScript·ESLint) |
| `test-media` | 배속·단축키 자동 테스트 (실제 Electron 실행) |
| `core` | Core만 단독 실행 → http://127.0.0.1:47800/docs |
| `fetch-models` | Supertonic 모델 미리 받기 |
| `release` | 설치 파일 빌드 |

## 6. 폴더 구조

```
omnibrowser/
├─ setup.bat / run.bat        ← 설치 / 실행
├─ diagnose.bat               ← 동시 실행 문제 진단 (읽기 전용)
├─ src/omni_core/             ← Python Core (FastAPI)
│  ├─ services/ai/            ← Gemini·OpenAI·Claude 스트리밍, 작업 프리셋
│  ├─ services/crawler/       ← 크롤러 엔진
│  └─ routers/                ← ai·crawl·notes·history·bookmarks·settings·tts …
├─ tests/                     ← pytest (AI는 가짜 제공자, 크롤러는 로컬 테스트 사이트로 검사)
├─ desktop/src/main/          ← 탭·단축키·보안·UA(ua.ts)·페이지 도구(page-tools.ts)·AI 중계·크롤러·다운로드·광고 차단
├─ desktop/src/renderer/      ← React 화면 (AI·크롤러·메모·다운로드 패널, 리더, 명령 팔레트, 설정)
└─ docs/                      ← 상세 설계서 v3.2
```

## 7. 데이터 위치 (Windows)

`%APPDATA%\OmniBrowser` — 앱 DB `core\omni.db`(기록·북마크·메모·AI 사용량), 로그 `logs\main.log`, 워크스페이스 프로필 `Partitions\ws-*`.
API 키는 Windows 자격 증명 관리자("OmniBrowser")에 저장됩니다.

## 8. 알려진 제약

- AI를 쓰면 페이지 본문이 선택한 AI 회사로 전송됩니다. 사내 문서·개인정보가 있는 페이지에서는 주의하세요.
- 고급 봇 판별(행동 분석·CAPTCHA·TLS 지문)로 막는 사이트는 여전히 차단될 수 있습니다 → 안내 막대 또는 우클릭 "외부 브라우저로 열기".
- Chrome 최신 버전 확인은 인터넷이 필요합니다(회사망에서 막히면 날짜로 추정한 버전 사용).
- 크롤러는 HTML 링크를 따라갑니다. 자바스크립트로만 링크를 만드는 사이트는 하위 페이지를 못 찾을 수 있습니다.
- 넷플릭스 등 DRM 영상은 재생되지 않습니다. 코드 서명이 없어 설치 파일 첫 실행 시 SmartScreen 경고가 뜹니다.
