@echo off
rem OmniBrowser concurrent-run diagnosis (read-only). Drag another app folder onto this file to compare.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\diagnose.ps1" -OtherApp "%~1"
echo.
echo Result file saved on Desktop: OmniBrowser_*.txt
pause
