/**
 * 탭(웹페이지)용 preload — 모든 프레임(iframe 포함)에서 실행된다.
 * 역할: 배속·탐색 단축키, 사이트가 배속을 되돌릴 때 재적용, 화면 표시(OSD), 상태 보고.
 * ⚠ 샌드박스 preload이므로 'electron' 외의 모듈은 import하지 않는다.
 */
import { contextBridge, ipcRenderer } from 'electron'

/**
 * 사이트 호환: 실제 Chrome에 있는 window.chrome 속성(app·runtime·csi·loadTimes) 보완.
 * preload는 페이지 스크립트보다 먼저 실행되므로, 사이트가 브라우저를 검사하기 전에 적용된다.
 */
function chromeShim(): void {
  try {
    const w = window as unknown as { chrome?: Record<string, unknown> }
    let c = w.chrome
    if (!c || !Object.isExtensible(c)) {
      c = Object.assign({}, c || {})
      Object.defineProperty(window, 'chrome', {
        value: c,
        writable: true,
        configurable: true,
        enumerable: true
      })
    }
    if (!c.app)
      c.app = {
        isInstalled: false,
        InstallState: {
          DISABLED: 'disabled',
          INSTALLED: 'installed',
          NOT_INSTALLED: 'not_installed'
        },
        RunningState: {
          CANNOT_RUN: 'cannot_run',
          READY_TO_RUN: 'ready_to_run',
          RUNNING: 'running'
        },
        getDetails: () => null,
        getIsInstalled: () => false,
        runningState: () => 'cannot_run'
      }
    if (!c.runtime) c.runtime = {}
    if (!c.csi)
      c.csi = () => ({
        startE: Date.now(),
        onloadT: Date.now(),
        pageT: performance.now(),
        tran: 15
      })
    if (!c.loadTimes)
      c.loadTimes = () => {
        const s = Date.now() / 1000
        return {
          requestTime: s,
          startLoadTime: s,
          commitLoadTime: s,
          finishDocumentLoadTime: s,
          finishLoadTime: s,
          firstPaintTime: s,
          firstPaintAfterLoadTime: 0,
          navigationType: 'Other',
          wasFetchedViaSpdy: true,
          wasNpnNegotiated: true,
          npnNegotiatedProtocol: 'h2',
          wasAlternateProtocolAvailable: false,
          connectionInfo: 'h2'
        }
      }
  } catch {
    // 일부 특수 페이지에서는 실패해도 무시
  }
}
try {
  contextBridge.executeInMainWorld({ func: chromeShim })
} catch {
  // 무시
}

const MIN = 0.1
const MAX = 10 // Chromium 허용 범위(약 0.0625~16) 안쪽. 고배속에서 소리가 끊기면 브라우저 제약
let favorite = 1.5 // 설정(media.favorite_rate) 값으로 교체됨
const clamp = (r: number): number => Math.min(MAX, Math.max(MIN, Math.round(r * 100) / 100))

let targetRate: number | null = null // null = 강제하지 않음 (사이트 기본 동작 존중)
let previousRate = 1.5 // R 키: 1.0x ↔ 직전 배속
let lastOwnSet = 0
let fightStart = 0
let fights = 0
let siteRateChecked = false
let loopA: number | null = null
let loopB: number | null = null

/** 문서 + 열린 Shadow DOM 안의 모든 video/audio 수집 */
function collectMedia(
  root: Document | ShadowRoot = document,
  out: HTMLMediaElement[] = []
): HTMLMediaElement[] {
  root.querySelectorAll<HTMLMediaElement>('video, audio').forEach((m) => out.push(m))
  root.querySelectorAll('*').forEach((el) => {
    if (el.shadowRoot) collectMedia(el.shadowRoot, out)
  })
  return out
}

/** 조작 대상: 재생 중인 것 우선, 없으면 화면에서 가장 큰 영상 */
function mainMedia(): HTMLMediaElement | undefined {
  const all = collectMedia()
  const area = (m: HTMLMediaElement): number => m.clientWidth * m.clientHeight
  return all.find((m) => !m.paused) ?? all.sort((a, b) => area(b) - area(a))[0]
}

function apply(m: HTMLMediaElement): void {
  if (targetRate === null) return
  m.preservesPitch = true // 고배속에서도 목소리 톤 유지 (Chromium 내장 기능)
  if (Math.abs(m.playbackRate - targetRate) > 0.001) {
    try {
      m.playbackRate = targetRate
    } catch {
      // 지원 범위를 벗어난 값 → 무시
    }
  }
}

/** 상태 보고. user=true면 Main이 "이 사이트의 배속"으로 기억함 (MED-05) */
function report(user = false): void {
  const m = mainMedia()
  if (m) ipcRenderer.send('media:state', { rate: m.playbackRate, playing: !m.paused, user })
}

function setRate(rate: number, osd = true, user = true): void {
  const next = clamp(rate)
  if (targetRate !== null && targetRate !== 1) previousRate = targetRate
  targetRate = next
  lastOwnSet = performance.now()
  collectMedia().forEach(apply)
  if (osd) showOSD(`${next.toFixed(2)}×`)
  report(user)
}

// ── 사이트가 배속을 1.0으로 되돌리면 다시 적용 (capture 단계에서 감지) ──
document.addEventListener(
  'ratechange',
  (e) => {
    const m = e.target
    if (!(m instanceof HTMLMediaElement) || targetRate === null) return
    if (Math.abs(m.playbackRate - targetRate) < 0.001) return
    const now = performance.now()
    // 사용자가 사이트의 배속 메뉴를 직접 클릭해서 바꾼 경우 → 그 값을 받아들임
    if (navigator.userActivation?.isActive && now - lastOwnSet > 1000) {
      targetRate = clamp(m.playbackRate)
      return report(true)
    }
    if (now - fightStart > 1000) {
      fightStart = now
      fights = 0
    }
    if (++fights > 5) return // 1초에 5회 넘게 싸우면 양보 (무한 루프·CPU 폭주 방지)
    apply(m)
  },
  true
)

document.addEventListener(
  'play',
  (e) => {
    if (!(e.target instanceof HTMLMediaElement)) return
    if (!siteRateChecked) {
      siteRateChecked = true // 이 사이트에서 기억해 둔 배속이 있으면 적용 (최초 1회)
      void ipcRenderer.invoke('media:get-favorite-rate').then((r: number) => (favorite = r))
      void ipcRenderer.invoke('media:get-site-rate').then((r: number | null) => {
        if (r && targetRate === null) setRate(r, false, false)
      })
    }
    apply(e.target)
    report()
  },
  true
)
document.addEventListener('pause', () => report(), true)

// 구간 반복 (A-B)
document.addEventListener(
  'timeupdate',
  (e) => {
    const m = e.target
    if (
      m instanceof HTMLMediaElement &&
      loopA !== null &&
      loopB !== null &&
      m.currentTime >= loopB
    ) {
      m.currentTime = loopA
    }
  },
  true
)

// ── 단축키: 어느 프레임에서 눌렀든 Main을 거쳐 탭의 모든 프레임에 전달 ──
function deepActiveElement(): Element | null {
  let el = document.activeElement
  while (el?.shadowRoot?.activeElement) el = el.shadowRoot.activeElement
  return el
}

function isTyping(): boolean {
  const el = deepActiveElement()
  if (!el) return false
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return true
  if (el instanceof HTMLSelectElement) return true
  return (el as HTMLElement).isContentEditable
}

const MEDIA_KEYS = new Set([
  'KeyS',
  'KeyD',
  'KeyR',
  'KeyG',
  'KeyZ',
  'KeyX',
  'Comma',
  'Period',
  'BracketLeft',
  'BracketRight',
  'Backslash'
])

window.addEventListener(
  'keydown',
  (e) => {
    // e.code = 키보드의 "물리적 위치" → 한글 입력 모드(ㄴ, ㅇ)에서도 S, D로 인식
    if (!MEDIA_KEYS.has(e.code) || e.ctrlKey || e.altKey || e.metaKey || isTyping()) return
    if (collectMedia().length > 0) {
      e.preventDefault() // 이 프레임에 영상이 있으면 사이트 자체 단축키와 중복 실행 방지
      e.stopImmediatePropagation()
    }
    ipcRenderer.send('media:key', { code: e.code, shift: e.shiftKey })
  },
  true
)

ipcRenderer.on('media:key', (_e, key: { code: string; shift: boolean }) => {
  const m = mainMedia()
  if (!m) return // 영상이 없는 프레임은 무시
  const cur = targetRate ?? m.playbackRate
  const step = key.shift ? 0.5 : 0.1
  switch (key.code) {
    case 'KeyD':
      return setRate(cur + step)
    case 'KeyS':
      return setRate(cur - step)
    case 'KeyR':
      return setRate(cur === 1 ? previousRate : 1)
    case 'KeyG':
      return setRate(favorite)
    case 'KeyZ':
      m.currentTime = Math.max(0, m.currentTime - 10)
      return showOSD('⏪ 10초')
    case 'KeyX':
      m.currentTime += 10
      return showOSD('10초 ⏩')
    case 'Comma':
    case 'Period':
      if (!m.paused) return // 프레임 이동은 일시정지 중에만
      m.currentTime += (key.code === 'Period' ? 1 : -1) / 30 // 약 1프레임(30fps 가정)
      return
    case 'BracketLeft':
      loopA = m.currentTime
      return showOSD('반복 시작 A')
    case 'BracketRight':
      loopB = m.currentTime
      return showOSD('반복 끝 B')
    case 'Backslash':
      loopA = loopB = null
      return showOSD('반복 해제')
  }
})

// 상태바 슬라이더·명령 팔레트·제스처에서 온 배속 지정
ipcRenderer.on('media:set-rate', (_e, rate: number) => {
  if (collectMedia().length > 0) setRate(rate)
})

// ── 화면 표시(OSD): innerHTML 대신 createElement (Trusted Types 사이트에서도 동작) ──
let osd: HTMLDivElement | null = null
let osdTimer: ReturnType<typeof setTimeout> | undefined

function showOSD(text: string): void {
  if (!osd) {
    osd = document.createElement('div')
    osd.style.cssText =
      'position:fixed;top:24px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
      'padding:6px 14px;border-radius:8px;background:rgba(0,0,0,.75);color:#fff;' +
      'font:600 18px system-ui,sans-serif;pointer-events:none;transition:opacity .3s'
  }
  // 전체 화면일 때는 전체 화면 요소 안에 붙여야 보임 (<video> 자체가 전체 화면이면 표시 불가 → 상태바로 대신)
  const fs = document.fullscreenElement
  const host = fs && !(fs instanceof HTMLMediaElement) ? fs : document.documentElement
  if (osd.parentNode !== host) host.appendChild(osd)
  osd.textContent = text
  osd.style.opacity = '1'
  clearTimeout(osdTimer)
  osdTimer = setTimeout(() => {
    if (osd) osd.style.opacity = '0'
  }, 800)
}
