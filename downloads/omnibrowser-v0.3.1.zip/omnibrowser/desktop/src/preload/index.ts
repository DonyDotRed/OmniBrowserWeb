/** UI 창 전용 브리지: window.omni 로 노출. 목록에 있는 채널만 사용할 수 있다(최소 권한). */
import { contextBridge, ipcRenderer, type IpcRendererEvent } from 'electron'

const INVOKE = [
  'core:get-status',
  'tabs:list',
  'tabs:create',
  'tabs:activate',
  'tabs:close',
  'tabs:mute',
  'tabs:set-covered',
  'nav:go',
  'split:set-bounds',
  'cmd:run',
  'overlay:show',
  'overlay:hide',
  'find:query',
  'find:stop',
  'media:set-rate',
  'tts:read',
  'tts:stop',
  'history:search',
  'bookmarks:list',
  'bookmarks:toggle',
  'bookmarks:remove',
  'settings:get',
  'settings:set',
  'secrets:get',
  'secrets:set',
  'secrets:delete',
  'ws:list',
  'ws:switch',
  'ws:create',
  'ws:delete',
  // v0.2
  'ai:providers',
  'ai:presets',
  'ai:models',
  'ai:usage',
  'ai:run',
  'ai:stop',
  'ai:save-md',
  'page:extract',
  'page:translate',
  'page:save',
  'tts:text',
  'clipboard:write',
  'crawl:file-types',
  'crawl:start',
  'crawl:jobs',
  'crawl:status',
  'crawl:download',
  'crawl:cancel',
  'crawl:open',
  'crawl:choose-dir',
  'downloads:list',
  'downloads:open',
  'downloads:show',
  'downloads:cancel',
  'downloads:clear',
  'notes:list',
  'notes:add',
  'notes:delete',
  'notes:export',
  'history:list',
  'history:clear',
  'browsing:clear',
  'menu:more',
  // v0.3
  'ua:info',
  'ua:refresh-version',
  'ua:retry',
  'tts:voices',
  'tts:models',
  'tts:local-status',
  'tts:local-download',
  'tts:local-copy',
  'tts:local-reload',
  'dialog:choose-dir',
  'ai:refresh-models'
] as const

const EVENTS = [
  'tabs:state',
  'core:status',
  'media:state',
  'find:result',
  'bookmarks:changed',
  'tts:start',
  'tts:chunk',
  'tts:stop',
  'ui:toast',
  'ui:focus-address',
  'ui:find-open',
  'ui:ws-index',
  'ui:panel',
  'ui:palette',
  'ui:reader',
  'ui:sidebar',
  'ui:ai-request',
  'ui:crawl-url',
  'ai:chunk',
  'ai:done',
  'downloads:state',
  'ui:blocked'
] as const

export type InvokeChannel = (typeof INVOKE)[number]
export type EventChannel = (typeof EVENTS)[number]

const api = {
  invoke<T = unknown>(channel: InvokeChannel, ...args: unknown[]): Promise<T> {
    if (!INVOKE.includes(channel)) throw new Error(`허용되지 않은 채널: ${channel}`)
    return ipcRenderer.invoke(channel, ...args)
  },
  /** Main이 보내는 이벤트 구독. 반환값(함수)을 호출하면 구독 해제 */
  on(event: EventChannel, fn: (payload: unknown) => void): () => void {
    if (!EVENTS.includes(event)) throw new Error(`허용되지 않은 이벤트: ${event}`)
    const handler = (_e: IpcRendererEvent, payload: unknown): void => fn(payload)
    ipcRenderer.on(event, handler)
    return () => ipcRenderer.removeListener(event, handler)
  }
}

contextBridge.exposeInMainWorld('omni', api)
export type OmniApi = typeof api
