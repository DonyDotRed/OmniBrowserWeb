import type { OmniApi } from './index'

declare global {
  interface Window {
    omni: OmniApi
  }
}
