/** 선택 텍스트 읽기(TTS-01): 문장으로 나눠 차례로 합성 → UI로 오디오 전달 → UI가 이어서 재생 */
import { core, coreJson } from './core-process'

export class ReadAloud {
  private generation = 0 // 새 요청·정지 시 증가 → 이전 작업은 스스로 멈춤

  constructor(
    private send: (channel: string, payload: unknown) => void,
    private toast: (msg: string) => void
  ) {}

  stop(): void {
    this.generation++
    this.send('tts:stop', null)
  }

  async read(text: string): Promise<void> {
    const my = ++this.generation
    const clean = text.trim()
    if (!clean) return this.toast('읽을 텍스트를 먼저 드래그해서 선택하세요')
    try {
      const s = await coreJson<Record<string, unknown>>('/settings')
      const { sentences } = await coreJson<{ sentences: string[] }>('/tts/split', {
        method: 'POST',
        body: { text: clean }
      })
      this.send('tts:start', { total: sentences.length, rate: s['tts.rate'] })
      for (let i = 0; i < sentences.length; i++) {
        if (my !== this.generation) return
        const r = await core('/tts/synthesize', {
          method: 'POST',
          body: {
            provider: s['tts.provider'],
            voice: s[`tts.voice.${s['tts.provider']}`] ?? s['tts.voice'],
            lang: s['tts.lang'],
            text: sentences[i]
          }
        })
        const base64 = Buffer.from(await r.arrayBuffer()).toString('base64')
        if (my !== this.generation) return
        this.send('tts:chunk', {
          index: i,
          total: sentences.length,
          text: sentences[i],
          mime: r.headers.get('content-type') ?? 'audio/wav',
          base64
        })
      }
    } catch (e) {
      if (my !== this.generation) return
      this.toast(`읽기 실패: ${(e as Error).message}`)
      this.send('tts:stop', null)
    }
  }
}
