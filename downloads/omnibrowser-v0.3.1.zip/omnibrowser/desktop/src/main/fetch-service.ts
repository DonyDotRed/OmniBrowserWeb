/**
 * 브라우저 네트워크 가져오기 서비스 (크롤러용, 127.0.0.1 전용 + 토큰).
 * Core 크롤러가 이 주소로 요청하면, Electron(Chromium) 네트워크로 대신 받아 준다.
 * → 실제 Chrome과 같은 TLS·HTTP/2·헤더·쿠키·UA로 요청하므로 방화벽이 크롤러를 막는 사이트도 받을 수 있다.
 */
import { session } from 'electron'
import { randomBytes } from 'node:crypto'
import { createServer, type Server } from 'node:http'
import { Readable } from 'node:stream'
import type { ReadableStream as WebReadableStream } from 'node:stream/web'
import log from 'electron-log/main'

let server: Server | null = null
let port = 0
const token = randomBytes(24).toString('hex')

export function startFetchService(headers: () => Record<string, string>): Promise<void> {
  return new Promise((resolve) => {
    server = createServer(async (req, res) => {
      try {
        if (req.headers['x-omni-token'] !== token) {
          res.writeHead(401).end()
          return
        }
        const q = new URL(req.url ?? '/', 'http://127.0.0.1').searchParams
        const target = q.get('url') ?? ''
        const partition = q.get('p') ?? 'persist:ws-default'
        if (!/^https?:\/\//.test(target) || !partition.startsWith('persist:ws-')) {
          res.writeHead(400).end('bad request')
          return
        }
        const ac = new AbortController()
        req.on('close', () => ac.abort())
        const r = await session.fromPartition(partition).fetch(target, {
          headers: headers(),
          credentials: 'include',
          redirect: 'follow',
          signal: ac.signal
        })
        const out: Record<string, string> = { 'x-final-url': r.url || target }
        for (const k of [
          'content-type',
          'content-disposition',
          'content-length',
          'last-modified'
        ]) {
          const v = r.headers.get(k)
          if (v) out[k] = v
        }
        res.writeHead(r.status, out)
        if (r.body) Readable.fromWeb(r.body as unknown as WebReadableStream).pipe(res)
        else res.end()
      } catch (e) {
        if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain' })
        res.end(String((e as Error).message))
      }
    })
    server.listen(0, '127.0.0.1', () => {
      const a = server!.address()
      port = typeof a === 'object' && a ? a.port : 0
      log.info('[fetch-service] port', port)
      resolve()
    })
  })
}

export function fetchServiceInfo(
  partition: string
): { fetch_via: string; fetch_token: string } | null {
  if (!port) return null
  return {
    fetch_via: `http://127.0.0.1:${port}/fetch?p=${encodeURIComponent(partition)}`,
    fetch_token: token
  }
}

export function stopFetchService(): void {
  server?.close()
}
