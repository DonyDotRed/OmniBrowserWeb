import {
  app,
  BrowserWindow,
  clipboard,
  dialog,
  ipcMain,
  Menu,
  session,
  shell,
  type ContextMenuParams,
  type Event,
  type Input,
  type IpcMainEvent,
  type IpcMainInvokeEvent,
  type MenuItemConstructorOptions,
  type Rectangle,
  type Session,
  type WebContents
} from 'electron'
import { writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { is } from '@electron-toolkit/utils'
import log from 'electron-log/main'
import appIcon from '../../resources/icon.png?asset'
import { setAdblock } from './adblock'
import { AiRunner } from './ai'
import { comboOf, KEYMAP } from './commands'
import {
  core,
  coreJson,
  getCoreStatus,
  onCoreStatus,
  startCore,
  stopCore,
  whenCoreSettled
} from './core-process'
import { cancelPdf, crawlStatus, startCrawl, type CrawlRequest } from './crawl'
import { DownloadManager } from './downloads'
import { createOverlay, type Overlay } from './overlay'
import {
  extractPage,
  forgetDark,
  isDark,
  restoreOriginal,
  safeFileName,
  savePage,
  setDark,
  translatePage,
  type SaveFormat
} from './page-tools'
import { allSessions, setupSession } from './security'
import { TabManager, type SessionSnapshot } from './tabs'
import { ReadAloud } from './tts'
import { fetchServiceInfo, startFetchService, stopFetchService } from './fetch-service'
import {
  applyUserAgent,
  BLOCK_CHECK,
  chromeHeaders,
  chromeVersion,
  emulateTab,
  refreshChromeVersion,
  userAgentFor,
  type UaMode
} from './ua'

log.initialize() // 로그 파일: %APPDATA%\OmniBrowser\logs\main.log
app.enableSandbox() // 모든 렌더러를 샌드박스로 (보안 체크리스트 #1)

let startUrl = 'https://www.google.com' // 설정(start.url)으로 변경 가능
let win: BrowserWindow
let tabs: TabManager
let overlay: Overlay
let reader: ReadAloud
let restored = false // 세션 복원이 끝나기 전에는 빈 세션을 저장하지 않음
let ai: AiRunner
let downloads: DownloadManager
let settingsCache: Record<string, unknown> = {}

// 사이트 호환성: 첫 요청부터 일반 크롬과 같은 UA 사용 (Electron 표시가 있으면 일부 사이트가 차단)
const ELECTRON_UA = app.userAgentFallback
let uaMode: UaMode = 'chrome'
let uaCustom = ''
app.userAgentFallback = userAgentFor(uaMode, ELECTRON_UA)
const currentUA = (): string => userAgentFor(uaMode, ELECTRON_UA, uaCustom)
const blockedShown = new Set<string>() // 같은 사이트에서 차단 안내를 반복하지 않음

/** UA 모드·Chrome 버전이 바뀌면 모든 세션·탭에 다시 적용 */
function reapplyUA(): void {
  app.userAgentFallback = currentUA()
  for (const s of allSessions()) applyUserAgent(s, uaMode, currentUA())
  for (const wc of tabs?.allWebContents() ?? []) {
    if (uaMode === 'electron' || uaMode === 'custom') {
      if (wc.debugger.isAttached()) {
        void wc.debugger
          .sendCommand('Emulation.setUserAgentOverride', { userAgent: currentUA() })
          .catch(() => {})
      }
    } else void emulateTab(wc, uaMode, currentUA())
  }
}
const darkSites = new Map<string, boolean>() // 출처 → 다크 모드 (Core site-settings 캐시)

const toUI = (channel: string, payload?: unknown): void => {
  if (!win.isDestroyed()) win.webContents.send(channel, payload)
}
const toast = (message: string): void => toUI('ui:toast', message)

/** UI 창(또는 오버레이)에서 온 요청만 허용 — 웹페이지가 UI용 채널을 호출하는 것 차단 */
function assertUI(e: IpcMainEvent | IpcMainInvokeEvent): void {
  if (e.sender !== win.webContents && e.sender !== overlay.webContents) {
    throw new Error(`forbidden IPC sender: ${e.sender.getURL()}`)
  }
}

/** 탭(웹페이지)에서 온 요청인지 확인 */
function assertTab(e: IpcMainEvent | IpcMainInvokeEvent): void {
  if (!tabs.has(e.sender.id)) throw new Error('not a tab')
}

function originOf(url: string): string | null {
  try {
    const u = new URL(url)
    return u.protocol.startsWith('http') ? u.origin : null
  } catch {
    return null
  }
}

// ───────────────────────── 세션 자동 저장 (TAB-05) ─────────────────────────
let saveTimer: NodeJS.Timeout | undefined
function scheduleSave(): void {
  if (!restored) return
  clearTimeout(saveTimer)
  saveTimer = setTimeout(() => void saveSession('auto'), 1500)
}
async function saveSession(reason: 'auto' | 'quit'): Promise<void> {
  if (!restored || getCoreStatus().status !== 'ready') return
  await core('/sessions/latest', {
    method: 'PUT',
    body: { reason, payload: tabs.snapshot() }
  }).catch((err) => log.warn('[session]', err.message))
}

async function restoreSession(): Promise<void> {
  if ((await whenCoreSettled()) === 'ready') {
    try {
      const settings = await coreJson<Record<string, unknown>>('/settings')
      settingsCache = settings
      if (typeof settings['start.url'] === 'string') startUrl = settings['start.url']
      uaMode = (settings['browser.user_agent'] as UaMode) || 'chrome'
      uaCustom = String(settings['browser.user_agent_custom'] ?? '')
      reapplyUA()
      if (settings['ai.models_auto_refresh'])
        void core('/ai/models/refresh?only_stale=true', { method: 'POST' }).catch(() => {}) // 하루 한 번 최신 모델 목록
      if (settings['privacy.adblock'])
        void setAdblock(true, allSessions()).catch((e) => toast(e.message))
      const s = await coreJson<{ payload: SessionSnapshot } | null>('/sessions/latest')
      if (s?.payload?.tabs?.length) tabs.restore(s.payload)
    } catch (err) {
      log.warn('[session] restore failed', err)
    }
  } else {
    toast('Core 연결 실패 — 기록·북마크·TTS가 동작하지 않습니다 (uv run poe doctor)')
  }
  if (tabs.list().length === 0) tabs.create(startUrl)
  restored = true
}

// ───────────────────────── 사이트별 배속 기억 (MED-05) ─────────────────────────
const rateTimers = new Map<string, NodeJS.Timeout>()
function rememberSiteRate(origin: string, rate: number): void {
  clearTimeout(rateTimers.get(origin))
  rateTimers.set(
    origin,
    setTimeout(() => {
      core('/site-settings', {
        method: 'PUT',
        body: { origin, key: 'media.rate', value: rate }
      }).catch(() => {})
    }, 800)
  )
}

// ───────────────────────── 명령 실행 (단축키·UI 버튼·메뉴 공용) ─────────────────────────
async function toggleBookmark(): Promise<void> {
  const t = tabs.active === null ? null : tabs.info(tabs.active)
  if (!t || !t.url.startsWith('http')) return
  try {
    const list = await coreJson<{ id: string; url: string }[]>('/bookmarks')
    const found = list.find((b) => b.url === t.url)
    if (found) {
      await core(`/bookmarks/${found.id}`, { method: 'DELETE' })
      toast('☆ 북마크 삭제')
    } else {
      await core('/bookmarks', { method: 'POST', body: { title: t.title, url: t.url } })
      toast('★ 북마크 추가')
    }
    toUI('bookmarks:changed')
  } catch (err) {
    toast(`북마크 실패: ${(err as Error).message}`)
  }
}

async function forcePip(id: number): Promise<void> {
  // 사이트가 PiP를 막아 두어도(disablePictureInPicture) 강제로 켬 (3.5절)
  const code = `(() => {
    if (document.pictureInPictureElement) { document.exitPictureInPicture(); return true }
    const vs = [...document.querySelectorAll('video')]
    const v = vs.find((x) => !x.paused) || vs[0]
    if (!v) return false
    v.disablePictureInPicture = false
    v.requestPictureInPicture().catch(() => {})
    return true
  })()`
  for (const f of tabs.wc(id)?.mainFrame.framesInSubtree ?? []) {
    if (await f.executeJavaScript(code, true).catch(() => false)) return
  }
  toast('이 페이지에서 영상을 찾지 못했습니다')
}

async function readSelection(id: number | null, text?: string): Promise<void> {
  const wc = tabs.wc(id)
  const selected =
    text ?? (wc ? await wc.executeJavaScript('getSelection().toString()').catch(() => '') : '')
  void reader.read(String(selected))
}

// ───────────────────────── AI · 페이지 도구 ─────────────────────────
interface AiRequest {
  jobId: string
  source: 'selection' | 'page' | 'text' | 'none'
  text?: string
  preset?: string
  instruction?: string
  question?: string
  history?: { role: string; content: string }[]
  lang?: string
  provider?: string
  model?: string
}

async function runAi(req: AiRequest): Promise<{ title: string; url: string; chars: number }> {
  const wc = tabs.wc(tabs.active)
  let input = ''
  let title = wc?.getTitle() ?? ''
  let url = wc?.getURL() ?? ''
  if (req.source === 'text') input = req.text ?? ''
  else if (req.source !== 'none' && wc && url.startsWith('http')) {
    const page = await extractPage(wc)
    title = page.title
    url = page.url
    input = req.source === 'selection' ? page.selection.trim() : page.text
    if (req.source === 'selection' && !input)
      throw new Error('선택된 텍스트가 없습니다. 페이지에서 먼저 드래그하세요.')
  } else if ((req.source === 'selection' || req.source === 'page') && !req.question) {
    throw new Error('웹페이지(http/https)에서만 사용할 수 있습니다')
  }
  void ai.run(req.jobId, {
    preset: req.preset,
    instruction: req.instruction,
    question: req.question,
    history: req.history ?? [],
    input,
    lang: req.lang,
    provider: req.provider,
    model: req.model,
    page_title: title,
    page_url: url
  })
  return { title, url, chars: input.length }
}

/** 우클릭·단축키 → AI 패널을 열고 작업 요청 (대화 기록은 UI가 관리) */
function askAi(preset: string | null, source: 'selection' | 'page' | 'text', text?: string): void {
  toUI('ui:panel', 'ai')
  toUI('ui:ai-request', { preset, source, text })
}

async function translateActivePage(mode: 'bilingual' | 'replace'): Promise<void> {
  const wc = tabs.wc(tabs.active)
  if (!wc || !wc.getURL().startsWith('http')) return toast('웹페이지에서만 번역할 수 있습니다')
  toast('🌐 페이지 번역 중… (Alt+T 다시 누르면 중지)')
  const msg = await translatePage(
    wc,
    {
      lang: String(settingsCache['ai.lang'] ?? 'ko'),
      mode,
      maxSegments: Number(settingsCache['ai.translate_max_segments'] ?? 400)
    },
    (done, total) => toast(`🌐 페이지 번역 ${done}/${total}`)
  ).catch((e) => `번역 실패: ${(e as Error).message}`)
  toast(msg)
}

async function doSave(fmt: SaveFormat): Promise<void> {
  const wc = tabs.wc(tabs.active)
  if (!wc) return
  try {
    const msg = await savePage(win, wc, fmt)
    if (msg) toast(msg)
  } catch (e) {
    toast(`저장 실패: ${(e as Error).message}`)
  }
}

async function toggleDark(): Promise<void> {
  const wc = tabs.wc(tabs.active)
  const origin = wc ? originOf(wc.getURL()) : null
  if (!wc || !origin) return
  const on = !isDark(wc)
  await setDark(wc, on)
  darkSites.set(origin, on)
  core('/site-settings', { method: 'PUT', body: { origin, key: 'page.dark', value: on } }).catch(
    () => {}
  )
  toast(on ? '🌙 이 사이트는 다크 모드로 표시합니다' : '☀ 다크 모드 해제')
}

async function onDomReady(_id: number, wc: WebContents): Promise<void> {
  const origin = originOf(wc.getURL())
  if (!origin) return
  if (!darkSites.has(origin)) {
    const s = await coreJson<Record<string, unknown>>(
      `/site-settings?origin=${encodeURIComponent(origin)}`
    ).catch(() => ({}) as Record<string, unknown>)
    darkSites.set(origin, s['page.dark'] === true)
  }
  if (darkSites.get(origin)) await setDark(wc, true).catch(() => {})
  // 차단 화면 감지 → 상단 안내 막대 (호환 모드 바꿔 재시도 / 외부 브라우저)
  if (settingsCache['browser.block_detect'] !== false && !blockedShown.has(origin)) {
    const blocked = await wc
      .executeJavaScriptInIsolatedWorld(1003, [{ code: BLOCK_CHECK }])
      .catch(() => false)
    if (blocked) {
      blockedShown.add(origin)
      toUI('ui:blocked', { tabId: _id, url: wc.getURL(), mode: uaMode, chrome: chromeVersion() })
    }
  }
}

function saveMenuItems(): MenuItemConstructorOptions[] {
  return [
    { label: 'PDF로 저장', click: () => void doSave('pdf') },
    { label: '전체 페이지 이미지(PNG)로 저장\tCtrl+Shift+S', click: () => void doSave('png') },
    { label: 'Markdown(본문)으로 저장', click: () => void doSave('md') },
    { label: '웹 보관 파일(MHTML)로 저장', click: () => void doSave('mhtml') },
    { label: 'HTML(파일 포함)로 저장', click: () => void doSave('html') },
    { type: 'separator' },
    { label: '본문을 Markdown으로 복사', click: () => void doSave('md-copy') },
    { label: '보이는 화면을 클립보드로 복사', click: () => void doSave('shot-copy') }
  ]
}

function moreMenu(): void {
  const items: MenuItemConstructorOptions[] = [
    { label: '🤖 AI 도우미\tCtrl+Shift+A', click: () => toUI('ui:panel', 'ai') },
    { label: '📝 이 페이지 AI 요약\tAlt+S', click: () => askAi('summarize', 'page') },
    {
      label: '🌐 페이지 번역 (원문+번역)\tAlt+T',
      click: () => void translateActivePage('bilingual')
    },
    { label: '🌐 페이지 번역 (번역만)', click: () => void translateActivePage('replace') },
    { label: '↩ 번역 전 원문으로\tAlt+Shift+T', click: () => run('page.restore') },
    { type: 'separator' },
    { label: '📖 리더 모드\tF9', click: () => toUI('ui:reader') },
    { label: '🔊 본문 전체 읽어주기', click: () => run('tts.page') },
    { label: '🌙 다크 모드 (이 사이트)\tAlt+Shift+D', click: () => void toggleDark() },
    { type: 'separator' },
    { label: '🕸 크롤러 · 일괄 다운로드\tCtrl+Shift+L', click: () => toUI('ui:panel', 'crawl') },
    { label: '💾 페이지 저장', submenu: saveMenuItems() },
    { label: '🖨 인쇄\tCtrl+P', click: () => run('page.print') },
    { type: 'separator' },
    { label: '🗒 메모\tCtrl+Shift+N', click: () => toUI('ui:panel', 'notes') },
    { label: '⬇ 다운로드\tCtrl+J', click: () => toUI('ui:panel', 'downloads') },
    { label: '🕘 방문 기록\tCtrl+H', click: () => toUI('ui:sidebar', 'history') },
    { label: '⌘ 명령 팔레트\tCtrl+K', click: () => toUI('ui:palette') },
    { type: 'separator' },
    { label: '외부 브라우저로 열기', click: () => run('open.external') }
  ]
  Menu.buildFromTemplate(items).popup({ window: win })
}

function run(cmd: string): void {
  const id = tabs.active
  const wc = tabs.wc(id)
  if (cmd.startsWith('ws.')) {
    toUI('ui:ws-index', Number(cmd.slice(3)) - 1) // UI가 목록 순서로 전환 요청
    return
  }
  switch (cmd) {
    case 'tab.new':
      tabs.create(startUrl)
      toUI('ui:focus-address')
      break
    case 'tab.close':
      if (id !== null) tabs.close(id)
      break
    case 'tab.reopen':
      tabs.reopenClosed()
      break
    case 'tab.next':
      tabs.cycle(1)
      break
    case 'tab.prev':
      tabs.cycle(-1)
      break
    case 'tab.mute':
      wc?.setAudioMuted(!wc.isAudioMuted())
      toUI('tabs:state', { list: tabs.list(), activeId: tabs.active, workspaceId: tabs.workspace })
      break
    case 'address.focus':
      win.webContents.focus()
      toUI('ui:focus-address')
      break
    case 'nav.reload':
      wc?.reload()
      break
    case 'nav.back':
      wc?.navigationHistory.goBack()
      break
    case 'nav.forward':
      wc?.navigationHistory.goForward()
      break
    case 'find.open':
      win.webContents.focus()
      toUI('ui:find-open')
      break
    case 'bookmark.toggle':
      void toggleBookmark()
      break
    case 'zoom.in':
    case 'zoom.out':
    case 'zoom.reset':
      if (id !== null) tabs.zoom(id, cmd === 'zoom.in' ? 1 : cmd === 'zoom.out' ? -1 : 0)
      break
    case 'tts.read':
      void readSelection(id)
      break
    case 'tts.stop':
      reader.stop()
      break
    case 'media.pip':
      if (id !== null) void forcePip(id)
      break
    case 'devtools.tab':
      wc?.toggleDevTools()
      break
    case 'devtools.ui':
      win.webContents.toggleDevTools()
      break
    case 'palette':
      win.webContents.focus()
      toUI('ui:palette')
      break
    case 'panel.ai':
    case 'panel.crawl':
    case 'panel.notes':
    case 'panel.downloads':
      toUI('ui:panel', cmd.slice(6))
      break
    case 'sidebar.history':
      toUI('ui:sidebar', 'history')
      break
    case 'ai.summarize':
      askAi('summarize', 'page')
      break
    case 'page.translate':
      void translateActivePage('bilingual')
      break
    case 'page.restore':
      if (wc)
        void restoreOriginal(wc).then((ok) =>
          toast(ok ? '원문으로 되돌렸습니다' : '번역된 내용이 없습니다')
        )
      break
    case 'reader.toggle':
      win.webContents.focus() // 가려진 웹페이지 대신 UI가 키 입력을 받도록 (F9·Esc로 닫기)
      toUI('ui:reader')
      break
    case 'page.dark':
      void toggleDark()
      break
    case 'page.print':
      wc?.print({}, () => {})
      break
    case 'page.save.menu':
      Menu.buildFromTemplate(saveMenuItems()).popup({ window: win })
      break
    case 'page.save.png':
      void doSave('png')
      break
    case 'more.menu':
      moreMenu()
      break
    case 'tts.page':
      if (wc) void extractPage(wc).then((p) => reader.read(p.text))
      break
    case 'open.external':
      if (wc?.getURL().startsWith('http')) void shell.openExternal(wc.getURL()) // DRM 사이트 등 (CNV-10)
      break
  }
}

function onKey(input: Input, event: Event): void {
  if (input.type !== 'keyDown') return
  const cmd = KEYMAP[comboOf(input)]
  if (!cmd) return
  event.preventDefault()
  run(cmd)
}

function onContextMenu(tabId: number, p: ContextMenuParams): void {
  const wc = tabs.wc(tabId)
  if (!wc) return
  const items: MenuItemConstructorOptions[] = []
  if (p.linkURL) {
    items.push(
      { label: '새 탭에서 링크 열기', click: () => tabs.create(p.linkURL, tabs.workspace, true) },
      { label: '링크 대상 파일로 저장', click: () => wc.downloadURL(p.linkURL) },
      { label: '🕸 이 링크부터 크롤링…', click: () => toUI('ui:crawl-url', p.linkURL) },
      { label: '링크 주소 복사', click: () => clipboard.writeText(p.linkURL) },
      { type: 'separator' }
    )
  }
  if (p.hasImageContents && p.srcURL) {
    items.push(
      {
        label: '이미지를 새 탭에서 열기',
        click: () => tabs.create(p.srcURL, tabs.workspace, true)
      },
      { label: '이미지 주소 복사', click: () => clipboard.writeText(p.srcURL) },
      { type: 'separator' }
    )
  }
  const sel = p.selectionText.trim()
  if (sel) {
    const short = sel.length > 20 ? `${sel.slice(0, 20)}…` : sel
    items.push(
      { label: '복사', role: 'copy' },
      { label: '🔊 선택 텍스트 읽기 (Alt+R)', click: () => void readSelection(tabId, sel) },
      {
        label: '🤖 AI',
        submenu: [
          { label: '🌐 번역', click: () => askAi('translate', 'text', sel) },
          { label: '📝 요약', click: () => askAi('summarize', 'text', sel) },
          { label: '💡 쉽게 설명', click: () => askAi('explain', 'text', sel) },
          { label: '🗂 정리 노트', click: () => askAi('organize', 'text', sel) },
          { label: '📚 용어 사전', click: () => askAi('glossary', 'text', sel) },
          { label: '✍ 교정', click: () => askAi('proofread', 'text', sel) },
          { label: '💬 이 내용에 대해 질문…', click: () => askAi(null, 'text', sel) }
        ]
      },
      {
        label: '🗒 메모로 저장',
        click: () =>
          core('/notes', {
            method: 'POST',
            body: { url: wc.getURL(), title: wc.getTitle(), quote: sel, body: '(선택 인용)' }
          })
            .then(() => toast('메모에 저장했습니다'))
            .catch((e) => toast(e.message))
      },
      { label: `"${short}" 검색`, click: () => tabs.create(sel) },
      { type: 'separator' }
    )
  }
  if (p.isEditable) {
    items.push(
      { label: '잘라내기', role: 'cut' },
      { label: '붙여넣기', role: 'paste' },
      { label: '모두 선택', role: 'selectAll' },
      { type: 'separator' }
    )
  }
  items.push(
    {
      label: '뒤로',
      enabled: wc.navigationHistory.canGoBack(),
      click: () => wc.navigationHistory.goBack()
    },
    { label: '새로고침', click: () => wc.reload() },
    { label: 'PiP로 보기 (Alt+P)', click: () => void forcePip(tabId) },
    { type: 'separator' },
    { label: '📝 페이지 AI 요약 (Alt+S)', click: () => askAi('summarize', 'page') },
    { label: '🌐 페이지 번역 (Alt+T)', click: () => void translateActivePage('bilingual') },
    { label: '📖 리더 모드 (F9)', click: () => toUI('ui:reader') },
    { label: '💾 페이지 저장', submenu: saveMenuItems() },
    { label: '🕸 이 페이지 크롤링·일괄 다운로드…', click: () => toUI('ui:panel', 'crawl') },
    { type: 'separator' },
    { label: '외부 브라우저로 열기', click: () => void shell.openExternal(wc.getURL()) },
    { type: 'separator' },
    { label: '검사 (개발자 도구)', click: () => wc.inspectElement(p.x, p.y) }
  )
  Menu.buildFromTemplate(items).popup({ window: win })
}

// ───────────────────────── 창 · IPC ─────────────────────────
function createWindow(): void {
  win = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 500,
    show: false,
    title: 'OmniBrowser',
    icon: appIcon, // 작업 표시줄·창 아이콘 (개발 모드에서도 Electron 기본 아이콘 대신 OmniBrowser 아이콘)
    backgroundColor: '#f5f5f5',
    webPreferences: { preload: join(__dirname, '../preload/index.js'), sandbox: true }
  })
  win.on('ready-to-show', () => win.show())
  // 창을 닫기 직전(탭이 아직 살아 있을 때) 세션 저장 — 최대 1.5초 대기
  let sessionSaved = false
  win.on('close', (e) => {
    if (sessionSaved) return
    e.preventDefault()
    void Promise.race([saveSession('quit'), new Promise((r) => setTimeout(r, 1500))]).finally(
      () => {
        sessionSaved = true
        win.close()
      }
    )
  })
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) tabs.create(url) // UI(AI 답변·리더 등)의 링크는 새 탭으로
    return { action: 'deny' }
  })
  win.webContents.on('will-navigate', (e) => e.preventDefault()) // UI 창 자체는 다른 주소로 이동 금지
  win.webContents.on('before-input-event', (e, input) => onKey(input, e))
  const devUrl = is.dev ? (process.env['ELECTRON_RENDERER_URL'] ?? null) : null
  if (devUrl) void win.loadURL(devUrl)
  else void win.loadFile(join(__dirname, '../renderer/index.html'))

  tabs = new TabManager(win, {
    startUrl: () => startUrl,
    onState: (state) => {
      toUI('tabs:state', state)
      scheduleSave()
    },
    onVisit: (t) => {
      core('/history', {
        method: 'POST',
        body: { workspace_id: t.workspaceId, url: t.url, title: t.title }
      }).catch(() => {}) // Core가 준비 전이면 조용히 건너뜀
    },
    onFound: (r) => toUI('find:result', r),
    onKey,
    onContextMenu,
    onDomReady: (id, wc) => void onDomReady(id, wc),
    onCreated: (wc) => emulateTab(wc, uaMode, currentUA()),
    onClosed: (id) => forgetDark(id),
    prepareSession: (partition) =>
      void setupSession(partition, {
        getWin: () => win,
        onDownload: (item) => downloads.track(item),
        onCreated: (ses: Session) => {
          applyUserAgent(ses, uaMode, currentUA())
          if (settingsCache['privacy.adblock']) void setAdblock(true, [ses]).catch(() => {})
        }
      })
  })
  overlay = createOverlay(win, devUrl)
  reader = new ReadAloud(toUI, toast)
  ai = new AiRunner(toUI)
  downloads = new DownloadManager((list) => toUI('downloads:state', list), toast)
}

/** UI 전용 invoke 핸들러 등록 (보낸 쪽 검사 포함) */
function handleUI<A extends unknown[]>(channel: string, fn: (...args: A) => unknown): void {
  ipcMain.handle(channel, (e, ...args) => {
    assertUI(e)
    return fn(...(args as A))
  })
}

function registerIpc(): void {
  // ── UI → Main: 탭·탐색 ──
  handleUI('core:get-status', () => getCoreStatus())
  handleUI('tabs:list', () => ({
    list: tabs.list(),
    activeId: tabs.active,
    workspaceId: tabs.workspace
  }))
  handleUI('tabs:create', (url?: string) => tabs.create(url ?? startUrl))
  handleUI('tabs:activate', (id: number) => tabs.activate(id))
  handleUI('tabs:close', (id: number) => tabs.close(id))
  handleUI('tabs:mute', (id: number) => {
    const wc = tabs.wc(id)
    wc?.setAudioMuted(!wc.isAudioMuted())
    toUI('tabs:state', { list: tabs.list(), activeId: tabs.active, workspaceId: tabs.workspace })
  })
  handleUI('tabs:set-covered', (covered: boolean) => tabs.setCovered(covered))
  handleUI('nav:go', (id: number, input: string) => tabs.navigate(id, input))
  handleUI('split:set-bounds', (b: Rectangle) => tabs.setBounds(b))
  handleUI('cmd:run', (cmd: string) => run(cmd))
  handleUI('overlay:show', () => overlay.show())
  handleUI('overlay:hide', () => overlay.hide())

  // ── 페이지 내 검색 ──
  handleUI('find:query', (text: string, forward: boolean, findNext: boolean) => {
    const wc = tabs.wc(tabs.active)
    if (wc && text) wc.findInPage(text, { forward, findNext })
  })
  handleUI('find:stop', () => tabs.wc(tabs.active)?.stopFindInPage('clearSelection'))

  // ── 미디어 · TTS ──
  handleUI('media:set-rate', (rate: number) => {
    if (tabs.active !== null) tabs.sendToFrames(tabs.active, 'media:set-rate', rate)
  })
  handleUI('tts:read', () => readSelection(tabs.active))
  handleUI('tts:stop', () => reader.stop())

  // ── Core 데이터 (UI는 토큰을 모르므로 Main이 대신 호출) ──
  handleUI('history:search', (q: string) =>
    coreJson(`/history?q=${encodeURIComponent(q)}&workspace_id=${tabs.workspace}&limit=8`)
  )
  handleUI('bookmarks:list', () => coreJson('/bookmarks'))
  handleUI('bookmarks:toggle', () => toggleBookmark())
  handleUI('bookmarks:remove', async (id: string) => {
    await core(`/bookmarks/${id}`, { method: 'DELETE' })
    toUI('bookmarks:changed')
  })
  handleUI('settings:get', () => coreJson('/settings'))
  handleUI('settings:set', async (key: string, value: unknown) => {
    await core(`/settings/${encodeURIComponent(key)}`, { method: 'PUT', body: { value } })
    settingsCache[key] = value
    if (key === 'start.url' && typeof value === 'string') startUrl = value
    if (key === 'browser.user_agent' || key === 'browser.user_agent_custom') {
      if (key === 'browser.user_agent') uaMode = value as UaMode
      else uaCustom = String(value ?? '')
      reapplyUA()
      blockedShown.clear()
      toast('사이트 호환 모드를 바꿨습니다 — 페이지를 새로고침하세요')
    }
    if (key === 'privacy.adblock') {
      await setAdblock(Boolean(value), allSessions())
      toast(value ? '🛡 광고·추적기 차단 켜짐' : '광고 차단 꺼짐')
    }
  })
  handleUI('secrets:get', (name: string) => coreJson(`/secrets/${name}`))
  handleUI('secrets:set', (name: string, value: string) =>
    coreJson(`/secrets/${name}`, { method: 'PUT', body: { value } })
  )
  handleUI('secrets:delete', (name: string) => coreJson(`/secrets/${name}`, { method: 'DELETE' }))

  // ── 워크스페이스 ──
  handleUI('ws:list', () => coreJson('/workspaces'))
  handleUI('ws:switch', (id: string) => tabs.switchWorkspace(id))
  handleUI('ws:create', async (name: string, color: string) => {
    const w = await coreJson<{ id: string }>('/workspaces', {
      method: 'POST',
      body: { name, color }
    })
    tabs.switchWorkspace(w.id)
    return w
  })
  handleUI('ws:delete', async (id: string, name: string) => {
    const { response } = await dialog.showMessageBox(win, {
      type: 'warning',
      buttons: ['삭제', '취소'],
      defaultId: 1,
      cancelId: 1,
      message: `워크스페이스 "${name}"을(를) 삭제할까요?`,
      detail: '열린 탭이 닫히고, 이 워크스페이스의 쿠키·로그인 정보가 모두 지워집니다.'
    })
    if (response !== 0) return false
    if (tabs.workspace === id) tabs.switchWorkspace('default')
    tabs.closeWorkspace(id)
    await session.fromPartition(`persist:ws-${id}`).clearStorageData()
    await core(`/workspaces/${id}`, { method: 'DELETE' })
    return true
  })

  // ── AI ──
  handleUI('ai:providers', () => coreJson('/ai/providers'))
  handleUI('ai:presets', () => coreJson('/ai/presets'))
  handleUI('ai:models', (provider: string, refresh = false) =>
    coreJson(`/ai/models?provider=${provider}&refresh=${refresh}`)
  )
  handleUI('ai:usage', () => coreJson('/ai/usage'))
  handleUI('ai:run', (req: AiRequest) => runAi(req))
  handleUI('ai:stop', (jobId: string) => ai.stop(jobId))
  handleUI('ai:save-md', async (text: string, title: string) => {
    const r = await dialog.showSaveDialog(win, {
      defaultPath: join(app.getPath('downloads'), `${safeFileName(title || 'AI 결과')}.md`),
      filters: [{ name: 'Markdown', extensions: ['md'] }]
    })
    if (!r.canceled && r.filePath) {
      await writeFile(r.filePath, text, 'utf8')
      toast(`저장: ${r.filePath}`)
    }
  })

  // ── 페이지 도구 ──
  handleUI('page:extract', async () => {
    const wc = tabs.wc(tabs.active)
    if (!wc || !wc.getURL().startsWith('http')) throw new Error('웹페이지에서만 사용할 수 있습니다')
    return extractPage(wc)
  })
  handleUI('page:translate', (mode: 'bilingual' | 'replace') => translateActivePage(mode))
  handleUI('page:save', (fmt: SaveFormat) => doSave(fmt))
  handleUI('tts:text', (text: string) => reader.read(text))
  handleUI('clipboard:write', (text: string) => clipboard.writeText(text))

  // ── 크롤러 ──
  handleUI('crawl:file-types', () => coreJson('/crawl/file-types'))
  handleUI('crawl:start', (req: CrawlRequest) =>
    startCrawl(
      { ...req, workspaceId: tabs.workspace },
      currentUA(),
      String(settingsCache['crawl.output_dir'] ?? ''),
      fetchServiceInfo
    )
  )
  handleUI('crawl:jobs', () => coreJson('/crawl/jobs'))
  handleUI('crawl:status', (id: string, files: boolean) => crawlStatus(id, files))
  handleUI('crawl:download', (id: string, urls: string[]) =>
    coreJson(`/crawl/${id}/download`, { method: 'POST', body: { urls } })
  )
  handleUI('crawl:cancel', (id: string) => {
    cancelPdf(id)
    return coreJson(`/crawl/${id}/cancel`, { method: 'POST' })
  })
  handleUI('crawl:open', (path: string) => shell.openPath(path))
  handleUI('crawl:choose-dir', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] })
    return r.canceled ? null : r.filePaths[0]
  })

  // ── 다운로드 ──
  handleUI('downloads:list', () => downloads.list())
  handleUI('downloads:open', (id: number) => {
    const d = downloads.get(id)
    if (d?.path) void shell.openPath(d.path)
  })
  handleUI('downloads:show', (id: number) => {
    const d = downloads.get(id)
    if (d?.path) shell.showItemInFolder(d.path)
  })
  handleUI('downloads:cancel', (id: number) => downloads.cancel(id))
  handleUI('downloads:clear', () => downloads.clearFinished())

  // ── 메모 · 기록 ──
  handleUI('notes:list', (url?: string, q?: string) => {
    const qs = new URLSearchParams()
    if (url) qs.set('url', url)
    if (q) qs.set('q', q)
    return coreJson(`/notes?${qs}`)
  })
  handleUI('notes:add', (note: { url: string; title: string; body: string; quote?: string }) =>
    coreJson('/notes', { method: 'POST', body: note })
  )
  handleUI('notes:delete', (id: string) => coreJson(`/notes/${id}`, { method: 'DELETE' }))
  handleUI('notes:export', async () => {
    const md = await (await core('/notes/export')).text()
    const r = await dialog.showSaveDialog(win, {
      defaultPath: join(app.getPath('downloads'), 'OmniBrowser 메모.md'),
      filters: [{ name: 'Markdown', extensions: ['md'] }]
    })
    if (!r.canceled && r.filePath) await writeFile(r.filePath, md, 'utf8')
  })
  handleUI('history:list', (q: string) =>
    coreJson(`/history?q=${encodeURIComponent(q)}&workspace_id=${tabs.workspace}&limit=200`)
  )
  handleUI('history:clear', async () => {
    const { response } = await dialog.showMessageBox(win, {
      type: 'warning',
      buttons: ['모두 삭제', '취소'],
      defaultId: 1,
      cancelId: 1,
      message: '방문 기록을 모두 삭제할까요?'
    })
    if (response === 0) await core('/history', { method: 'DELETE' })
    return response === 0
  })
  handleUI('browsing:clear', async () => {
    const { response } = await dialog.showMessageBox(win, {
      type: 'warning',
      buttons: ['삭제', '취소'],
      defaultId: 1,
      cancelId: 1,
      message: '현재 워크스페이스의 쿠키·캐시·사이트 데이터를 삭제할까요?',
      detail: '이 워크스페이스에서 로그인한 사이트는 모두 로그아웃됩니다.'
    })
    if (response !== 0) return false
    const ses = session.fromPartition(`persist:ws-${tabs.workspace}`)
    await ses.clearStorageData()
    await ses.clearCache()
    toast('사이트 데이터를 삭제했습니다')
    return true
  })
  handleUI('menu:more', () => moreMenu())

  // ── 사이트 호환 ──
  handleUI('ua:info', () => ({
    mode: uaMode,
    ua: currentUA(),
    chrome: chromeVersion(),
    electron: ELECTRON_UA
  }))
  handleUI('ua:refresh-version', async () => {
    await refreshChromeVersion(true)
    reapplyUA()
    return { chrome: chromeVersion(), ua: currentUA() }
  })
  handleUI('ua:retry', async (mode: UaMode) => {
    uaMode = mode
    await core('/settings/browser.user_agent', { method: 'PUT', body: { value: mode } })
    settingsCache['browser.user_agent'] = mode
    reapplyUA()
    blockedShown.clear()
    tabs.wc(tabs.active)?.reloadIgnoringCache()
  })

  // ── 읽어주기(TTS) 모델·폴더 ──
  handleUI('tts:voices', (provider: string) => coreJson(`/tts/voices?provider=${provider}`))
  handleUI('tts:models', (provider: string, refresh: boolean) =>
    coreJson(`/tts/models?provider=${provider}&refresh=${refresh}`)
  )
  handleUI('tts:local-status', (dir?: string, model?: string) => {
    const qs = new URLSearchParams()
    if (dir !== undefined && dir !== null) qs.set('dir', dir)
    if (model) qs.set('model', model)
    return coreJson(`/tts/local/status?${qs}`)
  })
  handleUI('tts:local-download', (dir?: string, model?: string) =>
    coreJson('/tts/local/download', { method: 'POST', body: { dir, model } })
  )
  handleUI('tts:local-copy', (dir: string) =>
    coreJson('/tts/local/copy', { method: 'POST', body: { dir } })
  )
  handleUI('tts:local-reload', () => coreJson('/tts/local/reload', { method: 'POST' }))
  handleUI('dialog:choose-dir', async (title?: string) => {
    const r = await dialog.showOpenDialog(win, {
      title,
      properties: ['openDirectory', 'createDirectory']
    })
    return r.canceled ? null : r.filePaths[0]
  })
  handleUI('ai:refresh-models', () => coreJson('/ai/models/refresh', { method: 'POST' }))

  // ── 탭(웹페이지) → Main ──
  // 어느 프레임에서 누른 단축키든 → 같은 탭의 모든 프레임에 전달 (영상이 iframe 안에 있어도 동작)
  ipcMain.on('media:key', (e, key: { code: string; shift: boolean }) => {
    assertTab(e)
    tabs.sendToFrames(e.sender.id, 'media:key', key)
  })
  ipcMain.on('media:state', (e, state: { rate: number; playing: boolean; user: boolean }) => {
    assertTab(e)
    if (e.sender.id === tabs.active) toUI('media:state', state) // → 상태바
    const origin = originOf(e.sender.getURL()) // 최상위 페이지 기준 (iframe 출처 아님)
    if (state.user && origin) rememberSiteRate(origin, state.rate)
  })
  ipcMain.handle('media:get-site-rate', async (e) => {
    assertTab(e)
    const origin = originOf(e.sender.getURL())
    if (!origin) return null
    try {
      const s = await coreJson<Record<string, unknown>>(
        `/site-settings?origin=${encodeURIComponent(origin)}`
      )
      return typeof s['media.rate'] === 'number' ? s['media.rate'] : null
    } catch {
      return null // 설정 없음 / Core 준비 전 → 사이트 기본 동작
    }
  })
  ipcMain.handle('media:get-favorite-rate', async (e) => {
    assertTab(e)
    try {
      const s = await coreJson<Record<string, unknown>>('/settings')
      return Number(s['media.favorite_rate']) || 1.5
    } catch {
      return 1.5
    }
  })
}

// 두 번 실행하면 새로 띄우지 않고 기존 창을 앞으로 (같은 DB 동시 접근 방지)
const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  // 진단용 기록: 이미 실행 중인 OmniBrowser가 있으면 그 창을 앞으로 가져오고 이 프로세스는 조용히 끝남
  log.warn(
    '[startup] 다른 OmniBrowser가 이미 실행 중 → 기존 창으로 전환하고 종료',
    app.getPath('userData')
  )
  app.quit()
}
app.on('second-instance', () => {
  if (win?.isMinimized()) win.restore()
  win?.focus()
})

app.whenReady().then(() => {
  if (!gotLock) return
  // 작업 표시줄 그룹 ID. @electron-toolkit의 setAppUserModelId는 개발 모드에서 electron.exe 경로를 써서
  // 같은 템플릿으로 만든 다른 Electron 앱과 아이콘·그룹이 섞여 보였다 → 항상 고유 ID 사용
  if (process.platform === 'win32') app.setAppUserModelId('com.omnibrowser.app')
  if (process.platform !== 'darwin') Menu.setApplicationMenu(null) // 단축키는 commands.ts에서 직접 처리
  registerIpc()
  createWindow()
  onCoreStatus((s) => toUI('core:status', s))
  void startFetchService(() => chromeHeaders(uaMode)) // 크롤러용 브라우저 네트워크 가져오기
  void refreshChromeVersion().then((changed) => changed && reapplyUA()) // 최신 Chrome 버전 확인
  void startCore() // UI는 먼저 띄우고 Core는 병렬로 시작 (상태바에 '연결 중…' 표시)
  void restoreSession()
})

app.on('window-all-closed', () => app.quit())
app.on('will-quit', () => {
  stopFetchService()
  stopCore()
})
