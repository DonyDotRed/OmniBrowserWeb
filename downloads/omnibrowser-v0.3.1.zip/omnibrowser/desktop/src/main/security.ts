/** 워크스페이스(파티션)별 세션 설정: 권한 요청 확인, 다운로드 추적, 사용자 에이전트 */
import { dialog, session, type BrowserWindow, type DownloadItem, type Session } from 'electron'

const configured = new Map<string, Session>()
const decisions = new Map<string, boolean>() // "출처|권한" → 이번 실행 동안 기억

// 사용자에게 물어봐야 하는 민감한 권한 (나머지: 전체 화면, 클립보드 쓰기 등은 허용)
const ASK: Record<string, string> = {
  media: '카메라·마이크 사용',
  geolocation: '위치 정보',
  notifications: '알림 표시',
  'clipboard-read': '클립보드 읽기',
  midiSysex: 'MIDI 장치 제어',
  'display-capture': '화면 녹화·공유',
  hid: 'HID 장치 접근',
  serial: '시리얼 장치 접근',
  usb: 'USB 장치 접근',
  openExternal: '외부 프로그램 열기'
}

function originOf(url: string): string {
  try {
    return new URL(url).origin
  } catch {
    return url
  }
}

export interface SessionDeps {
  getWin: () => BrowserWindow
  onDownload: (item: DownloadItem) => void
  onCreated: (ses: Session) => void // UA·광고 차단 등 공통 설정 적용
}

export function allSessions(): Session[] {
  return [...configured.values()]
}

export function setupSession(partition: string, deps: SessionDeps): Session {
  const existing = configured.get(partition)
  if (existing) return existing
  const ses = session.fromPartition(partition)
  configured.set(partition, ses)

  ses.setPermissionRequestHandler((_wc, permission, callback, details) => {
    const label = ASK[permission]
    if (!label) return callback(true)
    const key = `${originOf(details.requestingUrl)}|${permission}`
    const saved = decisions.get(key)
    if (saved !== undefined) return callback(saved)
    void dialog
      .showMessageBox(deps.getWin(), {
        type: 'question',
        buttons: ['허용', '차단'],
        defaultId: 1,
        cancelId: 1,
        message: `${originOf(details.requestingUrl)} 사이트가 권한을 요청합니다`,
        detail: `요청: ${label}\n(이번 실행 동안 기억합니다)`
      })
      .then(({ response }) => {
        decisions.set(key, response === 0)
        callback(response === 0)
      })
  })
  ses.on('will-download', (_e, item) => deps.onDownload(item))
  deps.onCreated(ses)
  return ses
}
