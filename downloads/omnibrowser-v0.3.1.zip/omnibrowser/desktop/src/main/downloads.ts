/** 다운로드 관리 (CNV-02): 진행률·열기·폴더 보기·취소 */
import type { DownloadItem } from 'electron'

export interface DownloadInfo {
  id: number
  filename: string
  url: string
  path: string
  state: string // progressing | completed | cancelled | interrupted
  received: number
  total: number
  started: number
}

export class DownloadManager {
  private items = new Map<number, { info: DownloadInfo; item: DownloadItem }>()
  private seq = 0
  private timer: NodeJS.Timeout | undefined

  constructor(
    private emit: (list: DownloadInfo[]) => void,
    private toast: (msg: string) => void
  ) {}

  track(item: DownloadItem): void {
    const id = ++this.seq
    const info: DownloadInfo = {
      id,
      filename: item.getFilename(),
      url: item.getURL(),
      path: '',
      state: 'progressing',
      received: 0,
      total: item.getTotalBytes(),
      started: Date.now()
    }
    this.items.set(id, { info, item })
    item.on('updated', (_e, state) => {
      info.state = state === 'interrupted' ? 'interrupted' : 'progressing'
      info.received = item.getReceivedBytes()
      info.total = item.getTotalBytes()
      info.path = item.getSavePath()
      this.schedule()
    })
    item.once('done', (_e, state) => {
      info.state = state
      info.received = item.getReceivedBytes()
      info.path = item.getSavePath()
      if (state === 'completed') this.toast(`⬇ 다운로드 완료: ${info.filename}`)
      else if (state === 'interrupted') this.toast(`⬇ 다운로드 실패: ${info.filename}`)
      this.schedule()
    })
    this.schedule()
  }

  list(): DownloadInfo[] {
    return [...this.items.values()].map((x) => x.info).reverse()
  }

  get(id: number): DownloadInfo | undefined {
    return this.items.get(id)?.info
  }

  cancel(id: number): void {
    this.items.get(id)?.item.cancel()
  }

  clearFinished(): void {
    for (const [id, x] of this.items) if (x.info.state !== 'progressing') this.items.delete(id)
    this.schedule()
  }

  private schedule(): void {
    if (this.timer) return
    this.timer = setTimeout(() => {
      this.timer = undefined
      this.emit(this.list())
    }, 300)
  }
}
