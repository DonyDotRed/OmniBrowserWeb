/**
 * Python Core 실행·감시·호출.
 * - 개발: 저장소 루트에서 `uv run --no-sync omni-core ...`
 * - 배포: resources/core/omni-core(.exe) (PyInstaller 결과물)
 */
import { app } from 'electron'
import { execFile, spawn, type ChildProcess } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { createServer } from 'node:net'
import { join, resolve } from 'node:path'
import log from 'electron-log/main'

export type CoreStatus = 'stopped' | 'starting' | 'ready' | 'failed'

const token = randomBytes(32).toString('hex') // 실행할 때마다 새 256비트 토큰 (UI에는 절대 전달하지 않음)
let child: ChildProcess | null = null
let heartbeat: NodeJS.Timeout | null = null
let port = 0
let status: CoreStatus = 'stopped'
let lastError = ''
const listeners = new Set<(s: CoreStatus) => void>()

export function onCoreStatus(fn: (s: CoreStatus) => void): () => void {
  listeners.add(fn)
  return () => listeners.delete(fn)
}

export function getCoreStatus(): { status: CoreStatus; port: number; error: string } {
  return { status, port, error: lastError }
}

function setStatus(s: CoreStatus, error = ''): void {
  status = s
  lastError = error
  listeners.forEach((fn) => fn(s))
}

/** OS에게 빈 포트를 하나 받아 온다 (포트 충돌 방지) */
function freePort(): Promise<number> {
  return new Promise((ok, fail) => {
    const srv = createServer()
    srv.unref()
    srv.on('error', fail)
    srv.listen(0, '127.0.0.1', () => {
      const addr = srv.address()
      const p = typeof addr === 'object' && addr ? addr.port : 0
      srv.close(() => ok(p))
    })
  })
}

function coreCommand(): { cmd: string; args: string[]; cwd: string } {
  const dataDir = join(app.getPath('userData'), 'core')
  const common = ['--port', String(port), '--data-dir', dataDir]
  if (app.isPackaged) {
    const dir = join(process.resourcesPath, 'core')
    const exe = process.platform === 'win32' ? 'omni-core.exe' : 'omni-core'
    return { cmd: join(dir, exe), args: common, cwd: dir }
  }
  // 개발 모드: app.getAppPath() = desktop 폴더 → 그 상위가 저장소 루트(pyproject.toml 위치)
  const root = resolve(app.getAppPath(), '..')
  const uv = process.env.UV ?? 'uv' // `uv run`으로 실행되면 UV 환경 변수에 uv 경로가 들어 있음
  return { cmd: uv, args: ['run', '--no-sync', 'omni-core', ...common], cwd: root }
}

async function waitForHealth(timeoutMs = 60_000): Promise<void> {
  const until = Date.now() + timeoutMs
  while (Date.now() < until) {
    if (!child || child.exitCode !== null) throw new Error('Core 프로세스가 시작 직후 종료됨')
    try {
      const r = await fetch(`http://127.0.0.1:${port}/health`)
      if (r.ok) return
    } catch {
      // 아직 준비 안 됨 → 잠시 후 재시도
    }
    await new Promise((r) => setTimeout(r, 300))
  }
  throw new Error(`Core가 ${timeoutMs / 1000}초 안에 응답하지 않음`)
}

export async function startCore(): Promise<void> {
  if (child) return
  setStatus('starting')
  port = await freePort()
  const { cmd, args, cwd } = coreCommand()
  log.info('[core] start:', cmd, args.join(' '))
  child = spawn(cmd, args, {
    cwd,
    windowsHide: true, // 검은 콘솔 창 숨김
    env: {
      ...process.env,
      OMNI_CORE_TOKEN: token,
      OMNI_WATCHDOG: 'true', // heartbeat가 끊기면 Core 스스로 종료
      PYTHONUTF8: '1', // Windows 한글 깨짐 방지
      PYTHONUNBUFFERED: '1' // 로그 즉시 출력
    }
  })
  child.stdout?.on('data', (d) => log.info('[core]', String(d).trimEnd()))
  child.stderr?.on('data', (d) => log.info('[core]', String(d).trimEnd())) // uvicorn은 stderr로 로그 출력
  child.on('exit', (code) => {
    log.warn('[core] exit', code)
    child = null
    if (heartbeat) clearInterval(heartbeat)
    if (status !== 'stopped') setStatus('failed', `Core 종료 (코드 ${code})`)
  })
  child.on('error', (e) => log.error('[core] spawn error', e)) // 예: uv를 찾지 못함

  try {
    await waitForHealth()
  } catch (e) {
    setStatus(
      'failed',
      `${(e as Error).message} → 'uv run poe core'로 단독 실행해 오류를 확인하세요`
    )
    return
  }
  heartbeat = setInterval(() => {
    core('/health/heartbeat', { method: 'POST' }).catch(() => {})
  }, 10_000)
  setStatus('ready')
}

export function stopCore(): void {
  setStatus('stopped')
  if (heartbeat) clearInterval(heartbeat)
  if (!child?.pid) return
  if (process.platform === 'win32') {
    // /T: uv → python 자식 프로세스까지 함께 종료
    execFile('taskkill', ['/pid', String(child.pid), '/T', '/F'], () => {})
  } else {
    child.kill('SIGTERM')
  }
  child = null
}

/** Core API 호출 도우미. 오류 시 Core가 준 message + hint로 예외를 만든다. */
export interface CoreOpts {
  method?: string
  body?: unknown
  signal?: AbortSignal
}

export async function core(path: string, opts: CoreOpts = {}): Promise<Response> {
  if (status !== 'ready' && path !== '/health/heartbeat') throw new Error('Core 준비 전입니다')
  const res = await fetch(`http://127.0.0.1:${port}${path}`, {
    method: opts.method ?? 'GET',
    headers: { 'Content-Type': 'application/json', 'X-Omni-Token': token },
    body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
    signal: opts.signal
  })
  if (!res.ok) {
    const err = (await res.json().catch(() => null))?.error
    throw new Error(err ? `${err.message} → ${err.hint}` : `Core 오류 (${res.status})`)
  }
  return res
}

/** JSON 응답을 바로 돌려주는 편의 함수 */
export async function coreJson<T>(path: string, opts: CoreOpts = {}): Promise<T> {
  return (await core(path, opts)).json() as Promise<T>
}

/** Core가 준비(또는 실패)될 때까지 기다린다 */
export function whenCoreSettled(): Promise<CoreStatus> {
  if (status === 'ready' || status === 'failed') return Promise.resolve(status)
  return new Promise((ok) => {
    const off = onCoreStatus((s) => {
      if (s === 'ready' || s === 'failed') {
        off()
        ok(s)
      }
    })
  })
}
