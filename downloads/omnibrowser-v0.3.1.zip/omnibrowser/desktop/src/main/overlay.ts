/**
 * 오버레이 뷰: 명령 팔레트·드롭다운·캡처 영역 선택처럼 "웹페이지 위에" 떠야 하는 UI.
 * WebContentsView(탭)는 항상 UI 창 위에 그려지므로, UI를 투명한 별도 뷰로 한 장 더 올린다.
 */
import { WebContentsView, type BrowserWindow, type WebContents } from 'electron'
import { join } from 'node:path'

export interface Overlay {
  webContents: WebContents
  show(): void
  hide(): void
}

export function createOverlay(win: BrowserWindow, rendererUrl: string | null): Overlay {
  const view = new WebContentsView({
    webPreferences: { preload: join(__dirname, '../preload/index.js'), sandbox: true }
  })
  view.setBackgroundColor('#00000000') // 완전 투명
  view.setVisible(false)
  win.contentView.addChildView(view)
  if (rendererUrl) void view.webContents.loadURL(`${rendererUrl}#/overlay`)
  else
    void view.webContents.loadFile(join(__dirname, '../renderer/index.html'), { hash: '/overlay' })

  return {
    webContents: view.webContents,
    show(): void {
      win.contentView.addChildView(view) // 이미 있는 뷰를 다시 추가하면 "맨 위"로 올라감
      const [width, height] = win.getContentSize()
      view.setBounds({ x: 0, y: 0, width, height })
      view.setVisible(true)
      view.webContents.focus()
    },
    hide(): void {
      view.setVisible(false)
      win.webContents.focus()
    }
  }
}
