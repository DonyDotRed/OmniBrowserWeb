/**
 * 현재 페이지 도구: 본문 추출(리더 모드·AI 입력), 페이지 저장(PDF·PNG 전체·MHTML·Markdown),
 * 다크 모드, 페이지 제자리 번역(원문+번역 대역 / 번역만).
 */
import { app, clipboard, dialog, type BrowserWindow, type WebContents } from 'electron'
import { readFileSync } from 'node:fs'
import { writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { coreJson } from './core-process'

const EXTRACT_WORLD = 1001 // 격리된 실행 공간: 웹페이지의 변수·보안 정책과 섞이지 않음
const TRANSLATE_WORLD = 1002

let readabilitySrc: string | null = null
function readability(): string {
  if (!readabilitySrc) {
    readabilitySrc = readFileSync(require.resolve('@mozilla/readability/Readability.js'), 'utf8')
  }
  return readabilitySrc
}

export interface PageContent {
  title: string
  byline: string
  html: string // 본문 HTML (리더 모드용, 신뢰할 수 없는 내용 → UI에서 격리된 iframe으로만 표시)
  text: string // 본문 글자 (AI·TTS용)
  selection: string
  url: string
}

export async function extractPage(wc: WebContents): Promise<PageContent> {
  const code = `${readability()}
  ;(() => {
    let art = null
    try { art = new Readability(document.cloneNode(true), { charThreshold: 300 }).parse() } catch (e) {}
    const body = document.body ? document.body.innerText : ''
    const text = ((art && art.textContent) || body).replace(/[ \\t]+\\n/g, '\\n').replace(/\\n{3,}/g, '\\n\\n').trim()
    return { title: (art && art.title) || document.title, byline: (art && art.byline) || '',
             html: (art && art.content) || '', text, selection: String(getSelection() || ''), url: location.href }
  })()`
  return (await wc.executeJavaScriptInIsolatedWorld(EXTRACT_WORLD, [{ code }])) as PageContent
}

export function safeFileName(name: string): string {
  const cleaned = [...(name || 'page')].filter((c) => c.charCodeAt(0) >= 32).join('') // 제어 문자 제거
  return (
    cleaned
      .replace(/[<>:"/\\|?*]/g, '_')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 100) || 'page'
  )
}

async function askPath(
  win: BrowserWindow,
  title: string,
  ext: string,
  label: string
): Promise<string | null> {
  const r = await dialog.showSaveDialog(win, {
    title: `${label}(으)로 저장`,
    defaultPath: join(app.getPath('downloads'), `${safeFileName(title)}.${ext}`),
    filters: [{ name: label, extensions: [ext] }]
  })
  return r.canceled || !r.filePath ? null : r.filePath
}

/** 긴 페이지 전체를 한 장의 PNG로 (DevTools 프로토콜 사용, 실패 시 보이는 영역만) */
export async function captureFullPage(wc: WebContents): Promise<Buffer> {
  const dbg = wc.debugger
  let attached = false // 사이트 호환 기능이 이미 연결해 두었으면 그대로 사용하고 끊지 않음
  try {
    if (!dbg.isAttached()) {
      dbg.attach('1.3')
      attached = true
    }
    const m = (await dbg.sendCommand('Page.getLayoutMetrics')) as {
      cssContentSize: { width: number; height: number }
    }
    const width = Math.ceil(m.cssContentSize.width)
    const height = Math.min(Math.ceil(m.cssContentSize.height), 20000) // 너무 긴 페이지는 20000px까지
    const r = (await dbg.sendCommand('Page.captureScreenshot', {
      format: 'png',
      captureBeyondViewport: true,
      clip: { x: 0, y: 0, width, height, scale: 1 }
    })) as { data: string }
    return Buffer.from(r.data, 'base64')
  } catch {
    return (await wc.capturePage()).toPNG() // 개발자 도구가 열려 있는 등 → 보이는 영역만
  } finally {
    if (attached) dbg.detach()
  }
}

export type SaveFormat = 'pdf' | 'png' | 'mhtml' | 'html' | 'md' | 'md-copy' | 'shot-copy'

export async function savePage(
  win: BrowserWindow,
  wc: WebContents,
  fmt: SaveFormat
): Promise<string> {
  const title = wc.getTitle()
  if (fmt === 'shot-copy') {
    clipboard.writeImage(await wc.capturePage())
    return '보이는 화면을 클립보드에 복사했습니다'
  }
  if (fmt === 'md' || fmt === 'md-copy') {
    const page = await extractPage(wc)
    const html = page.html || (await wc.executeJavaScript('document.documentElement.outerHTML'))
    const { markdown } = await coreJson<{ markdown: string }>('/crawl/to-markdown', {
      method: 'POST',
      body: { html: `<html><body><article>${html}</article></body></html>`, url: page.url }
    })
    const md = `# ${page.title}\n\n원본: ${page.url}\n\n${markdown || page.text}`
    if (fmt === 'md-copy') {
      clipboard.writeText(md)
      return '본문을 Markdown으로 복사했습니다'
    }
    const path = await askPath(win, title, 'md', 'Markdown')
    if (!path) return ''
    await writeFile(path, md, 'utf8')
    return `저장: ${path}`
  }
  const label = { pdf: 'PDF', png: 'PNG 이미지', mhtml: '웹 보관 파일(MHTML)', html: 'HTML' }[fmt]
  const path = await askPath(win, title, fmt === 'mhtml' ? 'mhtml' : fmt, label)
  if (!path) return ''
  if (fmt === 'pdf')
    await writeFile(path, await wc.printToPDF({ printBackground: true, pageSize: 'A4' }))
  else if (fmt === 'png') await writeFile(path, await captureFullPage(wc))
  else if (fmt === 'mhtml') await wc.savePage(path, 'MHTML')
  else await wc.savePage(path, 'HTMLComplete')
  return `저장: ${path}`
}

// ───────── 다크 모드 (페이지 색 반전) ─────────
const DARK_CSS = `html{filter:invert(.92) hue-rotate(180deg)!important;background:#fff!important}
img,video,picture,canvas,iframe,svg image,[style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}`
const darkKeys = new Map<number, string>()

export async function setDark(wc: WebContents, on: boolean): Promise<void> {
  const key = darkKeys.get(wc.id)
  if (key) {
    await wc.removeInsertedCSS(key).catch(() => {})
    darkKeys.delete(wc.id)
  }
  if (on) darkKeys.set(wc.id, await wc.insertCSS(DARK_CSS))
}

export const isDark = (wc: WebContents): boolean => darkKeys.has(wc.id)
export const forgetDark = (id: number): boolean => darkKeys.delete(id)

// ───────── 페이지 제자리 번역 ─────────
const COLLECT = (maxSegments: number, skipKorean: boolean): string => `(() => {
  const S = (window.__omniTr = window.__omniTr || { next: 1, els: new Map(), orig: new Map() })
  const BLOCK = 'p,li,h1,h2,h3,h4,h5,h6,td,th,dt,dd,blockquote,figcaption,caption,summary,legend,label,div,section,article,aside,header,footer,nav'
  const SKIP = 'script,style,noscript,code,pre,textarea,input,select,svg,math,[contenteditable="true"],[translate="no"],.notranslate,.omni-tr'
  const out = []
  for (const el of document.body.querySelectorAll(BLOCK)) {
    if (out.length >= ${maxSegments}) break
    if (el.dataset.omniSeg || el.closest(SKIP)) continue
    const text = (el.innerText || '').trim()
    if (text.length < 2 || text.length > 4000 || !/\\p{L}/u.test(text)) continue
    let leaf = true
    for (const c of el.querySelectorAll(BLOCK)) { if ((c.innerText || '').trim()) { leaf = false; break } }
    if (!leaf) continue
    if (${skipKorean}) {
      const ko = (text.match(/[가-힣]/g) || []).length
      if (ko / text.length > 0.3) continue
    }
    const id = S.next++
    el.dataset.omniSeg = String(id)
    S.els.set(id, el)
    out.push({ id, text })
  }
  return out
})()`

const APPLY = (items: Record<string, string>, mode: 'bilingual' | 'replace'): string => `(() => {
  const S = window.__omniTr
  if (!S) return 0
  const items = ${JSON.stringify(items)}
  let n = 0
  for (const [id, tr] of Object.entries(items)) {
    const el = S.els.get(Number(id))
    if (!el || !el.isConnected) continue
    if (${JSON.stringify(mode)} === 'bilingual') {
      const d = document.createElement('font')
      d.className = 'omni-tr'
      d.style.cssText = 'display:block;color:#2563eb;margin-top:3px;font-size:.95em'
      d.textContent = tr
      el.appendChild(d)
    } else {
      S.orig.set(Number(id), [...el.childNodes])
      el.textContent = tr
    }
    n++
  }
  return n
})()`

const RESTORE = `(() => {
  const S = window.__omniTr
  if (!S) return false
  document.querySelectorAll('font.omni-tr').forEach((f) => f.remove())
  for (const [id, nodes] of S.orig) { const el = S.els.get(id); if (el) el.replaceChildren(...nodes) }
  for (const el of S.els.values()) delete el.dataset.omniSeg
  window.__omniTr = null
  return true
})()`

const translating = new Map<number, { cancelled: boolean }>()

export async function translatePage(
  wc: WebContents,
  opts: { lang: string; mode: 'bilingual' | 'replace'; maxSegments: number },
  progress: (done: number, total: number) => void
): Promise<string> {
  if (translating.has(wc.id)) {
    translating.get(wc.id)!.cancelled = true
    return '번역을 중지했습니다'
  }
  const state = { cancelled: false }
  translating.set(wc.id, state)
  const url = wc.getURL()
  try {
    const segs = (await wc.executeJavaScriptInIsolatedWorld(TRANSLATE_WORLD, [
      { code: COLLECT(opts.maxSegments, opts.lang === 'ko') }
    ])) as { id: number; text: string }[]
    if (!segs.length) return '번역할 새 문장이 없습니다 (이미 번역했거나 대상 언어와 같음)'
    // 한 번에 40구간·3500자 이하로 묶어 요청 (3개씩 병렬)
    const batches: { id: number; text: string }[][] = []
    let cur: { id: number; text: string }[] = []
    let chars = 0
    for (const s of segs) {
      if (cur.length >= 40 || chars + s.text.length > 3500) {
        batches.push(cur)
        cur = []
        chars = 0
      }
      cur.push(s)
      chars += s.text.length
    }
    if (cur.length) batches.push(cur)
    let done = 0
    let failed = ''
    const queue = [...batches]
    const worker = async (): Promise<void> => {
      for (let b = queue.shift(); b; b = queue.shift()) {
        if (state.cancelled || wc.isDestroyed() || wc.getURL() !== url) return
        try {
          const r = await coreJson<{ translations: Record<string, string> }>(
            '/ai/translate-segments',
            {
              method: 'POST',
              body: { segments: b, lang: opts.lang }
            }
          )
          if (!wc.isDestroyed() && wc.getURL() === url) {
            await wc.executeJavaScriptInIsolatedWorld(TRANSLATE_WORLD, [
              { code: APPLY(r.translations, opts.mode) }
            ])
          }
        } catch (e) {
          failed = (e as Error).message
          state.cancelled = true // 키 없음·한도 초과 등은 계속해도 같은 오류 → 중단
        }
        done += b.length
        progress(done, segs.length)
      }
    }
    await Promise.all([worker(), worker(), worker()])
    if (failed) return `번역 실패: ${failed}`
    return state.cancelled ? '번역을 중지했습니다' : `번역 완료 (${segs.length}개 문단)`
  } finally {
    translating.delete(wc.id)
  }
}

export async function restoreOriginal(wc: WebContents): Promise<boolean> {
  return (await wc.executeJavaScriptInIsolatedWorld(TRANSLATE_WORLD, [
    { code: RESTORE }
  ])) as boolean
}
