/**
 * 탭 = WebContentsView 하나. 진짜 탭 상태는 여기(Main)에만 있다 (7.2절 원칙).
 * 워크스페이스마다 partition이 달라 쿠키·로그인이 섞이지 않는다 (WS-01).
 */
import {
  WebContentsView,
  type BrowserWindow,
  type ContextMenuParams,
  type Event,
  type Input,
  type Rectangle,
  type WebContents
} from 'electron'
import { join } from 'node:path'

export interface TabInfo {
  id: number
  workspaceId: string
  url: string
  title: string
  favicon: string
  loading: boolean
  audible: boolean
  muted: boolean
  canGoBack: boolean
  canGoForward: boolean
  zoom: number
}

export interface TabsState {
  list: TabInfo[]
  activeId: number | null
  workspaceId: string
}

export interface SessionSnapshot {
  workspaceId: string
  tabs: { url: string; workspaceId: string; active: boolean }[]
}

interface Tab {
  view: WebContentsView
  workspaceId: string
  favicon: string
}

interface Hooks {
  startUrl: () => string
  onState: (state: TabsState) => void // → UI 'tabs:state' + 세션 자동 저장
  onVisit: (tab: TabInfo) => void // → Core 방문 기록
  onFound: (result: { active: number; matches: number }) => void // 페이지 내 검색 결과
  onKey: (input: Input, event: Event) => void // 단축키
  onContextMenu: (tabId: number, params: ContextMenuParams) => void
  onDomReady: (tabId: number, wc: WebContents) => void // 사이트별 다크 모드 등 적용
  onCreated: (wc: WebContents) => Promise<void> // 페이지를 열기 전 준비 (사이트 호환 UA 등)
  onClosed: (tabId: number) => void
  prepareSession: (partition: string) => void // 권한·다운로드 처리 등록
}

/** 주소창 입력 → URL (주소처럼 보이면 이동, 아니면 검색) */
export function toUrl(input: string): string {
  const s = input.trim()
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s) || s.startsWith('about:')) return s
  if (/^localhost(:\d+)?(\/.*)?$/.test(s)) return `http://${s}`
  if (/^[^\s]+\.[^\s]{2,}$/.test(s)) return `https://${s}`
  return `https://www.google.com/search?q=${encodeURIComponent(s)}`
}

const ZOOM_STEPS = [-3, -2, -1, -0.5, 0, 0.5, 1, 1.5, 2, 3] // Chromium 확대 레벨 (0 = 100%)

export class TabManager {
  private tabs = new Map<number, Tab>()
  private activeByWs = new Map<string, number>() // 워크스페이스별 마지막 활성 탭
  private ws = 'default'
  private bounds: Rectangle = { x: 0, y: 0, width: 0, height: 0 }
  private covered = false // UI 패널(주소 추천·설정)이 콘텐츠 영역을 덮는 중
  private closed: { url: string; workspaceId: string }[] = [] // 닫은 탭 (TAB-04)

  constructor(
    private win: BrowserWindow,
    private hooks: Hooks
  ) {}

  get workspace(): string {
    return this.ws
  }

  get active(): number | null {
    return this.activeByWs.get(this.ws) ?? null
  }

  has(id: number): boolean {
    return this.tabs.has(id)
  }

  allWebContents(): WebContents[] {
    return [...this.tabs.values()].map((t) => t.view.webContents)
  }

  wc(id: number | null): WebContents | undefined {
    return id === null ? undefined : this.tabs.get(id)?.view.webContents
  }

  create(url: string, workspaceId = this.ws, background = false): number {
    const partition = `persist:ws-${workspaceId}`
    this.hooks.prepareSession(partition)
    const view = new WebContentsView({
      webPreferences: {
        partition,
        preload: join(__dirname, '../preload/tab.js'),
        sandbox: true,
        contextIsolation: true,
        nodeIntegration: false,
        nodeIntegrationInSubFrames: true // iframe 안의 인강 플레이어에도 tab preload 주입
      }
    })
    const wc = view.webContents
    const id = wc.id
    const tab: Tab = { view, workspaceId, favicon: '' }
    this.tabs.set(id, tab)

    wc.setWindowOpenHandler(({ url: target, disposition }) => {
      // 로그인 팝업(창 크기가 지정된 새 창)은 실제 팝업으로 열어야 로그인 흐름이 유지됨
      if (disposition === 'new-window') {
        return {
          action: 'allow',
          overrideBrowserWindowOptions: { width: 520, height: 720, autoHideMenuBar: true }
        }
      }
      this.create(target, workspaceId, disposition === 'background-tab')
      return { action: 'deny' }
    })
    const emit = (): void => this.emit()
    wc.on('page-title-updated', emit)
    wc.on('did-start-loading', emit)
    wc.on('did-stop-loading', emit)
    wc.on('audio-state-changed', emit)
    wc.on('did-navigate', emit)
    wc.on('did-navigate-in-page', emit)
    wc.on('page-favicon-updated', (_e, icons) => {
      tab.favicon = icons[0] ?? ''
      emit()
    })
    wc.on('did-finish-load', () => {
      const info = this.info(id) // 제목이 정해진 뒤 방문 기록 저장
      if (info && info.url.startsWith('http')) this.hooks.onVisit(info)
    })
    wc.on('found-in-page', (_e, r) =>
      this.hooks.onFound({ active: r.activeMatchOrdinal, matches: r.matches })
    )
    wc.on('before-input-event', (e, input) => this.hooks.onKey(input, e))
    wc.on('context-menu', (_e, params) => this.hooks.onContextMenu(id, params))
    wc.on('dom-ready', () => this.hooks.onDomReady(id, wc))

    view.setVisible(false)
    this.win.contentView.addChildView(view)
    // 사이트 호환 설정(UA·Client Hints) 적용을 시작한 뒤 연다.
    // ⚠ 아직 렌더러가 없는 새 탭에서는 DevTools 명령이 페이지를 열 때까지 대기하므로 끝나기를 기다리지 않는다
    //   (명령은 순서대로 처리되어 첫 페이지에도 적용됨). 최대 300ms만 기다림.
    void Promise.race([
      this.hooks.onCreated(wc).catch(() => {}),
      new Promise((r) => setTimeout(r, 300))
    ]).then(
      () => void wc.loadURL(toUrl(url)).catch(() => {}) // 로드 실패는 페이지에 오류 화면으로 표시됨
    )
    wc.on('did-create-window', (w) => void this.hooks.onCreated(w.webContents)) // 로그인 팝업 창
    if (!background && workspaceId === this.ws) this.activate(id)
    else this.emit()
    return id
  }

  activate(id: number): void {
    const t = this.tabs.get(id)
    if (!t) return
    this.ws = t.workspaceId
    this.activeByWs.set(this.ws, id)
    this.refresh()
    this.emit()
  }

  close(id: number): void {
    const t = this.tabs.get(id)
    if (!t) return
    const url = t.view.webContents.getURL()
    if (url.startsWith('http')) this.closed.push({ url, workspaceId: t.workspaceId })
    if (this.closed.length > 30) this.closed.shift()
    this.win.contentView.removeChildView(t.view)
    t.view.webContents.close() // WebContentsView는 직접 닫아야 메모리가 해제됨
    this.tabs.delete(id)
    this.hooks.onClosed(id)
    if (this.activeByWs.get(t.workspaceId) === id) {
      this.activeByWs.delete(t.workspaceId)
      const rest = this.idsOf(t.workspaceId)
      if (rest.length) this.activeByWs.set(t.workspaceId, rest[rest.length - 1])
      else if (t.workspaceId === this.ws) return void this.create(this.hooks.startUrl()) // 마지막 탭이면 새 탭
    }
    this.refresh()
    this.emit()
  }

  reopenClosed(): void {
    const last = this.closed.pop()
    if (last) this.create(last.url, last.workspaceId)
  }

  cycle(step: 1 | -1): void {
    const ids = this.idsOf(this.ws)
    if (ids.length < 2 || this.active === null) return
    const i = ids.indexOf(this.active)
    this.activate(ids[(i + step + ids.length) % ids.length])
  }

  switchWorkspace(workspaceId: string): void {
    this.ws = workspaceId
    if (!this.activeByWs.has(workspaceId)) {
      const ids = this.idsOf(workspaceId)
      if (ids.length) this.activeByWs.set(workspaceId, ids[ids.length - 1])
      else return void this.create(this.hooks.startUrl(), workspaceId)
    }
    this.refresh()
    this.emit()
  }

  /** 워크스페이스 삭제 시: 그 워크스페이스의 탭을 모두 닫음 */
  closeWorkspace(workspaceId: string): void {
    for (const id of this.idsOf(workspaceId)) {
      const t = this.tabs.get(id)!
      this.win.contentView.removeChildView(t.view)
      t.view.webContents.close()
      this.tabs.delete(id)
    }
    this.activeByWs.delete(workspaceId)
  }

  setBounds(b: Rectangle): void {
    this.bounds = b
    this.refresh()
  }

  setCovered(covered: boolean): void {
    this.covered = covered
    this.refresh()
  }

  navigate(id: number, input: string): void {
    void this.wc(id)
      ?.loadURL(toUrl(input))
      .catch(() => {})
  }

  zoom(id: number, dir: 1 | -1 | 0): void {
    const wc = this.wc(id)
    if (!wc) return
    const cur = wc.getZoomLevel()
    const next =
      dir === 0
        ? 0
        : dir > 0
          ? (ZOOM_STEPS.find((z) => z > cur + 0.01) ?? cur)
          : ([...ZOOM_STEPS].reverse().find((z) => z < cur - 0.01) ?? cur)
    wc.setZoomLevel(next)
    this.emit()
  }

  snapshot(): SessionSnapshot {
    const tabs = [...this.tabs.entries()]
      .map(([id, t]) => ({
        url: t.view.webContents.getURL(),
        workspaceId: t.workspaceId,
        active: this.activeByWs.get(t.workspaceId) === id
      }))
      .filter((t) => t.url.startsWith('http'))
    return { workspaceId: this.ws, tabs }
  }

  restore(s: SessionSnapshot): void {
    for (const t of s.tabs) {
      const id = this.create(t.url, t.workspaceId, true)
      if (t.active) this.activeByWs.set(t.workspaceId, id)
    }
    this.switchWorkspace(s.workspaceId)
  }

  info(id: number): TabInfo | null {
    const t = this.tabs.get(id)
    if (!t) return null
    const wc = t.view.webContents
    return {
      id,
      workspaceId: t.workspaceId,
      url: wc.getURL(),
      title: wc.getTitle(),
      favicon: t.favicon,
      loading: wc.isLoading(),
      audible: wc.isCurrentlyAudible(),
      muted: wc.isAudioMuted(),
      canGoBack: wc.navigationHistory.canGoBack(),
      canGoForward: wc.navigationHistory.canGoForward(),
      zoom: Math.round(Math.pow(1.2, wc.getZoomLevel()) * 100) // 표시용 %
    }
  }

  list(): TabInfo[] {
    return [...this.tabs.keys()].map((id) => this.info(id)).filter((t): t is TabInfo => !!t)
  }

  /** 탭 안의 모든 프레임(iframe 포함)에 메시지 전달 — 미디어 제어용 */
  sendToFrames(id: number, channel: string, ...args: unknown[]): void {
    this.wc(id)?.mainFrame.framesInSubtree.forEach((f) => f.send(channel, ...args))
  }

  private idsOf(workspaceId: string): number[] {
    return [...this.tabs.entries()]
      .filter(([, t]) => t.workspaceId === workspaceId)
      .map(([id]) => id)
  }

  private refresh(): void {
    const active = this.active
    for (const [id, t] of this.tabs) {
      const show = id === active && !this.covered
      t.view.setVisible(show)
      if (show) t.view.setBounds(this.bounds)
    }
  }

  private emit(): void {
    this.hooks.onState({ list: this.list(), activeId: this.active, workspaceId: this.ws })
  }
}
