/** 광고·추적기 차단 (CNV-09): Ghostery 필터 엔진. 필터 목록은 처음 켤 때 내려받아 캐시한다. */
import { ElectronBlocker } from '@ghostery/adblocker-electron'
import { app, type Session } from 'electron'
import { readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import log from 'electron-log/main'

let blocker: ElectronBlocker | null = null

async function load(): Promise<ElectronBlocker> {
  if (!blocker) {
    blocker = await ElectronBlocker.fromPrebuiltAdsAndTracking(fetch, {
      path: join(app.getPath('userData'), 'adblock-engine.bin'),
      read: readFile,
      write: writeFile
    })
  }
  return blocker
}

export async function setAdblock(enabled: boolean, sessions: Session[]): Promise<void> {
  try {
    if (enabled) {
      const b = await load()
      for (const s of sessions) if (!b.isBlockingEnabled(s)) b.enableBlockingInSession(s)
    } else if (blocker) {
      for (const s of sessions)
        if (blocker.isBlockingEnabled(s)) blocker.disableBlockingInSession(s)
    }
  } catch (e) {
    log.warn('[adblock]', e)
    throw new Error('광고 차단 목록을 불러오지 못했습니다 (인터넷 연결 확인)')
  }
}
