/**
 * 크롤러 연동 (CRW): 로그인 쿠키·UA를 붙여 Core에 작업을 맡기고,
 * 'PDF(브라우저 렌더링)' 형식은 Core 작업이 끝난 뒤 숨은 창으로 페이지를 열어 PDF로 인쇄한다.
 */
import { app, BrowserWindow, session } from 'electron'
import { mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { coreJson } from './core-process'
import { safeFileName } from './page-tools'

export interface CrawlRequest {
  start_url: string
  page_formats: string[]
  workspaceId: string
  [key: string]: unknown
}

interface PdfState {
  done: number
  total: number
  running: boolean
  cancelled: boolean
}

const pdfJobs = new Map<string, PdfState>()
const pdfWanted = new Map<string, string>() // jobId → partition

export async function startCrawl(
  req: CrawlRequest,
  userAgent: string,
  outputDir: string,
  via: (partition: string) => { fetch_via: string; fetch_token: string } | null
): Promise<unknown> {
  const partition = `persist:ws-${req.workspaceId}`
  // 기본: 브라우저 네트워크로 받기 (방화벽이 일반 프로그램 요청을 막는 사이트 대응)
  const browserNet = req.engine !== 'direct' ? via(partition) : null
  const cookies = await session.fromPartition(partition).cookies.get({ url: req.start_url })
  const wantPdf = req.page_formats.includes('pdf')
  const body = {
    ...req,
    workspaceId: undefined,
    engine: undefined,
    ...(browserNet ?? {}),
    page_formats: req.page_formats.filter((f) => f !== 'pdf'),
    cookies: cookies.map((c) => `${c.name}=${c.value}`).join('; '),
    user_agent: userAgent,
    output_dir: outputDir || join(app.getPath('downloads'), 'OmniBrowser')
  }
  const job = await coreJson<{ id: string }>('/crawl/start', { method: 'POST', body })
  if (wantPdf) {
    pdfWanted.set(job.id, partition)
    void waitAndPrint(job.id)
  }
  return job
}

export async function crawlStatus(id: string, files: boolean): Promise<Record<string, unknown>> {
  const s = await coreJson<Record<string, unknown>>(`/crawl/${id}?files=${files}`)
  const pdf = pdfJobs.get(id)
  return pdf ? { ...s, pdf } : s
}

export function cancelPdf(id: string): void {
  const p = pdfJobs.get(id)
  if (p) p.cancelled = true
  pdfWanted.delete(id)
}

async function waitAndPrint(id: string): Promise<void> {
  for (;;) {
    await new Promise((r) => setTimeout(r, 1500))
    if (!pdfWanted.has(id)) return
    const s = await coreJson<{ state: string; output_dir: string }>(`/crawl/${id}`).catch(
      () => null
    )
    if (!s) return
    if (['error', 'cancelled'].includes(s.state)) return
    if (s.state === 'done' || s.state === 'scanned') {
      const pages = await coreJson<{ url: string; title: string }[]>(`/crawl/${id}/pages`)
      await printPages(id, pages.slice(0, 300), pdfWanted.get(id)!, join(s.output_dir, 'pdf'))
      return
    }
  }
}

/** 숨은 창 하나로 페이지를 차례로 열어 PDF로 저장 (자바스크립트로 그려지는 페이지도 보이는 그대로) */
async function printPages(
  id: string,
  pages: { url: string; title: string }[],
  partition: string,
  dir: string
): Promise<void> {
  const st: PdfState = { done: 0, total: pages.length, running: true, cancelled: false }
  pdfJobs.set(id, st)
  await mkdir(dir, { recursive: true })
  const w = new BrowserWindow({
    show: false,
    width: 1280,
    height: 1600,
    webPreferences: { partition, sandbox: true }
  })
  w.webContents.setAudioMuted(true)
  try {
    for (const [i, p] of pages.entries()) {
      if (st.cancelled) break
      try {
        await Promise.race([
          w.loadURL(p.url),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 30000))
        ])
        await new Promise((r) => setTimeout(r, 1000)) // 늦게 그려지는 요소 대기
        const pdf = await w.webContents.printToPDF({ printBackground: true, pageSize: 'A4' })
        await writeFile(
          join(dir, `${String(i + 1).padStart(3, '0')}_${safeFileName(p.title)}.pdf`),
          pdf
        )
      } catch {
        // 한 페이지 실패는 건너뜀
      }
      st.done = i + 1
    }
  } finally {
    st.running = false
    w.destroy()
    pdfWanted.delete(id)
  }
}
