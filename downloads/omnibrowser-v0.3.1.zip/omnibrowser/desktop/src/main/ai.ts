/** AI 응답 스트리밍 중계: Core(/ai/stream)의 글자 조각을 UI로 실시간 전달, 중지 가능 */
import { core } from './core-process'

export class AiRunner {
  private jobs = new Map<string, AbortController>()

  constructor(private send: (channel: string, payload: unknown) => void) {}

  stop(jobId: string): void {
    this.jobs.get(jobId)?.abort()
  }

  async run(jobId: string, body: Record<string, unknown>): Promise<void> {
    const ac = new AbortController()
    this.jobs.set(jobId, ac)
    try {
      const res = await core('/ai/stream', { method: 'POST', body, signal: ac.signal })
      const reader = res.body!.getReader()
      const decoder = new TextDecoder()
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        const text = decoder.decode(value, { stream: true })
        if (text) this.send('ai:chunk', { jobId, text })
      }
      this.send('ai:done', { jobId })
    } catch (e) {
      const error = ac.signal.aborted ? '중지했습니다' : (e as Error).message
      this.send('ai:done', { jobId, error })
    } finally {
      this.jobs.delete(jobId)
    }
  }
}
