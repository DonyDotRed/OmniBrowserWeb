/**
 * 사이트 호환성 (3.14절): 일반 "최신 Chrome"과 똑같이 보이게 한다.
 *
 * 차단 원인 (v0.2 이후 추가 분석):
 *  ① UA 문자열의 Electron/앱 이름 표시  → v0.2에서 제거
 *  ② Chrome 버전이 오래됨 (Electron 39 = Chromium 142, 2025-10) → "최신 브라우저가 아님"으로 차단
 *  ③ 자바스크립트 navigator.userAgentData의 브랜드에 "Google Chrome"이 없음, window.chrome이 비어 있음
 * 대응:
 *  - 현재 Chrome 안정판 버전을 Google 버전 기록 API에서 받아(3일마다, 실패 시 날짜로 추정) UA·Client Hints에 사용
 *  - 각 탭에 DevTools 프로토콜 Emulation.setUserAgentOverride로 UA + Client Hints(헤더·JS 모두) 일관되게 설정
 *  - window.chrome 기본 속성 보완
 */
import { app, net, type Session, type WebContents } from 'electron'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import log from 'electron-log/main'

export type UaMode = 'chrome' | 'edge' | 'custom' | 'electron'

// Chrome 142 안정판 출시일(2025-10-28) 기준, 약 4주마다 새 버전 → 인터넷이 안 될 때의 추정값
const BASE_MAJOR = 142
const BASE_DATE = Date.UTC(2025, 9, 28)
export function estimateChromeMajor(now = Date.now()): number {
  return BASE_MAJOR + Math.max(0, Math.floor((now - BASE_DATE) / (28 * 86_400_000)))
}

let chromeFull = `${estimateChromeMajor()}.0.0.0`
const versionFile = (): string => join(app.getPath('userData'), 'chrome-version.json')

export const chromeVersion = (): string => chromeFull
const major = (): string => chromeFull.split('.')[0]

/** 저장된 버전을 읽고, 3일이 지났으면 Google에서 최신 안정판 버전을 받아 온다. 바뀌면 true */
export async function refreshChromeVersion(force = false): Promise<boolean> {
  let cached: { version?: string; checked?: number } = {}
  try {
    cached = JSON.parse(readFileSync(versionFile(), 'utf8'))
  } catch {
    /* 처음 실행 */
  }
  const before = chromeFull
  if (cached.version && Number(cached.version.split('.')[0]) >= Number(major()))
    chromeFull = cached.version
  if (!force && cached.checked && Date.now() - cached.checked < 3 * 86_400_000)
    return chromeFull !== before
  try {
    const plat =
      process.platform === 'darwin' ? 'mac' : process.platform === 'linux' ? 'linux' : 'win64'
    const res = await net.fetch(
      `https://versionhistory.googleapis.com/v1/chrome/platforms/${plat}/channels/stable/versions?pageSize=1`
    )
    const v = ((await res.json()) as { versions?: { version: string }[] }).versions?.[0]?.version
    if (v && /^\d+\.\d+\.\d+\.\d+$/.test(v)) {
      chromeFull = v
      writeFileSync(versionFile(), JSON.stringify({ version: v, checked: Date.now() }))
    }
  } catch (e) {
    log.warn('[ua] Chrome 최신 버전 확인 실패 — 추정값 사용', chromeFull, e)
  }
  return chromeFull !== before
}

function osInfo(): { token: string; platform: string; chPlatform: string; chVersion: string } {
  if (process.platform === 'win32')
    return {
      token: 'Windows NT 10.0; Win64; x64',
      platform: 'Win32',
      chPlatform: 'Windows',
      chVersion: '15.0.0'
    }
  if (process.platform === 'darwin')
    return {
      token: 'Macintosh; Intel Mac OS X 10_15_7',
      platform: 'MacIntel',
      chPlatform: 'macOS',
      chVersion: '15.0.0'
    }
  return {
    token: 'X11; Linux x86_64',
    platform: 'Linux x86_64',
    chPlatform: 'Linux',
    chVersion: '6.0.0'
  }
}

/** 모드에 맞는 UA 문자열 */
export function userAgentFor(mode: UaMode, electronDefault: string, custom = ''): string {
  if (mode === 'electron') return electronDefault
  if (mode === 'custom' && custom.trim()) return custom.trim()
  const v = `${major()}.0.0.0` // 실제 Chrome처럼 축약된 버전 표기
  const base = `Mozilla/5.0 (${osInfo().token}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${v} Safari/537.36`
  return mode === 'edge' ? `${base} Edg/${v}` : base
}

function brandList(mode: UaMode, full: boolean): { brand: string; version: string }[] {
  const v = full ? chromeFull : major()
  const second = mode === 'edge' ? 'Microsoft Edge' : 'Google Chrome'
  return [
    { brand: second, version: v },
    { brand: 'Chromium', version: v },
    { brand: 'Not/A)Brand', version: full ? '24.0.0.0' : '24' }
  ]
}
const headerOf = (list: { brand: string; version: string }[]): string =>
  list.map((b) => `"${b.brand}";v="${b.version}"`).join(', ')

/** 네트워크 요청 헤더 보정 (탭 외의 요청·서비스 워커 등 대비) */
export function applyUserAgent(ses: Session, mode: UaMode, ua: string): void {
  ses.setUserAgent(ua, 'ko-KR,ko,en-US,en')
  ses.webRequest.onBeforeSendHeaders((details, callback) => {
    const h = details.requestHeaders
    if (mode === 'chrome' || mode === 'edge') {
      for (const k of Object.keys(h)) {
        const lk = k.toLowerCase()
        if (lk === 'sec-ch-ua') h[k] = headerOf(brandList(mode, false))
        else if (lk === 'sec-ch-ua-full-version-list') h[k] = headerOf(brandList(mode, true))
        else if (lk === 'sec-ch-ua-full-version') h[k] = `"${chromeFull}"`
      }
    }
    callback({ requestHeaders: h })
  })
}

/** 브라우저 경유 크롤러 등 직접 만드는 요청에 붙일 Chrome 기본 헤더 */
export function chromeHeaders(mode: UaMode): Record<string, string> {
  const h: Record<string, string> = {
    accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'accept-language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
    'upgrade-insecure-requests': '1'
  }
  if (mode === 'chrome' || mode === 'edge') {
    h['sec-ch-ua'] = headerOf(brandList(mode, false))
    h['sec-ch-ua-mobile'] = '?0'
    h['sec-ch-ua-platform'] = `"${osInfo().chPlatform}"`
  }
  return h
}

/**
 * 탭 하나에 UA + Client Hints(JS의 navigator.userAgentData 포함)를 일관되게 적용.
 * DevTools 프로토콜을 쓰므로 페이지를 열기 전에 호출해야 첫 요청부터 적용된다.
 */
export async function emulateTab(wc: WebContents, mode: UaMode, ua: string): Promise<void> {
  if (wc.isDestroyed()) return
  const dbg = wc.debugger
  try {
    if (!dbg.isAttached()) {
      if (mode === 'electron' || mode === 'custom') return
      dbg.attach('1.3') // window.chrome 보완은 tab preload(chromeShim)가 담당
    }
    const os = osInfo()
    const real = mode === 'chrome' || mode === 'edge'
    await dbg.sendCommand('Emulation.setUserAgentOverride', {
      userAgent: ua,
      acceptLanguage: 'ko-KR,ko,en-US,en', // q 값은 Chromium이 헤더에 자동으로 붙임
      platform: os.platform,
      ...(real && {
        userAgentMetadata: {
          brands: brandList(mode, false),
          fullVersionList: brandList(mode, true),
          fullVersion: chromeFull,
          platform: os.chPlatform,
          platformVersion: os.chVersion,
          architecture: 'x86',
          model: '',
          mobile: false,
          bitness: '64',
          wow64: false
        }
      })
    })
  } catch (e) {
    log.warn('[ua] 탭 호환 설정 실패', e)
  }
}

// ───────── 차단 화면 감지 ─────────
export const BLOCK_CHECK = `(() => {
  const t = ((document.title || '') + ' ' + (document.body ? document.body.innerText : '')).slice(0, 4000)
  if (t.length > 3500) return false
  return /web page blocked|request (has been )?blocked|browser-update\\.org|unsupported browser|update your browser|latest version of your browser|access denied|지원하지 않는 브라우저|브라우저를 업데이트|차단되었습니다/i.test(t)
})()`
