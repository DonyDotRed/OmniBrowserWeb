/**
 * 단축키 → 명령 ID. 탭(웹페이지)과 UI 창 양쪽의 before-input-event에서 같은 표를 사용한다.
 * e.code(물리 키 위치) 기준이라 한글 입력 모드에서도 동작한다.
 * (미디어 단축키 S/D/R/G/Z/X 등은 탭 preload가 처리 — 3.10절)
 */
import type { Input } from 'electron'

export const KEYMAP: Record<string, string> = {
  'Ctrl+KeyT': 'tab.new',
  'Ctrl+KeyW': 'tab.close',
  'Ctrl+Shift+KeyT': 'tab.reopen',
  'Ctrl+Tab': 'tab.next',
  'Ctrl+Shift+Tab': 'tab.prev',
  'Ctrl+Shift+KeyM': 'tab.mute',
  'Ctrl+KeyL': 'address.focus',
  F6: 'address.focus',
  F5: 'nav.reload',
  'Ctrl+KeyR': 'nav.reload',
  'Alt+ArrowLeft': 'nav.back',
  'Alt+ArrowRight': 'nav.forward',
  'Ctrl+KeyF': 'find.open',
  'Ctrl+KeyD': 'bookmark.toggle',
  'Ctrl+Equal': 'zoom.in',
  'Ctrl+Shift+Equal': 'zoom.in',
  'Ctrl+NumpadAdd': 'zoom.in',
  'Ctrl+Minus': 'zoom.out',
  'Ctrl+NumpadSubtract': 'zoom.out',
  'Ctrl+Digit0': 'zoom.reset',
  'Alt+KeyD': 'address.focus',
  'Alt+KeyR': 'tts.read',
  'Alt+KeyP': 'media.pip',
  F12: 'devtools.tab',
  // v0.2: AI · 크롤러 · 페이지 도구
  'Ctrl+KeyK': 'palette',
  'Ctrl+Shift+KeyP': 'palette',
  'Ctrl+Shift+KeyA': 'panel.ai',
  'Ctrl+Shift+KeyL': 'panel.crawl',
  'Ctrl+Shift+KeyN': 'panel.notes',
  'Ctrl+KeyJ': 'panel.downloads',
  'Ctrl+KeyH': 'sidebar.history',
  'Alt+KeyS': 'ai.summarize',
  'Alt+KeyT': 'page.translate',
  'Alt+Shift+KeyT': 'page.restore',
  F9: 'reader.toggle',
  'Alt+Shift+KeyD': 'page.dark',
  'Ctrl+KeyP': 'page.print',
  'Ctrl+KeyS': 'page.save.menu',
  'Ctrl+Shift+KeyS': 'page.save.png'
}
for (let i = 1; i <= 9; i++) KEYMAP[`Ctrl+Alt+Digit${i}`] = `ws.${i}` // 워크스페이스 전환

/** 키 입력 → "Ctrl+Shift+KeyT" 형식 문자열 */
export function comboOf(input: Input): string {
  const parts: string[] = []
  if (input.control || input.meta) parts.push('Ctrl')
  if (input.alt) parts.push('Alt')
  if (input.shift) parts.push('Shift')
  parts.push(input.code)
  return parts.join('+')
}
