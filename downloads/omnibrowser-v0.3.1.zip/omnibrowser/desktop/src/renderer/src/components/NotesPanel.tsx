import { useEffect, useState } from 'react'
import { renderMarkdown } from '../lib/markdown'
import { invoke, safeInvoke, useApp } from '../stores/app'

interface Note {
  id: string
  url: string
  title: string | null
  quote: string | null
  body: string
  created_at: number
}

/** 메모 (LRN-03): 이 페이지 메모 / 전체 메모 검색 / Markdown 내보내기 */
export function NotesPanel(): React.JSX.Element {
  const { tabs, activeId } = useApp()
  const tab = tabs.find((t) => t.id === activeId)
  const [all, setAll] = useState(false)
  const [q, setQ] = useState('')
  const [notes, setNotes] = useState<Note[]>([])
  const [draft, setDraft] = useState('')

  const [version, setVersion] = useState(0) // 추가·삭제 후 다시 불러오기
  const url = tab?.url
  const load = (): void => setVersion((v) => v + 1)

  useEffect(() => {
    const t = setTimeout(() => {
      void safeInvoke<Note[]>('notes:list', all ? undefined : url, q || undefined).then((r) =>
        setNotes(r ?? [])
      )
    }, 150)
    return () => clearTimeout(t)
  }, [all, q, url, version])

  return (
    <div className="flex h-full flex-col text-xs">
      <div className="border-b border-neutral-200 p-2">
        <textarea
          rows={3}
          className="w-full rounded border border-neutral-300 p-1.5"
          placeholder={`이 페이지에 대한 메모 (Markdown 가능)\n${tab?.title ?? ''}`}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
        <button
          className="w-full rounded bg-indigo-600 py-1 text-white disabled:opacity-40"
          disabled={!draft.trim() || !tab}
          onClick={async () => {
            await safeInvoke('notes:add', { url: tab!.url, title: tab!.title, body: draft })
            setDraft('')
            load()
          }}
        >
          메모 추가
        </button>
      </div>
      <div className="flex items-center gap-2 p-2">
        <label>
          <input type="radio" checked={!all} onChange={() => setAll(false)} /> 이 페이지
        </label>
        <label>
          <input type="radio" checked={all} onChange={() => setAll(true)} /> 전체
        </label>
        <input
          className="min-w-0 flex-1 rounded border px-1"
          placeholder="검색"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button title="모든 메모를 Markdown 파일로" onClick={() => invoke('notes:export')}>
          📤
        </button>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto px-2">
        {notes.length === 0 && (
          <p className="text-neutral-500">
            메모가 없습니다. AI 답변의 🗒 버튼이나 우클릭 → 메모로 저장도 쓸 수 있습니다.
          </p>
        )}
        {notes.map((n) => (
          <div key={n.id} className="group mb-2 rounded border border-neutral-200 bg-white p-2">
            {all && (
              <button
                className="block w-full truncate text-left text-indigo-600"
                onClick={() => invoke('tabs:create', n.url)}
              >
                {n.title || n.url}
              </button>
            )}
            {n.quote && (
              <blockquote className="border-l-2 border-indigo-200 pl-2 text-neutral-600">
                {n.quote}
              </blockquote>
            )}
            <div className="omni-md" dangerouslySetInnerHTML={{ __html: renderMarkdown(n.body) }} />
            <div className="flex text-[10px] text-neutral-400">
              {new Date(n.created_at).toLocaleString()}
              <button
                className="invisible ml-auto group-hover:visible"
                onClick={async () => {
                  await safeInvoke('notes:delete', n.id)
                  load()
                }}
              >
                삭제
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
