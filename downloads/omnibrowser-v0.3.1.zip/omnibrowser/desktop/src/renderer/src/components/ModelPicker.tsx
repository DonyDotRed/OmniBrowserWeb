import { useCallback, useEffect, useState } from 'react'
import { invoke } from '../stores/app'

interface ModelInfo {
  id: string
  name: string
  created: number
}
interface ModelList {
  updated: number
  models: ModelInfo[]
  recommended: string | null
  default?: string | null
}

const clean = (e: unknown): string =>
  String((e as Error).message ?? e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')

/**
 * 모델 선택 + 🔄 최신 목록 갱신 (AI 대화 모델·TTS 모델 공용).
 * 목록은 Core에 저장(캐시)되어 다음 실행에도 바로 보이고, 🔄을 누르면 각 회사 API에서 다시 받는다.
 */
export function ModelPicker(p: {
  provider: string
  kind: 'chat' | 'tts'
  value: string
  defaultModel: string
  onChange: (v: string) => void
  disabled?: boolean
  compact?: boolean
}): React.JSX.Element {
  const [list, setList] = useState<ModelList | null>(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [manual, setManual] = useState(false)

  const load = useCallback(
    async (refresh: boolean): Promise<void> => {
      if (p.disabled || p.provider === 'supertonic') return
      setBusy(true)
      setErr('')
      try {
        const ch = p.kind === 'chat' ? 'ai:models' : 'tts:models'
        setList(await invoke<ModelList>(ch, p.provider, refresh))
      } catch (e) {
        setErr(clean(e))
      } finally {
        setBusy(false)
      }
    },
    [p.provider, p.kind, p.disabled]
  )

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- 제공자가 바뀌면 저장된 목록을 불러옴
    void load(false)
  }, [load])

  const ids = new Set(list?.models.map((m) => m.id))
  const known = !p.value || ids.has(p.value)
  const box = 'rounded border border-neutral-300 px-1 py-0.5'
  return (
    <div className={p.compact ? 'flex min-w-0 flex-1 items-center gap-1' : ''}>
      <div className="flex min-w-0 flex-1 items-center gap-1">
        {manual || (!known && p.value) ? (
          <input
            className={`${box} min-w-0 flex-1`}
            defaultValue={p.value}
            placeholder={`모델 이름 직접 입력 (비우면 ${p.defaultModel})`}
            onBlur={(e) => p.onChange(e.target.value.trim())}
          />
        ) : (
          <select
            className={`${box} min-w-0 flex-1`}
            value={p.value}
            disabled={p.disabled}
            onChange={(e) =>
              e.target.value === '__manual' ? setManual(true) : p.onChange(e.target.value)
            }
          >
            <option value="">
              기본값 (
              {list?.default && !ids.has(list.default) && list.recommended && p.kind === 'chat'
                ? `${list.recommended} — 기본 모델 단종으로 자동 대체`
                : p.defaultModel}
              )
            </option>
            {list?.recommended && (
              <option value={list.recommended}>⭐ {list.recommended} (추천 최신)</option>
            )}
            {list?.models
              .filter((m) => m.id !== list.recommended)
              .map((m) => (
                <option key={m.id} value={m.id}>
                  {m.id}
                  {m.name && m.name !== m.id ? ` — ${m.name}` : ''}
                </option>
              ))}
            <option value="__manual">✏ 직접 입력…</option>
          </select>
        )}
        <button
          className="rounded border px-1.5 py-0.5 disabled:opacity-40"
          title="각 회사에서 최신 모델 목록을 다시 받아 옵니다"
          disabled={busy || p.disabled}
          onClick={() => {
            setManual(false)
            void load(true)
          }}
        >
          {busy ? '…' : '🔄'}
        </button>
      </div>
      {!p.compact && (
        <div className="mt-0.5 text-[11px] text-neutral-500">
          {err
            ? `⚠ ${err}`
            : list
              ? `목록 ${list.models.length}개 · 갱신 ${new Date(list.updated).toLocaleString()}`
              : p.disabled
                ? '키를 등록하면 목록을 불러올 수 있습니다'
                : '🔄을 눌러 최신 목록을 받으세요'}
        </div>
      )}
    </div>
  )
}
