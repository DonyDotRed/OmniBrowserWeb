import { useEffect, useRef, type ReactNode } from 'react'
import { invoke } from '../stores/app'

/**
 * 웹페이지(WebContentsView)가 그려질 자리. Main이 이 div의 좌표에 웹페이지를 겹쳐 그린다.
 * 주소 추천·설정 패널을 열면 Main이 웹페이지를 잠시 숨기고(tabs:set-covered) 이 자리에 패널을 그린다.
 */
export function ContentArea({ children }: { children?: ReactNode }): React.JSX.Element {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const send = (): void => {
      const r = el.getBoundingClientRect()
      void invoke('split:set-bounds', {
        x: Math.round(r.x),
        y: Math.round(r.y),
        width: Math.round(r.width),
        height: Math.round(r.height)
      })
    }
    const ro = new ResizeObserver(send) // 사이드바 열기·창 크기 변경 등 모든 크기 변화 감지
    ro.observe(el)
    window.addEventListener('resize', send)
    send()
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', send)
    }
  }, [])

  return (
    <div ref={ref} className="relative min-w-0 flex-1 bg-white">
      {children}
    </div>
  )
}
