import { useEffect, useState } from 'react'
import { invoke, loadWorkspaces, safeInvoke, set, useApp } from '../stores/app'

const COLORS = ['#4F46E5', '#16A34A', '#DC2626', '#D97706', '#0891B2', '#9333EA']

/** 버티컬 탭 (TAB-01) + 북마크 + 워크스페이스 (WS-01) */
export function Sidebar(): React.JSX.Element {
  const { tabs, activeId, workspaceId, workspaces, bookmarks, sidebar } = useApp()
  const visible = tabs.filter((t) => t.workspaceId === workspaceId)
  const tabBtn = (mode: 'tabs' | 'bookmarks' | 'history', label: string): React.JSX.Element => (
    <button
      onClick={() => set({ sidebar: mode })}
      className={`flex-1 py-1 ${sidebar === mode ? 'border-b-2 border-indigo-500 font-semibold' : 'text-neutral-500'}`}
    >
      {label}
    </button>
  )

  return (
    <aside className="flex w-60 shrink-0 flex-col border-r border-neutral-200 bg-neutral-100 text-sm">
      <div className="flex">
        {tabBtn('tabs', `탭 ${visible.length}`)}
        {tabBtn('bookmarks', `북마크 ${bookmarks.length}`)}
        {tabBtn('history', '기록')}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-1">
        {sidebar === 'tabs' ? (
          <>
            {visible.map((t) => (
              <div
                key={t.id}
                onClick={() => invoke('tabs:activate', t.id)}
                onAuxClick={(e) => e.button === 1 && invoke('tabs:close', t.id)} // 휠 클릭으로 닫기
                className={`group flex cursor-default items-center gap-2 rounded px-2 py-1.5 ${t.id === activeId ? 'bg-white shadow-sm' : 'hover:bg-neutral-200'}`}
                title={t.url}
              >
                {t.favicon ? <img src={t.favicon} className="h-4 w-4" alt="" /> : <span>🌐</span>}
                <span className="min-w-0 flex-1 truncate">
                  {t.loading ? '⏳ ' : ''}
                  {t.title || t.url}
                </span>
                {(t.audible || t.muted) && (
                  <button
                    title="음소거 (Ctrl+Shift+M)"
                    onClick={(e) => {
                      e.stopPropagation()
                      void invoke('tabs:mute', t.id)
                    }}
                  >
                    {t.muted ? '🔇' : '🔊'}
                  </button>
                )}
                <button
                  className="invisible text-neutral-500 group-hover:visible"
                  title="닫기 (Ctrl+W)"
                  onClick={(e) => {
                    e.stopPropagation()
                    void invoke('tabs:close', t.id)
                  }}
                >
                  ✕
                </button>
              </div>
            ))}
            <button
              className="w-full rounded px-2 py-1.5 text-left text-neutral-500 hover:bg-neutral-200"
              onClick={() => invoke('tabs:create')}
            >
              ＋ 새 탭 (Ctrl+T)
            </button>
          </>
        ) : sidebar === 'history' ? (
          <HistoryList />
        ) : (
          <>
            {bookmarks.length === 0 && (
              <p className="p-2 text-neutral-500">☆ 버튼이나 Ctrl+D로 추가하세요.</p>
            )}
            {bookmarks.map((b) => (
              <div
                key={b.id}
                className="group flex items-center gap-2 rounded px-2 py-1.5 hover:bg-neutral-200"
                title={b.url}
              >
                <button
                  className="min-w-0 flex-1 truncate text-left"
                  onClick={() => invoke('tabs:create', b.url)}
                >
                  ★ {b.title}
                </button>
                <button
                  className="invisible text-neutral-500 group-hover:visible"
                  onClick={() => safeInvoke('bookmarks:remove', b.id)}
                >
                  ✕
                </button>
              </div>
            ))}
          </>
        )}
      </div>

      <Workspaces current={workspaceId} list={workspaces} />
    </aside>
  )
}

function Workspaces({
  current,
  list
}: {
  current: string
  list: { id: string; name: string; color: string }[]
}): React.JSX.Element {
  const [adding, setAdding] = useState(false)
  const [name, setName] = useState('')

  const create = async (): Promise<void> => {
    const n = name.trim()
    setAdding(false)
    setName('')
    if (!n) return
    await safeInvoke('ws:create', n, COLORS[list.length % COLORS.length])
    await loadWorkspaces()
  }

  return (
    <div className="border-t border-neutral-200 p-2">
      <div className="mb-1 text-xs text-neutral-500">
        워크스페이스 (Ctrl+Alt+숫자 · 우클릭 삭제)
      </div>
      <div className="flex flex-wrap gap-1">
        {list.map((w, i) => (
          <button
            key={w.id}
            title={`Ctrl+Alt+${i + 1}`}
            onClick={() => invoke('ws:switch', w.id)}
            onContextMenu={async (e) => {
              e.preventDefault()
              if (w.id === 'default') return
              if (await safeInvoke<boolean>('ws:delete', w.id, w.name)) await loadWorkspaces()
            }}
            className={`flex items-center gap-1 rounded-full border px-2 py-0.5 ${w.id === current ? 'border-neutral-400 bg-white font-semibold' : 'border-transparent hover:bg-neutral-200'}`}
          >
            <span
              className="inline-block h-2.5 w-2.5 rounded-full"
              style={{ background: w.color }}
            />
            {w.name}
          </button>
        ))}
        {adding ? (
          <input
            autoFocus
            className="w-24 rounded border px-1"
            placeholder="이름 입력"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={() => void create()}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.nativeEvent.isComposing) void create()
              if (e.key === 'Escape') setAdding(false)
            }}
          />
        ) : (
          <button
            className="rounded-full px-2 py-0.5 text-neutral-500 hover:bg-neutral-200"
            onClick={() => setAdding(true)}
          >
            ＋
          </button>
        )}
      </div>
    </div>
  )
}

interface Visit {
  url: string
  title: string
  last_visit: number
}

/** 방문 기록 (한국어 부분 검색, 전체 삭제) */
function HistoryList(): React.JSX.Element {
  const [q, setQ] = useState('')
  const [items, setItems] = useState<Visit[]>([])
  const load = (query: string): void => {
    void invoke<Visit[]>('history:list', query)
      .then(setItems)
      .catch(() => setItems([]))
  }
  useEffect(() => {
    const t = setTimeout(() => load(q), 150)
    return () => clearTimeout(t)
  }, [q])
  return (
    <div>
      <div className="flex gap-1 p-1">
        <input
          className="min-w-0 flex-1 rounded border px-1"
          placeholder="기록 검색"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button
          className="text-xs text-neutral-500"
          title="방문 기록 전체 삭제"
          onClick={async () => {
            if (await safeInvoke<boolean>('history:clear')) load(q)
          }}
        >
          🗑
        </button>
      </div>
      {items.map((h) => (
        <button
          key={h.url}
          className="block w-full truncate rounded px-2 py-1 text-left hover:bg-neutral-200"
          title={`${h.url}\n${new Date(h.last_visit).toLocaleString()}`}
          onClick={() => invoke('tabs:create', h.url)}
        >
          {h.title || h.url}
        </button>
      ))}
    </div>
  )
}
