import { useEffect, useState } from 'react'
import { invoke, safeInvoke, set, showToast } from '../stores/app'
import { ModelPicker } from './ModelPicker'
import { TtsSettings } from './TtsSettings'

type Settings = Record<string, unknown>
interface Provider {
  name: string
  label: string
  default_model: string
  key_url: string
  has_key: boolean
  model: string
}

const SHORTCUTS: [string, string][] = [
  ['명령 팔레트 (모든 기능 검색)', 'Ctrl+K'],
  ['AI 도우미 / 페이지 AI 요약', 'Ctrl+Shift+A / Alt+S'],
  ['페이지 번역 / 원문으로', 'Alt+T / Alt+Shift+T'],
  ['리더 모드', 'F9'],
  ['크롤러 · 일괄 다운로드', 'Ctrl+Shift+L'],
  ['메모 / 다운로드 / 방문 기록', 'Ctrl+Shift+N / Ctrl+J / Ctrl+H'],
  ['페이지 저장 메뉴 / 전체 페이지 PNG / 인쇄', 'Ctrl+S / Ctrl+Shift+S / Ctrl+P'],
  ['다크 모드 (사이트별)', 'Alt+Shift+D'],
  ['새 탭 / 닫기 / 닫은 탭 복구', 'Ctrl+T / Ctrl+W / Ctrl+Shift+T'],
  ['다음·이전 탭', 'Ctrl+Tab / Ctrl+Shift+Tab'],
  ['주소창 (?로 시작하면 AI 질문)', 'Ctrl+L, Alt+D, F6'],
  ['페이지에서 찾기 / 북마크', 'Ctrl+F / Ctrl+D'],
  ['확대 / 축소 / 원래대로', 'Ctrl+= / Ctrl+- / Ctrl+0'],
  ['워크스페이스 전환', 'Ctrl+Alt+1~9'],
  ['영상 느리게 / 빠르게', 'S / D (Shift: ±0.5)'],
  ['1.0x ↔ 직전 배속 / 즐겨찾기 배속', 'R / G'],
  ['10초 뒤로 / 앞으로 · 프레임 이동', 'Z / X · , / .'],
  ['구간 반복 시작 / 끝 / 해제', '[ / ] / \\'],
  ['PiP (강제) / 선택 텍스트 읽기', 'Alt+P / Alt+R'],
  ['탭 음소거 / 개발자 도구', 'Ctrl+Shift+M / F12']
]

/** 설정 화면 */
export function SettingsPanel(): React.JSX.Element {
  const [s, setS] = useState<Settings | null>(null)
  const [providers, setProviders] = useState<Provider[]>([])
  const [keys, setKeys] = useState<Record<string, string>>({})
  const [usage, setUsage] = useState<{
    limit: number
    by_provider: { provider: string; chars: number; calls: number }[]
  } | null>(null)
  const [ua, setUa] = useState<{ mode: string; ua: string; chrome: string } | null>(null)

  const reloadProviders = (): void => {
    void safeInvoke<Provider[]>('ai:providers').then(
      (p) => p && setProviders(p.filter((x) => x.name !== 'mock'))
    )
  }
  useEffect(() => {
    void safeInvoke<Settings>('settings:get').then(setS)
    void safeInvoke<{ mode: string; ua: string; chrome: string }>('ua:info').then(setUa)
    void safeInvoke<typeof usage>('ai:usage').then(setUsage)
    reloadProviders()
  }, [])

  const save = async (key: string, value: unknown): Promise<void> => {
    setS((prev) => ({ ...prev, [key]: value }))
    await safeInvoke('settings:set', key, value)
  }

  if (!s) return <Frame>Core에 연결되면 설정을 불러옵니다… (상태바의 Core 표시 확인)</Frame>

  const row = 'grid grid-cols-[170px_1fr] items-center gap-3 py-1.5'
  const inputCls = 'rounded border border-neutral-300 px-2 py-1'
  return (
    <Frame>
      <H>🤖 AI (번역 · 요약 · 정리 · 질문)</H>
      <label className={row}>
        <span>기본 AI</span>
        <select
          className={`${inputCls} w-72`}
          value={String(s['ai.provider'])}
          onChange={(e) => save('ai.provider', e.target.value)}
        >
          {providers.map((p) => (
            <option key={p.name} value={p.name}>
              {p.label}
            </option>
          ))}
        </select>
      </label>
      {providers.map((p) => (
        <div key={p.name} className="mb-2 rounded border border-neutral-200 p-2">
          <div className="mb-1 flex items-center gap-2">
            <b>{p.label}</b>
            <span className={p.has_key ? 'text-green-700' : 'text-neutral-500'}>
              {p.has_key ? '✓ 키 등록됨' : '키 없음'}
            </span>
            <a
              className="ml-auto text-indigo-600 underline"
              href={p.key_url}
              target="_blank"
              rel="noreferrer"
            >
              키 발급 페이지
            </a>
          </div>
          <div className="flex gap-2">
            <input
              type="password"
              className={`${inputCls} flex-1`}
              placeholder={p.has_key ? '새 키로 바꾸려면 입력' : 'API 키 붙여넣기'}
              value={keys[p.name] ?? ''}
              onChange={(e) => setKeys({ ...keys, [p.name]: e.target.value })}
            />
            <button
              className="rounded bg-indigo-600 px-2 text-white disabled:opacity-40"
              disabled={!keys[p.name]}
              onClick={async () => {
                if (await safeInvoke('secrets:set', p.name, keys[p.name])) {
                  setKeys({ ...keys, [p.name]: '' })
                  showToast(`${p.label} 키를 OS 키체인에 저장했습니다`)
                  reloadProviders()
                }
              }}
            >
              저장
            </button>
            {p.has_key && (
              <button
                className="rounded border px-2"
                onClick={async () => {
                  await safeInvoke('secrets:delete', p.name)
                  reloadProviders()
                }}
              >
                삭제
              </button>
            )}
          </div>
          <div className="mt-1 flex items-start gap-2">
            <span className="mt-1 w-10 text-neutral-500">모델</span>
            <div className="min-w-0 flex-1">
              <ModelPicker
                provider={p.name}
                kind="chat"
                value={String(s[`ai.model.${p.name}`] ?? p.model ?? '')}
                defaultModel={p.default_model}
                disabled={!p.has_key}
                onChange={(v) => save(`ai.model.${p.name}`, v)}
              />
            </div>
          </div>
        </div>
      ))}
      <div className={row}>
        <span>모델 목록</span>
        <div className="flex flex-wrap items-center gap-2">
          <button
            className="rounded bg-indigo-600 px-2 py-1 text-white"
            onClick={async () => {
              const r =
                await safeInvoke<Record<string, Record<string, unknown>>>('ai:refresh-models')
              if (!r) return
              const done = Object.entries(r)
                .filter(([, v]) => !('skipped' in v))
                .map(([k, v]) => `${k}: ${(v.chat as { count?: number })?.count ?? '오류'}개`)
              showToast(
                done.length
                  ? `최신 모델 목록 갱신 — ${done.join(', ')}`
                  : '키가 등록된 AI가 없습니다'
              )
              reloadProviders()
              setS((prev) => ({ ...prev })) // 모델 선택 상자 다시 그리기
            }}
          >
            🔄 모든 AI·TTS 모델 목록 지금 갱신
          </button>
          <label>
            <input
              type="checkbox"
              checked={Boolean(s['ai.models_auto_refresh'])}
              onChange={(e) => save('ai.models_auto_refresh', e.target.checked)}
            />{' '}
            하루 한 번 자동 갱신
          </label>
          <label title="모델을 '기본값'으로 둔 상태에서 기본 모델이 단종되면 같은 계열의 최신 모델(⭐)을 자동으로 사용">
            <input
              type="checkbox"
              checked={Boolean(s['ai.auto_latest'])}
              onChange={(e) => save('ai.auto_latest', e.target.checked)}
            />{' '}
            단종 시 최신 모델로 자동 대체
          </label>
        </div>
      </div>
      <label className={row}>
        <span>월 사용 한도 (글자 수)</span>
        <div className="flex items-center gap-2">
          <input
            type="number"
            step={100000}
            min={0}
            className={`${inputCls} w-36`}
            defaultValue={Number(s['ai.monthly_char_limit'])}
            onBlur={(e) => save('ai.monthly_char_limit', Number(e.target.value))}
          />
          <span className="text-xs text-neutral-500">
            이번 달 사용:{' '}
            {(usage?.by_provider ?? [])
              .map((u) => `${u.provider} ${u.chars.toLocaleString()}자`)
              .join(', ') || '없음'}{' '}
            (0 = 무제한)
          </span>
        </div>
      </label>
      <label className={row}>
        <span>페이지 번역 최대 문단 수</span>
        <input
          type="number"
          min={10}
          max={2000}
          className={`${inputCls} w-24`}
          defaultValue={Number(s['ai.translate_max_segments'])}
          onBlur={(e) => save('ai.translate_max_segments', Number(e.target.value))}
        />
      </label>
      <p className="text-xs text-neutral-500">
        API 키는 Windows 자격 증명 관리자에 저장되며 화면에는 표시되지 않습니다. 페이지 내용이
        선택한 AI 회사로 전송되므로, 회사 내부 문서·개인정보가 있는 페이지에서는 주의하세요.
      </p>

      <H>🌐 브라우저</H>
      <label className={row}>
        <span>시작·새 탭 페이지</span>
        <input
          className={inputCls}
          defaultValue={String(s['start.url'])}
          onBlur={(e) => save('start.url', e.target.value)}
        />
      </label>
      <label className={row}>
        <span>사이트 호환 모드</span>
        <select
          className={`${inputCls} w-72`}
          value={String(s['browser.user_agent'])}
          onChange={(e) => save('browser.user_agent', e.target.value)}
        >
          <option value="chrome">최신 Chrome으로 표시 (권장)</option>
          <option value="edge">최신 Microsoft Edge로 표시</option>
          <option value="custom">직접 입력한 UA 사용</option>
          <option value="electron">Electron 기본값 (차단될 수 있음)</option>
        </select>
      </label>
      {s['browser.user_agent'] === 'custom' && (
        <label className={row}>
          <span>사용자 지정 UA</span>
          <input
            className={inputCls}
            placeholder="Mozilla/5.0 (Windows NT 10.0; Win64; x64) ..."
            defaultValue={String(s['browser.user_agent_custom'] ?? '')}
            onBlur={(e) => save('browser.user_agent_custom', e.target.value)}
          />
        </label>
      )}
      <div className={row}>
        <span>표시 중인 버전</span>
        <div className="flex items-center gap-2 text-xs">
          <code className="min-w-0 flex-1 truncate rounded bg-neutral-100 px-1" title={ua?.ua}>
            Chrome {ua?.chrome ?? '…'}
          </code>
          <button
            className="rounded border px-2 py-0.5"
            onClick={async () => {
              const r = await safeInvoke<{ chrome: string; ua: string }>('ua:refresh-version')
              if (r) {
                setUa((u) => (u ? { ...u, ...r } : u))
                showToast(`최신 Chrome 안정판: ${r.chrome}`)
              }
            }}
          >
            최신 버전 다시 확인
          </button>
        </div>
      </div>
      <label className={row}>
        <span>차단 화면 감지</span>
        <span>
          <input
            type="checkbox"
            checked={s['browser.block_detect'] !== false}
            onChange={(e) => save('browser.block_detect', e.target.checked)}
          />{' '}
          “Web Page Blocked” 같은 화면이 뜨면 해결 방법 안내
        </span>
      </label>
      <p className="text-xs text-neutral-500">
        일부 기관 사이트는 브라우저 이름표(UA)뿐 아니라 <b>버전이 최신인지</b>, 자바스크립트의
        브라우저 정보까지 검사합니다. OmniBrowser는 Google에서 최신 Chrome 버전을 확인해 UA·Client
        Hints·자바스크립트 정보를 모두 맞춥니다. 그래도 막히면 Edge로 바꿔 보거나 우클릭 → 외부
        브라우저로 열기.
      </p>
      <label className={row}>
        <span>광고·추적기 차단</span>
        <span>
          <input
            type="checkbox"
            checked={Boolean(s['privacy.adblock'])}
            onChange={(e) => save('privacy.adblock', e.target.checked)}
          />{' '}
          켜기 (처음 켤 때 필터 목록을 내려받음)
        </span>
      </label>
      <label className={row}>
        <span>즐겨찾기 배속 (G 키)</span>
        <input
          type="number"
          step="0.25"
          min="0.25"
          max="10"
          className={`${inputCls} w-24`}
          defaultValue={Number(s['media.favorite_rate'])}
          onBlur={(e) => save('media.favorite_rate', Number(e.target.value))}
        />
      </label>
      <div className={row}>
        <span>개인 정보</span>
        <div className="flex gap-2">
          <button className="rounded border px-2 py-1" onClick={() => invoke('browsing:clear')}>
            이 워크스페이스 쿠키·캐시 삭제
          </button>
          <button className="rounded border px-2 py-1" onClick={() => invoke('history:clear')}>
            방문 기록 삭제
          </button>
        </div>
      </div>

      <H>🕸 크롤러</H>
      <div className={row}>
        <span>저장 폴더</span>
        <div className="flex items-center gap-2">
          <span className="truncate text-neutral-600">
            {String(s['crawl.output_dir'] || '다운로드\\OmniBrowser (기본)')}
          </span>
          <button
            className="rounded border px-2 py-1"
            onClick={async () => {
              const dir = await safeInvoke<string | null>('crawl:choose-dir')
              if (dir) void save('crawl.output_dir', dir)
            }}
          >
            바꾸기
          </button>
        </div>
      </div>

      <H>🔊 읽어주기 (TTS)</H>
      <TtsSettings
        s={s}
        save={save}
        keys={Object.fromEntries(providers.map((x) => [x.name, x.has_key]))}
      />

      <H>⌨ 단축키</H>
      <table className="text-sm">
        <tbody>
          {SHORTCUTS.map(([what, key]) => (
            <tr key={what}>
              <td className="py-0.5 pr-6 text-neutral-600">{what}</td>
              <td className="font-mono">{key}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 text-xs text-neutral-500">
        미디어 단축키는 입력창에 글을 쓰는 중에는 동작하지 않습니다. 데이터 폴더:
        %APPDATA%\OmniBrowser
      </p>
      <button
        className="mt-4 rounded border px-3 py-1"
        onClick={() => invoke('cmd:run', 'devtools.ui')}
      >
        UI 개발자 도구
      </button>
    </Frame>
  )
}

function H({ children }: { children: React.ReactNode }): React.JSX.Element {
  return <h3 className="mb-2 mt-6 border-b border-neutral-200 pb-1 font-semibold">{children}</h3>
}

function Frame({ children }: { children: React.ReactNode }): React.JSX.Element {
  return (
    <div className="absolute inset-0 overflow-y-auto bg-white p-6 text-sm">
      <div className="mx-auto max-w-2xl">
        <div className="mb-3 flex items-center">
          <h2 className="text-lg font-bold">설정</h2>
          <button
            className="ml-auto rounded px-2 py-1 hover:bg-neutral-100"
            onClick={() => set({ panel: 'none' })}
          >
            ✕ 닫기
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
