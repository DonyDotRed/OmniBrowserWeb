import DOMPurify from 'dompurify'
import { useEffect, useState } from 'react'
import { invoke, requestAi, safeInvoke, set } from '../stores/app'

interface Page {
  title: string
  byline: string
  html: string
  text: string
  url: string
}
const THEMES = {
  light: 'background:#fff;color:#1f2937',
  sepia: 'background:#f7f0e2;color:#433422',
  dark: 'background:#1f2023;color:#d4d4d8'
}

/**
 * 리더 모드 (CNV-01): 광고·메뉴를 걷어 낸 본문만 읽기 편하게.
 * 본문 HTML은 웹페이지에서 온 신뢰할 수 없는 내용 → 스크립트가 절대 실행되지 않는 sandbox iframe에만 표시.
 */
export function ReaderView(): React.JSX.Element {
  const [page, setPage] = useState<Page | null>(null)
  const [error, setError] = useState('')
  const [size, setSize] = useState(19)
  const [theme, setTheme] = useState<keyof typeof THEMES>('light')

  useEffect(() => {
    invoke<Page>('page:extract')
      .then(setPage)
      .catch((e) =>
        setError(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''))
      )
    void safeInvoke<Record<string, unknown>>('settings:get').then(
      (s) => s && setSize(Number(s['reader.font_size']) || 19)
    )
  }, [])

  const close = (): void => set({ panel: 'none' })
  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') set({ panel: 'none' })
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])
  const body = page?.html
    ? DOMPurify.sanitize(page.html)
    : (page?.text ?? '')
        .split('\n')
        .map((l) => `<p>${DOMPurify.sanitize(l)}</p>`)
        .join('')
  const srcdoc = `<!doctype html><html><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src https: data:; style-src 'unsafe-inline'">
<base target="_blank"><style>
body{${THEMES[theme]};font:${size}px/1.8 "Malgun Gothic","Apple SD Gothic Neo",Georgia,serif;max-width:760px;margin:0 auto;padding:32px 24px 80px}
img,video,figure{max-width:100%;height:auto} a{color:#4f46e5} pre{white-space:pre-wrap} table{border-collapse:collapse} td,th{border:1px solid #ccc;padding:4px}
h1{font-size:1.6em;line-height:1.3}</style></head><body><h1>${DOMPurify.sanitize(page?.title ?? '')}</h1>
<p style="opacity:.6;font-size:.8em">${DOMPurify.sanitize(page?.byline ?? '')} ${DOMPurify.sanitize(page?.url ?? '')}</p>${body}</body></html>`

  const btn = 'rounded px-2 py-1 hover:bg-neutral-200'
  return (
    <div className="absolute inset-0 flex flex-col bg-white">
      <div className="flex flex-wrap items-center gap-1 border-b border-neutral-200 bg-neutral-50 px-3 py-1.5 text-xs">
        <b className="mr-2">📖 리더 모드</b>
        <button className={btn} onClick={() => setSize((s) => Math.max(12, s - 1))}>
          가-
        </button>
        <button className={btn} onClick={() => setSize((s) => Math.min(32, s + 1))}>
          가+
        </button>
        {(Object.keys(THEMES) as (keyof typeof THEMES)[]).map((t) => (
          <button
            key={t}
            className={`${btn} ${theme === t ? 'bg-neutral-200' : ''}`}
            onClick={() => setTheme(t)}
          >
            {{ light: '밝게', sepia: '세피아', dark: '어둡게' }[t]}
          </button>
        ))}
        <span className="mx-1 text-neutral-300">|</span>
        <button
          className={btn}
          disabled={!page}
          onClick={() => page && invoke('tts:text', page.text)}
        >
          🔊 읽어주기
        </button>
        <button
          className={btn}
          disabled={!page}
          onClick={() => page && requestAi('summarize', 'text', page.text)}
        >
          📝 AI 요약
        </button>
        <button
          className={btn}
          disabled={!page}
          onClick={() => page && requestAi('translate', 'text', page.text)}
        >
          🌐 AI 번역
        </button>
        <button
          className={btn}
          disabled={!page}
          onClick={() => page && requestAi('organize', 'text', page.text)}
        >
          🗂 정리
        </button>
        <button className={btn} onClick={() => invoke('page:save', 'md')}>
          💾 .md
        </button>
        <button className={`${btn} ml-auto`} onClick={close}>
          ✕ 닫기 (F9)
        </button>
      </div>
      {error ? (
        <p className="p-6 text-red-600">{error}</p>
      ) : !page ? (
        <p className="p-6 text-neutral-500">본문을 추출하는 중…</p>
      ) : (
        <iframe
          title="reader"
          sandbox="allow-popups"
          className="min-h-0 w-full flex-1"
          srcDoc={srcdoc}
        />
      )}
    </div>
  )
}
