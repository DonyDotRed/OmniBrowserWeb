import { useEffect, useRef, useState } from 'react'
import { renderMarkdown } from '../lib/markdown'
import { ModelPicker } from './ModelPicker'
import { invoke, safeInvoke, set, showToast, useApp, type ChatMsg } from '../stores/app'

interface Provider {
  name: string
  label: string
  default_model: string
  has_key: boolean
  model: string
}
interface Preset {
  id: string
  label: string
  icon: string
}
const LANGS: [string, string][] = [
  ['ko', '한국어'],
  ['en', '영어'],
  ['ja', '일본어'],
  ['zh', '중국어'],
  ['de', '독일어'],
  ['fr', '프랑스어'],
  ['es', '스페인어']
]

/** AI 도우미 (AI-01~08): 번역·요약·정리 프리셋, 페이지 질문, 페이지 제자리 번역 */
export function AiPanel(): React.JSX.Element {
  const { chat, aiSource, aiRequest } = useApp()
  const [providers, setProviders] = useState<Provider[]>([])
  const [presets, setPresets] = useState<Preset[]>([])
  const [provider, setProvider] = useState('')
  const [lang, setLang] = useState('ko')
  const [target, setTarget] = useState<'selection' | 'page'>('page')
  const [question, setQuestion] = useState('')
  const [withPage, setWithPage] = useState(true)
  const [pendingText, setPendingText] = useState<string | null>(null) // 우클릭 "이 내용에 대해 질문"
  const bottom = useRef<HTMLDivElement>(null)
  const input = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    void safeInvoke<Provider[]>('ai:providers').then((p) => p && setProviders(p))
    void safeInvoke<Preset[]>('ai:presets').then((p) => p && setPresets(p))
    void safeInvoke<Record<string, unknown>>('settings:get').then((s) => {
      if (!s) return
      setProvider(String(s['ai.provider']))
      setLang(String(s['ai.lang']))
    })
  }, [])

  useEffect(() => bottom.current?.scrollIntoView({ block: 'end' }), [chat])

  const busy = chat.some((m) => m.streaming)

  const send = async (
    preset: string | null,
    source: 'selection' | 'page' | 'text' | 'none',
    opts: { text?: string; question?: string } = {}
  ): Promise<void> => {
    const jobId = crypto.randomUUID()
    const p = presets.find((x) => x.id === preset)
    const srcLabel = {
      selection: '선택 텍스트',
      page: '페이지 전체',
      text: '선택 텍스트',
      none: ''
    }[source]
    const label = p ? `${p.icon} ${p.label}${srcLabel ? ` · ${srcLabel}` : ''}` : undefined
    const prev = useApp.getState().chat
    // 이어지는 질문: 지난 대화(질문·답변)를 함께 보냄 (최근 10개)
    const history = preset
      ? []
      : prev
          .filter((m) => !m.error && !m.streaming && m.content)
          .slice(-10)
          .map((m) => ({ role: m.role, content: m.content }))
    set({
      chat: [
        ...prev,
        { role: 'user', content: opts.question ?? label ?? '', label },
        { role: 'assistant', content: '', jobId, streaming: true }
      ]
    })
    try {
      const info = await invoke<{ title: string; url: string; chars: number }>('ai:run', {
        jobId,
        preset,
        source,
        text: opts.text,
        question: opts.question,
        history,
        lang,
        provider
      })
      set({ aiSource: info })
    } catch (e) {
      const msg = String((e as Error).message).replace(
        /^Error invoking remote method '[^']+': (Error: )?/,
        ''
      )
      set({
        chat: useApp
          .getState()
          .chat.map((m) => (m.jobId === jobId ? { ...m, streaming: false, error: msg } : m))
      })
    }
  }

  // 우클릭 메뉴·단축키·주소창(?)에서 온 요청 처리
  useEffect(() => {
    if (!aiRequest || presets.length === 0) return
    if (aiRequest.preset) void send(aiRequest.preset, aiRequest.source, { text: aiRequest.text })
    else if (aiRequest.question) void send(null, aiRequest.source, { question: aiRequest.question })
    else if (aiRequest.text) {
      // 외부(우클릭 메뉴)에서 온 요청을 입력 상태로 옮기는 것이라 effect 안에서 설정
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setPendingText(aiRequest.text)
      input.current?.focus()
    }
    set({ aiRequest: null })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aiRequest, presets.length])

  const ask = (): void => {
    const q = question.trim()
    if (!q || busy) return
    setQuestion('')
    if (pendingText) {
      void send(null, 'text', { text: pendingText, question: q })
      setPendingText(null)
    } else void send(null, withPage ? 'page' : 'none', { question: q })
  }

  const current = providers.find((p) => p.name === provider)

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* 제공자 · 언어 */}
      <div className="flex items-center gap-1 border-b border-neutral-200 p-2">
        <select
          className="min-w-0 flex-1 rounded border px-1 py-0.5"
          value={provider}
          onChange={(e) => {
            setProvider(e.target.value)
            void safeInvoke('settings:set', 'ai.provider', e.target.value)
          }}
        >
          {providers.map((p) => (
            <option key={p.name} value={p.name}>
              {p.has_key ? '' : '🔑 '}
              {p.label} · {p.model || p.default_model}
            </option>
          ))}
        </select>
        <select
          className="rounded border px-1 py-0.5"
          value={lang}
          title="결과 언어"
          onChange={(e) => {
            setLang(e.target.value)
            void safeInvoke('settings:set', 'ai.lang', e.target.value)
          }}
        >
          {LANGS.map(([c, n]) => (
            <option key={c} value={c}>
              → {n}
            </option>
          ))}
        </select>
      </div>
      {current && (
        <div className="flex items-center gap-1 border-b border-neutral-200 px-2 py-1 text-xs">
          <span className="text-neutral-500">모델</span>
          <ModelPicker
            compact
            provider={current.name}
            kind="chat"
            value={current.model}
            defaultModel={current.default_model}
            disabled={!current.has_key || current.name === 'mock'}
            onChange={(v) => {
              void safeInvoke('settings:set', `ai.model.${current.name}`, v)
              setProviders((ps) =>
                ps.map((x) => (x.name === current.name ? { ...x, model: v } : x))
              )
            }}
          />
        </div>
      )}
      {current && !current.has_key && (
        <div className="bg-amber-50 p-2 text-xs">
          🔑 {current.label} API 키가 없습니다. ⚙ 설정 → AI에서 등록하세요.
        </div>
      )}

      {/* 대상 + 프리셋 */}
      <div className="border-b border-neutral-200 p-2">
        <div className="mb-1 flex gap-3 text-xs">
          <label>
            <input type="radio" checked={target === 'page'} onChange={() => setTarget('page')} />{' '}
            페이지 전체
          </label>
          <label>
            <input
              type="radio"
              checked={target === 'selection'}
              onChange={() => setTarget('selection')}
            />{' '}
            선택 텍스트
          </label>
        </div>
        <div className="grid grid-cols-3 gap-1">
          {presets.map((p) => (
            <button
              key={p.id}
              disabled={busy}
              onClick={() => void send(p.id, target)}
              className="rounded border border-neutral-200 bg-white px-1 py-1 text-xs hover:bg-indigo-50 disabled:opacity-40"
            >
              {p.icon} {p.label}
            </button>
          ))}
        </div>
        <div className="mt-1 flex gap-1 text-xs">
          <button
            className="flex-1 rounded bg-indigo-600 px-1 py-1 text-white"
            onClick={() => invoke('page:translate', 'bilingual')}
          >
            🌐 페이지 번역(대역)
          </button>
          <button
            className="rounded border px-1 py-1"
            onClick={() => invoke('page:translate', 'replace')}
          >
            번역만
          </button>
          <button
            className="rounded border px-1 py-1"
            onClick={() => invoke('cmd:run', 'page.restore')}
          >
            원문
          </button>
        </div>
      </div>

      {/* 대화 */}
      <div className="min-h-0 flex-1 overflow-y-auto p-2">
        {chat.length === 0 && (
          <div className="p-2 text-xs leading-relaxed text-neutral-500">
            위 버튼으로 페이지를 요약·번역·정리하거나, 아래에 질문을 입력하세요.
            <br />
            페이지에서 텍스트를 드래그한 뒤 <b>우클릭 → 🤖 AI</b>, 주소창에 <b>?질문</b>,{' '}
            <b>Alt+S</b>(페이지 요약), <b>Alt+T</b>(페이지 번역)도 쓸 수 있습니다.
          </div>
        )}
        {aiSource && chat.length > 0 && (
          <div className="mb-2 truncate text-[11px] text-neutral-400" title={aiSource.url}>
            대상: {aiSource.title} {aiSource.chars ? `(${aiSource.chars.toLocaleString()}자)` : ''}
          </div>
        )}
        {chat.map((m, i) => (
          <Message key={i} m={m} />
        ))}
        <div ref={bottom} />
      </div>

      {/* 질문 입력 */}
      <div className="border-t border-neutral-200 p-2">
        {pendingText && (
          <div className="mb-1 flex items-start gap-1 rounded bg-neutral-100 p-1 text-xs">
            <span className="line-clamp-2 flex-1">💬 “{pendingText}”</span>
            <button onClick={() => setPendingText(null)}>✕</button>
          </div>
        )}
        <textarea
          ref={input}
          rows={2}
          className="w-full resize-none rounded border border-neutral-300 p-1.5"
          placeholder="질문 입력 (Enter 전송, Shift+Enter 줄바꿈)"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault()
              ask()
            }
          }}
        />
        <div className="flex items-center gap-2 text-xs">
          <label title="현재 페이지 본문을 근거 자료로 함께 보냅니다">
            <input
              type="checkbox"
              checked={withPage}
              onChange={(e) => setWithPage(e.target.checked)}
            />{' '}
            페이지 내용 포함
          </label>
          <button
            className="ml-auto text-neutral-500"
            onClick={() => set({ chat: [], aiSource: null })}
          >
            대화 지우기
          </button>
          <button
            className="rounded bg-indigo-600 px-3 py-1 text-white disabled:opacity-40"
            disabled={busy}
            onClick={ask}
          >
            보내기
          </button>
        </div>
      </div>
    </div>
  )
}

function Message({ m }: { m: ChatMsg }): React.JSX.Element {
  if (m.role === 'user') {
    return (
      <div className="my-2 ml-8 rounded-lg bg-indigo-600 px-2 py-1.5 text-white">
        {m.label ?? m.content}
      </div>
    )
  }
  const act = 'rounded px-1.5 py-0.5 hover:bg-neutral-200'
  return (
    <div className="my-2 rounded-lg border border-neutral-200 bg-white p-2">
      {m.content ? (
        <div
          className="omni-md text-[13px] leading-relaxed"
          // 링크 클릭 → Main이 새 탭으로 연다 (setWindowOpenHandler)
          onClick={(e) => {
            const a = (e.target as HTMLElement).closest('a')
            if (a) {
              e.preventDefault()
              window.open(a.href)
            }
          }}
          dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }}
        />
      ) : (
        m.streaming && <div className="animate-pulse text-neutral-400">생각 중…</div>
      )}
      {m.error && <div className="mt-1 text-xs text-red-600">⚠ {m.error}</div>}
      <div className="mt-1 flex flex-wrap gap-1 text-[11px] text-neutral-500">
        {m.streaming ? (
          <button className={act} onClick={() => m.jobId && invoke('ai:stop', m.jobId)}>
            ⏹ 중지
          </button>
        ) : (
          m.content && (
            <>
              <button
                className={act}
                onClick={async () => {
                  await invoke('clipboard:write', m.content)
                  showToast('복사했습니다')
                }}
              >
                📋 복사
              </button>
              <button
                className={act}
                onClick={async () => {
                  const { tabs, activeId } = useApp.getState()
                  const t = tabs.find((x) => x.id === activeId)
                  await safeInvoke('notes:add', {
                    url: t?.url ?? '',
                    title: t?.title ?? '',
                    body: m.content
                  })
                  showToast('메모에 저장했습니다')
                }}
              >
                🗒 메모
              </button>
              <button
                className={act}
                onClick={() =>
                  invoke('ai:save-md', m.content, useApp.getState().aiSource?.title ?? '')
                }
              >
                💾 .md
              </button>
              <button
                className={act}
                onClick={() => invoke('tts:text', m.content.replace(/[#*`>|_-]+/g, ' '))}
              >
                🔊 읽기
              </button>
            </>
          )
        )}
      </div>
    </div>
  )
}
