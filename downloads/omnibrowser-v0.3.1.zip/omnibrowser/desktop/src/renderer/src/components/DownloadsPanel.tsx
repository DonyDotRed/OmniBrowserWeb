import { useEffect, useState } from 'react'
import { invoke } from '../stores/app'

interface Dl {
  id: number
  filename: string
  url: string
  path: string
  state: string
  received: number
  total: number
}

const mb = (n: number): string => `${(n / 1048576).toFixed(1)}MB`

/** 다운로드 목록 (CNV-02): 진행률·열기·폴더·취소 */
export function DownloadsPanel(): React.JSX.Element {
  const [list, setList] = useState<Dl[]>([])
  useEffect(() => {
    void invoke<Dl[]>('downloads:list').then(setList)
    return window.omni.on('downloads:state', (p) => setList(p as Dl[]))
  }, [])

  return (
    <div className="h-full overflow-y-auto p-2 text-xs">
      <div className="mb-2 flex">
        <b>다운로드</b>
        <button className="ml-auto text-neutral-500" onClick={() => invoke('downloads:clear')}>
          완료 항목 지우기
        </button>
      </div>
      {list.length === 0 && (
        <p className="text-neutral-500">이번 실행 중 받은 파일이 여기에 표시됩니다.</p>
      )}
      {list.map((d) => {
        const pct = d.total ? Math.round((d.received / d.total) * 100) : 0
        return (
          <div key={d.id} className="mb-2 rounded border border-neutral-200 bg-white p-2">
            <div className="truncate font-semibold" title={d.url}>
              {d.filename}
            </div>
            {d.state === 'progressing' ? (
              <>
                <div className="my-1 h-1.5 rounded bg-neutral-200">
                  <div className="h-1.5 rounded bg-indigo-500" style={{ width: `${pct}%` }} />
                </div>
                <div className="flex">
                  {mb(d.received)} / {d.total ? mb(d.total) : '?'}
                  <button className="ml-auto" onClick={() => invoke('downloads:cancel', d.id)}>
                    취소
                  </button>
                </div>
              </>
            ) : (
              <div className="flex gap-2">
                <span className={d.state === 'completed' ? 'text-green-700' : 'text-red-600'}>
                  {d.state === 'completed'
                    ? `완료 · ${mb(d.received)}`
                    : d.state === 'cancelled'
                      ? '취소됨'
                      : '실패'}
                </span>
                {d.state === 'completed' && (
                  <>
                    <button
                      className="ml-auto text-indigo-600"
                      onClick={() => invoke('downloads:open', d.id)}
                    >
                      열기
                    </button>
                    <button
                      className="text-indigo-600"
                      onClick={() => invoke('downloads:show', d.id)}
                    >
                      폴더
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
