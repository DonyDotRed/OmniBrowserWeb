import { useEffect, useState } from 'react'
import { invoke, safeInvoke, showToast } from '../stores/app'
import { ModelPicker } from './ModelPicker'

type Settings = Record<string, unknown>
interface LocalStatus {
  engine_installed: boolean
  model?: string
  models?: string[]
  dir?: string
  default_dir?: string
  shared_dir?: string
  shared_installed?: boolean
  custom?: boolean
  installed?: boolean
  voices?: string[]
  size_mb?: number
  job: { state: string; message: string; target: string }
}

const ENGINES: [string, string][] = [
  ['supertonic', 'Supertonic 3 (로컬·무료·오프라인)'],
  ['gemini', 'Google Gemini TTS (클라우드·유료)'],
  ['openai', 'OpenAI TTS (클라우드·유료)']
]

/** 설정 → 읽어주기: 엔진 3종, 엔진별 음성·모델, 로컬 모델 폴더 관리 */
export function TtsSettings(p: {
  s: Settings
  save: (k: string, v: unknown) => Promise<void>
  keys: Record<string, boolean>
}): React.JSX.Element {
  const { s, save } = p
  const engine = String(s['tts.provider'])
  const [voices, setVoices] = useState<string[]>([])
  const [local, setLocal] = useState<LocalStatus | null>(null)
  const [pendingDir, setPendingDir] = useState<string | null>(null) // 복사가 끝나면 사용할 폴더

  useEffect(() => {
    void safeInvoke<string[]>('tts:voices', engine).then((v) => v && setVoices(v))
  }, [engine, local?.dir])

  const refreshLocal = async (): Promise<void> => {
    const st = await safeInvoke<LocalStatus>('tts:local-status')
    if (st) setLocal(st)
  }
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- 처음 열 때 상태 불러오기
    void refreshLocal()
  }, [])
  // 다운로드·복사 진행 중이면 2초마다 상태 확인
  useEffect(() => {
    if (local?.job.state !== 'running') return
    const t = setInterval(() => void refreshLocal(), 2000)
    return () => clearInterval(t)
  }, [local?.job.state])
  // 복사가 끝나면 새 폴더를 설정으로 저장
  useEffect(() => {
    if (!pendingDir || !local || local.job.state === 'running') return
    const dir = pendingDir
    // eslint-disable-next-line react-hooks/set-state-in-effect -- 복사 작업 완료(외부 상태)에 반응
    setPendingDir(null)
    if (local.job.state !== 'done') return
    void (async () => {
      await save('tts.local.model_dir', dir)
      await safeInvoke('tts:local-reload')
      void refreshLocal()
      showToast('모델을 복사했고, 이제 새 폴더의 모델을 사용합니다')
    })()
  }, [local, pendingDir, save])

  const row = 'grid grid-cols-[170px_1fr] items-center gap-3 py-1.5'
  const box = 'rounded border border-neutral-300 px-2 py-1'
  const voiceKey = `tts.voice.${engine}`

  const chooseDir = async (): Promise<void> => {
    const dir = await safeInvoke<string | null>('dialog:choose-dir', '로컬 TTS 모델 폴더 선택')
    if (!dir) return
    const st = await safeInvoke<LocalStatus>('tts:local-status', dir)
    if (!st) return
    await save('tts.local.model_dir', st.dir) // onnx 하위 폴더를 골라도 모델 폴더로 보정된 경로
    await safeInvoke('tts:local-reload')
    setLocal(await safeInvoke<LocalStatus>('tts:local-status'))
    showToast(
      st.installed
        ? `✓ 이 폴더의 모델을 사용합니다 (${st.size_mb}MB)`
        : '이 폴더에 모델이 없습니다 — "이 폴더로 모델 받기"를 누르세요'
    )
  }

  return (
    <>
      <label className={row}>
        <span>엔진</span>
        <select
          className={`${box} w-80`}
          value={engine}
          onChange={(e) => save('tts.provider', e.target.value)}
        >
          {ENGINES.map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </select>
      </label>
      {engine !== 'supertonic' && !p.keys[engine] && (
        <p className="text-xs text-amber-700">
          🔑 {engine === 'gemini' ? 'Gemini' : 'OpenAI'} 키가 필요합니다 — 위 AI 항목에서 등록 (AI와
          같은 키 사용)
        </p>
      )}
      <label className={row}>
        <span>음성</span>
        <div className="flex gap-2">
          <select
            className={`${box} w-48`}
            value={String(s[voiceKey] ?? '')}
            onChange={(e) => save(voiceKey, e.target.value)}
          >
            {voices.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
          <button
            className="rounded border px-2"
            onClick={() =>
              invoke(
                'tts:text',
                '안녕하세요. 옴니브라우저 읽어주기 테스트입니다. Hello, this is a test.'
              )
            }
          >
            ▶ 들어 보기
          </button>
        </div>
      </label>
      {engine !== 'supertonic' && (
        <div className={row}>
          <span>{engine === 'gemini' ? 'Gemini' : 'OpenAI'} TTS 모델</span>
          <ModelPicker
            provider={engine}
            kind="tts"
            value={String(s[`tts.${engine}.model`] ?? '')}
            defaultModel={engine === 'gemini' ? 'gemini-3.1-flash-tts-preview' : 'gpt-4o-mini-tts'}
            disabled={!p.keys[engine]}
            onChange={(v) =>
              save(
                `tts.${engine}.model`,
                v || (engine === 'gemini' ? 'gemini-3.1-flash-tts-preview' : 'gpt-4o-mini-tts')
              )
            }
          />
        </div>
      )}
      {engine === 'gemini' && (
        <label className={row}>
          <span>말투 지시 (선택)</span>
          <input
            className={box}
            placeholder="예: 차분하고 또박또박, 뉴스 앵커처럼 읽어 주세요"
            defaultValue={String(s['tts.gemini.style'] ?? '')}
            onBlur={(e) => save('tts.gemini.style', e.target.value.trim())}
          />
        </label>
      )}
      <label className={row}>
        <span>기본 읽기 속도</span>
        <input
          type="number"
          step="0.1"
          min="0.5"
          max="3"
          className={`${box} w-24`}
          defaultValue={Number(s['tts.rate'])}
          onBlur={(e) => save('tts.rate', Number(e.target.value))}
        />
      </label>

      <div className="mt-2 rounded border border-neutral-200 p-2">
        <b>로컬 모델 (Supertonic) 저장 폴더</b>
        {!local ? (
          <p className="text-xs text-neutral-500">확인 중…</p>
        ) : !local.engine_installed ? (
          <p className="text-xs text-red-600">
            Supertonic이 설치되지 않았습니다 — setup.bat을 다시 실행하세요.
          </p>
        ) : (
          <>
            <div className="mt-1 flex items-center gap-2 text-xs">
              <span className="w-12 text-neutral-500">모델</span>
              <select
                className={box}
                value={local.model}
                onChange={async (e) => {
                  await save('tts.local.model', e.target.value)
                  await safeInvoke('tts:local-reload')
                  void refreshLocal()
                }}
              >
                {local.models?.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
              <span className={local.installed ? 'text-green-700' : 'text-amber-700'}>
                {local.installed
                  ? `✓ 설치됨 · ${local.size_mb}MB · 음성 ${local.voices?.length}개`
                  : '⚠ 이 폴더에 모델 없음'}
              </span>
            </div>
            <div className="mt-1 flex items-center gap-2 text-xs">
              <span className="w-12 text-neutral-500">폴더</span>
              <code
                className="min-w-0 flex-1 truncate rounded bg-neutral-100 px-1"
                title={local.dir}
              >
                {local.dir}
              </code>
            </div>
            <div className="mt-1 flex flex-wrap gap-1 text-xs">
              <button className="rounded border px-2 py-0.5" onClick={() => void chooseDir()}>
                📂 다른 폴더 선택
              </button>
              {local.custom && (
                <button
                  className="rounded border px-2 py-0.5"
                  onClick={async () => {
                    await save('tts.local.model_dir', '')
                    await safeInvoke('tts:local-reload')
                    void refreshLocal()
                  }}
                >
                  기본 폴더로
                </button>
              )}
              <button
                className="rounded border px-2 py-0.5 disabled:opacity-40"
                disabled={local.job.state === 'running'}
                onClick={async () => {
                  const st = await safeInvoke<LocalStatus>('tts:local-download')
                  if (st) setLocal(st)
                }}
              >
                ⬇ 이 폴더로 모델 받기
              </button>
              <button
                className="rounded border px-2 py-0.5 disabled:opacity-40"
                disabled={!local.installed || local.job.state === 'running'}
                title="지금 모델을 다른 폴더(예: D 드라이브)로 복사한 뒤 그 폴더를 사용합니다"
                onClick={async () => {
                  const dir = await safeInvoke<string | null>(
                    'dialog:choose-dir',
                    '모델을 복사할 폴더 선택'
                  )
                  if (!dir) return
                  if (await safeInvoke('tts:local-copy', dir)) {
                    setPendingDir(dir)
                    void refreshLocal()
                  }
                }}
              >
                📋 다른 폴더로 복사해 사용
              </button>
              <label className="ml-auto">
                <input
                  type="checkbox"
                  checked={Boolean(s['tts.local.auto_download'])}
                  onChange={(e) => save('tts.local.auto_download', e.target.checked)}
                />{' '}
                없으면 자동으로 받기
              </label>
            </div>
            {local.job.state !== 'idle' && (
              <p
                className={`mt-1 text-xs ${local.job.state === 'error' ? 'text-red-600' : 'text-neutral-600'}`}
              >
                {local.job.state === 'running' ? '⏳' : local.job.state === 'done' ? '✓' : '⚠'}{' '}
                {local.job.message} ({local.job.target})
              </p>
            )}
            <p className="mt-1 text-[11px] text-neutral-500">
              기본 폴더(OmniBrowser 전용): {local.default_dir}.{' '}
              {local.shared_installed && !local.installed
                ? `공용 폴더(${local.shared_dir})에 모델이 있어 처음 읽을 때 인터넷 없이 복사해 씁니다. `
                : ''}
              다른 Supertonic 앱과 같은 폴더를 함께 쓰면 동시에 실행할 때 충돌할 수 있어, 공용
              폴더는 읽기만 합니다. 다른 PC에서 받은 모델 폴더(onnx·voice_styles 포함)를 복사해 와서
              골라도 됩니다.
            </p>
          </>
        )}
      </div>
    </>
  )
}
