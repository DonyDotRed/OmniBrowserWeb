import { useState } from 'react'
import { getTtsRate, setTtsRate } from '../lib/tts-player'
import { invoke, useApp } from '../stores/app'

const RATES = [1, 1.25, 1.5, 2, 3]

/** 상태바: Core 연결 · 확대율 · 영상 배속 · TTS 플레이어 · 알림 */
export function StatusBar(): React.JSX.Element {
  const { coreStatus, mediaRate, tabs, activeId, toast, tts } = useApp()
  const active = tabs.find((t) => t.id === activeId)
  const [ttsRate, setRate] = useState(getTtsRate())
  const core =
    coreStatus === 'ready' ? (
      <span className="text-green-700">Core ✓</span>
    ) : coreStatus === 'failed' ? (
      <span className="text-red-600" title="명령 프롬프트에서 uv run poe doctor 실행">
        Core ✕
      </span>
    ) : (
      <span className="text-neutral-500">Core 연결 중…</span>
    )

  return (
    <div className="flex h-7 items-center gap-3 border-t border-neutral-200 bg-neutral-100 px-3 text-xs">
      {core}
      {active && active.zoom !== 100 && <span>🔍 {active.zoom}%</span>}
      <span className="flex items-center gap-1">
        <span title="영상 배속 (S/D ±0.1, Shift ±0.5, R 1.0x 토글, G 즐겨찾기)">
          🎬 {mediaRate ? `${mediaRate.toFixed(2)}×` : '-'}
        </span>
        {RATES.map((r) => (
          <button
            key={r}
            className="rounded px-1 hover:bg-neutral-200"
            onClick={() => invoke('media:set-rate', r)}
          >
            {r}×
          </button>
        ))}
      </span>

      {tts.active && (
        <span className="flex min-w-0 items-center gap-2 rounded bg-indigo-50 px-2">
          <span>
            🔊 {tts.index}/{tts.total}
          </span>
          <span className="max-w-64 truncate text-neutral-600">{tts.text}</span>
          <select
            value={ttsRate}
            onChange={(e) => {
              setTtsRate(Number(e.target.value))
              setRate(Number(e.target.value))
            }}
          >
            {[0.8, 1, 1.2, 1.5, 2].map((r) => (
              <option key={r} value={r}>
                {r}×
              </option>
            ))}
          </select>
          <button title="읽기 중지" onClick={() => invoke('tts:stop')}>
            ⏹
          </button>
        </span>
      )}

      <span className="ml-auto truncate text-neutral-700">{toast}</span>
    </div>
  )
}
