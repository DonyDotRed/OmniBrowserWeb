import { invoke, set, useApp } from '../stores/app'

/** 차단 화면("Web Page Blocked!" 등) 감지 시 해결 방법 안내 막대 */
export function BlockedBar(): React.JSX.Element | null {
  const blocked = useApp((s) => s.blocked)
  if (!blocked) return null
  const host = (() => {
    try {
      return new URL(blocked.url).host
    } catch {
      return blocked.url
    }
  })()
  const btn = 'rounded border border-amber-400 bg-white px-2 py-0.5 hover:bg-amber-100'
  const retry = (mode: string): void => {
    set({ blocked: null })
    void invoke('ua:retry', mode)
  }
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-amber-300 bg-amber-50 px-3 py-1.5 text-xs">
      <span>
        ⚠ <b>{host}</b> 사이트가 브라우저를 차단한 것 같습니다 (현재:{' '}
        {blocked.mode === 'edge' ? 'Edge' : blocked.mode === 'chrome' ? 'Chrome' : blocked.mode}{' '}
        {blocked.chrome}).
      </span>
      {blocked.mode !== 'edge' && (
        <button className={btn} onClick={() => retry('edge')}>
          Edge로 표시하고 다시 시도
        </button>
      )}
      {blocked.mode !== 'chrome' && (
        <button className={btn} onClick={() => retry('chrome')}>
          Chrome으로 표시하고 다시 시도
        </button>
      )}
      <button
        className={btn}
        onClick={() => {
          set({ blocked: null })
          void invoke('cmd:run', 'open.external')
        }}
      >
        외부 브라우저로 열기
      </button>
      <button className="ml-auto text-neutral-500" onClick={() => set({ blocked: null })}>
        ✕
      </button>
    </div>
  )
}
