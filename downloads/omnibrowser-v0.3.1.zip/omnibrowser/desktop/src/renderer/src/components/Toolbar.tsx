import { invoke, set, useApp } from '../stores/app'
import { Omnibox } from './Omnibox'

export function Toolbar(): React.JSX.Element {
  const { tabs, activeId, bookmarks, panel, right } = useApp()
  const active = tabs.find((t) => t.id === activeId)
  const starred = !!active && bookmarks.some((b) => b.url === active.url)
  const btn = 'rounded px-2 py-1 hover:bg-neutral-200 disabled:opacity-30'

  return (
    <div className="flex items-center gap-1 border-b border-neutral-200 bg-neutral-100 px-2 py-1.5">
      <button
        className={btn}
        title="뒤로 (Alt+←)"
        disabled={!active?.canGoBack}
        onClick={() => invoke('cmd:run', 'nav.back')}
      >
        ◀
      </button>
      <button
        className={btn}
        title="앞으로 (Alt+→)"
        disabled={!active?.canGoForward}
        onClick={() => invoke('cmd:run', 'nav.forward')}
      >
        ▶
      </button>
      <button className={btn} title="새로고침 (F5)" onClick={() => invoke('cmd:run', 'nav.reload')}>
        {active?.loading ? '✕' : '⟳'}
      </button>
      <Omnibox />
      <button className={btn} title="북마크 (Ctrl+D)" onClick={() => invoke('bookmarks:toggle')}>
        <span className={starred ? 'text-amber-500' : ''}>{starred ? '★' : '☆'}</span>
      </button>
      <button
        className={btn}
        title="리더 모드 (F9)"
        onClick={() => set({ panel: panel === 'reader' ? 'none' : 'reader' })}
      >
        📖
      </button>
      <button
        className={btn}
        title="페이지 번역 — 원문+번역 (Alt+T)"
        onClick={() => invoke('page:translate', 'bilingual')}
      >
        🌐
      </button>
      <button
        className={`${btn} ${right === 'ai' ? 'bg-neutral-200' : ''}`}
        title="AI 도우미 (Ctrl+Shift+A)"
        onClick={() => set({ right: right === 'ai' ? null : 'ai' })}
      >
        🤖
      </button>
      <button
        className={`${btn} ${right === 'crawl' ? 'bg-neutral-200' : ''}`}
        title="크롤러·일괄 다운로드 (Ctrl+Shift+L)"
        onClick={() => set({ right: right === 'crawl' ? null : 'crawl' })}
      >
        🕸
      </button>
      <button className={btn} title="선택 텍스트 읽기 (Alt+R)" onClick={() => invoke('tts:read')}>
        🔊
      </button>
      <button
        className={btn}
        title="페이지 저장 (Ctrl+S)"
        onClick={() => invoke('cmd:run', 'page.save.menu')}
      >
        💾
      </button>
      <button
        className={btn}
        title="명령 팔레트 (Ctrl+K)"
        onClick={() => set({ panel: 'palette' })}
      >
        ⌘
      </button>
      <button className={btn} title="더 보기" onClick={() => invoke('menu:more')}>
        ⋯
      </button>
      <button
        className={`${btn} ${panel === 'settings' ? 'bg-neutral-200' : ''}`}
        title="설정"
        onClick={() => set({ panel: panel === 'settings' ? 'none' : 'settings' })}
      >
        ⚙
      </button>
    </div>
  )
}
