import { useEffect, useRef, useState } from 'react'
import { invoke, set, useApp } from '../stores/app'

/** 페이지 내 검색 (Ctrl+F) */
export function FindBar(): React.JSX.Element | null {
  const { findOpen, findResult } = useApp()
  const [text, setText] = useState('')
  const [last, setLast] = useState('')
  const input = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (findOpen) {
      input.current?.focus()
      input.current?.select()
    }
  }, [findOpen])

  if (!findOpen) return null
  const close = (): void => {
    void invoke('find:stop')
    set({ findOpen: false, findResult: null })
  }
  const find = (forward: boolean): void => {
    if (!text) return
    void invoke('find:query', text, forward, text === last) // 같은 단어면 "다음 결과"
    setLast(text)
  }

  return (
    <div className="flex items-center gap-2 border-b border-neutral-200 bg-amber-50 px-3 py-1 text-sm">
      <span>페이지에서 찾기</span>
      <input
        ref={input}
        className="w-64 rounded border border-neutral-300 px-2 py-0.5"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.nativeEvent.isComposing) find(!e.shiftKey)
          if (e.key === 'Escape') close()
        }}
      />
      <span className="w-16 text-neutral-500">
        {findResult ? `${findResult.active}/${findResult.matches}` : ''}
      </span>
      <button onClick={() => find(false)}>▲</button>
      <button onClick={() => find(true)}>▼</button>
      <button onClick={close}>✕</button>
      <span className="text-xs text-neutral-400">Enter 다음 · Shift+Enter 이전 · Esc 닫기</span>
    </div>
  )
}
