import { useEffect, useMemo, useRef, useState } from 'react'
import { invoke, requestAi, set, useApp } from '../stores/app'

interface Item {
  label: string
  hint?: string
  run: () => void
}

const cmd = (id: string) => () => void invoke('cmd:run', id)

/** 명령 팔레트 (Ctrl+K): 모든 기능·열린 탭·북마크·방문 기록을 한 곳에서 검색해 실행 */
export function CommandPalette(): React.JSX.Element {
  const { tabs, bookmarks, workspaceId } = useApp()
  const [q, setQ] = useState('')
  const [sel, setSel] = useState(0)
  const [history, setHistory] = useState<{ url: string; title: string }[]>([])
  const input = useRef<HTMLInputElement>(null)
  useEffect(() => input.current?.focus(), [])

  useEffect(() => {
    if (q.trim().length < 1) return
    const t = setTimeout(() => {
      void invoke<{ url: string; title: string }[]>('history:search', q)
        .then((r) => setHistory(r))
        .catch(() => {})
    }, 150)
    return () => clearTimeout(t)
  }, [q])

  const close = (): void => set({ panel: 'none' })

  const commands: Item[] = useMemo(
    () => [
      { label: '🤖 AI 도우미 열기', hint: 'Ctrl+Shift+A', run: () => set({ right: 'ai' }) },
      { label: '📝 이 페이지 AI 요약', hint: 'Alt+S', run: () => requestAi('summarize', 'page') },
      { label: '🗂 이 페이지 AI 정리 노트', run: () => requestAi('organize', 'page') },
      {
        label: '🌐 페이지 번역 (원문+번역)',
        hint: 'Alt+T',
        run: () => void invoke('page:translate', 'bilingual')
      },
      { label: '🌐 페이지 번역 (번역만)', run: () => void invoke('page:translate', 'replace') },
      { label: '↩ 번역 전 원문으로', hint: 'Alt+Shift+T', run: cmd('page.restore') },
      { label: '📖 리더 모드', hint: 'F9', run: () => set({ panel: 'reader' }) },
      { label: '🔊 본문 전체 읽어주기', run: cmd('tts.page') },
      { label: '🔊 선택 텍스트 읽기', hint: 'Alt+R', run: cmd('tts.read') },
      {
        label: '🕸 크롤러 · 일괄 다운로드',
        hint: 'Ctrl+Shift+L',
        run: () => set({ right: 'crawl' })
      },
      { label: '💾 PDF로 저장', run: () => void invoke('page:save', 'pdf') },
      {
        label: '💾 전체 페이지 이미지(PNG)',
        hint: 'Ctrl+Shift+S',
        run: () => void invoke('page:save', 'png')
      },
      { label: '💾 Markdown으로 저장', run: () => void invoke('page:save', 'md') },
      { label: '📋 본문을 Markdown으로 복사', run: () => void invoke('page:save', 'md-copy') },
      { label: '💾 MHTML(웹 보관)로 저장', run: () => void invoke('page:save', 'mhtml') },
      { label: '📷 보이는 화면 클립보드 복사', run: () => void invoke('page:save', 'shot-copy') },
      { label: '🖨 인쇄', hint: 'Ctrl+P', run: cmd('page.print') },
      { label: '🌙 다크 모드 (이 사이트)', hint: 'Alt+Shift+D', run: cmd('page.dark') },
      { label: '⧉ PiP (강제)', hint: 'Alt+P', run: cmd('media.pip') },
      { label: '🗒 메모', hint: 'Ctrl+Shift+N', run: () => set({ right: 'notes' }) },
      { label: '⬇ 다운로드 목록', hint: 'Ctrl+J', run: () => set({ right: 'downloads' }) },
      { label: '🕘 방문 기록', hint: 'Ctrl+H', run: () => set({ sidebar: 'history' }) },
      { label: '★ 북마크 추가/삭제', hint: 'Ctrl+D', run: () => void invoke('bookmarks:toggle') },
      { label: '🔍 페이지에서 찾기', hint: 'Ctrl+F', run: () => set({ findOpen: true }) },
      { label: '➕ 새 탭', hint: 'Ctrl+T', run: cmd('tab.new') },
      { label: '↺ 닫은 탭 다시 열기', hint: 'Ctrl+Shift+T', run: cmd('tab.reopen') },
      { label: '🔇 탭 음소거', hint: 'Ctrl+Shift+M', run: cmd('tab.mute') },
      { label: '🔍 확대 / 축소 원래대로', hint: 'Ctrl+0', run: cmd('zoom.reset') },
      { label: '↗ 외부 브라우저로 열기', run: cmd('open.external') },
      { label: '⚙ 설정', run: () => set({ panel: 'settings' }) },
      { label: '🧹 이 워크스페이스 쿠키·캐시 삭제', run: () => void invoke('browsing:clear') },
      { label: '🛠 개발자 도구 (페이지)', hint: 'F12', run: cmd('devtools.tab') }
    ],
    []
  )

  const items: Item[] = useMemo(() => {
    const k = q.trim().toLowerCase()
    const match = (s: string): boolean => !k || s.toLowerCase().includes(k)
    const out: Item[] = []
    if (k.startsWith('?') && k.length > 1)
      out.push({
        label: `🤖 AI에게 질문: ${q.trim().slice(1)}`,
        run: () => requestAi(null, 'none', undefined, q.trim().slice(1))
      })
    out.push(...commands.filter((c) => match(c.label)))
    out.push(
      ...tabs
        .filter((t) => t.workspaceId === workspaceId && match(`${t.title} ${t.url}`))
        .map((t) => ({
          label: `🗂 탭: ${t.title || t.url}`,
          run: () => void invoke('tabs:activate', t.id)
        }))
    )
    if (k) {
      out.push(
        ...bookmarks
          .filter((b) => match(`${b.title} ${b.url}`))
          .map((b) => ({
            label: `★ ${b.title}`,
            hint: b.url,
            run: () => void invoke('tabs:create', b.url)
          }))
      )
      out.push(
        ...history.slice(0, 8).map((h) => ({
          label: `🕘 ${h.title || h.url}`,
          hint: h.url,
          run: () => void invoke('tabs:create', h.url)
        }))
      )
    }
    return out.slice(0, 60)
  }, [q, commands, tabs, bookmarks, history, workspaceId])

  const exec = (i: number): void => {
    const it = items[i]
    if (!it) return
    close()
    it.run()
  }

  return (
    <div className="absolute inset-0 bg-black/10 p-6" onMouseDown={close}>
      <div
        className="mx-auto max-w-2xl overflow-hidden rounded-xl border border-neutral-200 bg-white shadow-2xl"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <input
          ref={input}
          className="w-full border-b border-neutral-200 px-4 py-3 text-base outline-none"
          placeholder="기능·탭·북마크·기록 검색  ( ?로 시작하면 AI에게 질문 )"
          value={q}
          onChange={(e) => {
            setQ(e.target.value)
            setSel(0)
          }}
          onKeyDown={(e) => {
            if (e.key === 'Escape') close()
            else if (e.key === 'ArrowDown') {
              e.preventDefault()
              setSel((s) => Math.min(s + 1, items.length - 1))
            } else if (e.key === 'ArrowUp') {
              e.preventDefault()
              setSel((s) => Math.max(s - 1, 0))
            } else if (e.key === 'Enter' && !e.nativeEvent.isComposing) exec(sel)
          }}
        />
        <div className="max-h-[60vh] overflow-y-auto">
          {items.map((it, i) => (
            <button
              key={`${it.label}-${i}`}
              onMouseEnter={() => setSel(i)}
              onClick={() => exec(i)}
              className={`flex w-full items-center gap-2 px-4 py-2 text-left ${i === sel ? 'bg-indigo-50' : ''}`}
            >
              <span className="min-w-0 flex-1 truncate">{it.label}</span>
              {it.hint && (
                <span className="max-w-64 truncate text-xs text-neutral-400">{it.hint}</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
