import { set, useApp, type RightPanel as R } from '../stores/app'
import { AiPanel } from './AiPanel'
import { CrawlPanel } from './CrawlPanel'
import { DownloadsPanel } from './DownloadsPanel'
import { NotesPanel } from './NotesPanel'

const TABS: [Exclude<R, null>, string][] = [
  ['ai', '🤖 AI'],
  ['crawl', '🕸 크롤러'],
  ['notes', '🗒 메모'],
  ['downloads', '⬇ 다운로드']
]

/** 오른쪽 도구 패널: 열려 있으면 웹페이지 영역이 그만큼 좁아진다 */
export function RightPanel(): React.JSX.Element | null {
  const right = useApp((s) => s.right)
  if (!right) return null
  return (
    <aside className="flex w-[380px] shrink-0 flex-col border-l border-neutral-200 bg-neutral-50 text-sm">
      <div className="flex border-b border-neutral-200">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => set({ right: id })}
            className={`flex-1 py-1.5 text-xs ${right === id ? 'border-b-2 border-indigo-500 font-semibold' : 'text-neutral-500'}`}
          >
            {label}
          </button>
        ))}
        <button
          className="px-2 text-neutral-500"
          title="패널 닫기"
          onClick={() => set({ right: null })}
        >
          ✕
        </button>
      </div>
      <div className="min-h-0 flex-1">
        {/* AI 패널은 닫아도 대화가 유지되도록 숨기기만 한다 */}
        <div className={right === 'ai' ? 'h-full' : 'hidden'}>
          <AiPanel />
        </div>
        {right === 'crawl' && <CrawlPanel />}
        {right === 'notes' && <NotesPanel />}
        {right === 'downloads' && <DownloadsPanel />}
      </div>
    </aside>
  )
}
