import { useEffect, useState } from 'react'
import { invoke, safeInvoke, set, showToast, useApp } from '../stores/app'

const PAGE_FORMATS: [string, string][] = [
  ['md', 'Markdown (본문)'],
  ['merged', '전체 합본 1개 (.md)'],
  ['html', 'HTML 원본'],
  ['txt', '텍스트'],
  ['json', 'JSON (구조화)'],
  ['pdf', 'PDF (브라우저로 인쇄, 느림)']
]
const TYPE_LABEL: Record<string, string> = {
  pdf: 'PDF',
  hwp: '한글 HWP·HWPX',
  word: 'Word',
  excel: 'Excel·CSV',
  ppt: 'PowerPoint',
  text: 'TXT·MD',
  archive: '압축 파일',
  image: '이미지',
  media: '음성·영상',
  data: 'JSON·XML·EPUB'
}
const DOCS = ['pdf', 'hwp', 'word', 'excel', 'ppt']

interface Job {
  id: string
  state: string
  message: string
  start_url: string
  mode: string
  output_dir: string
  zip_path: string
  pages_done: number
  pages_queued: number
  files_found: number
  files_done: number
  bytes: number
  current: string
  errors: string[]
  elapsed: number
  pdf?: { done: number; total: number; running: boolean }
  files?: FileRow[]
}
interface FileRow {
  url: string
  ext: string
  category: string
  text: string
  status: string
}

const STATE: Record<string, string> = {
  queued: '대기',
  running: '진행 중',
  downloading: '다운로드 중',
  scanned: '스캔 완료 — 받을 파일을 고르세요',
  done: '완료',
  cancelled: '중지됨',
  error: '오류'
}

/** 웹 크롤러 · 일괄 다운로드 (CRW-01~12) */
export function CrawlPanel(): React.JSX.Element {
  const { tabs, activeId, crawlUrl } = useApp()
  const activeUrl = tabs.find((t) => t.id === activeId)?.url ?? ''
  const [url, setUrl] = useState('')
  const [scope, setScope] = useState('subpath')
  const [depth, setDepth] = useState(2)
  const [maxPages, setMaxPages] = useState(200)
  const [formats, setFormats] = useState<string[]>(['md', 'merged'])
  const [types, setTypes] = useState<string[]>(DOCS)
  const [custom, setCustom] = useState('')
  const [robots, setRobots] = useState(true)
  const [browserNet, setBrowserNet] = useState(true)
  const [zip, setZip] = useState(false)
  const [delay, setDelay] = useState(300)
  const [include, setInclude] = useState('')
  const [exclude, setExclude] = useState('')
  const [jobs, setJobs] = useState<Job[]>([])
  const [openJob, setOpenJob] = useState<Job | null>(null)
  const [picked, setPicked] = useState<Set<string>>(new Set())
  const [allTypes, setAllTypes] = useState<string[]>(Object.keys(TYPE_LABEL))

  const target = url || activeUrl

  useEffect(() => {
    void safeInvoke<Record<string, string[]>>('crawl:file-types').then(
      (t) => t && setAllTypes(Object.keys(t))
    )
  }, [])
  useEffect(() => {
    if (crawlUrl) {
      // 우클릭 "이 링크부터 크롤링"에서 온 주소 반영
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setUrl(crawlUrl)
      set({ crawlUrl: null })
    }
  }, [crawlUrl])

  // 진행 상황 1초마다 갱신
  useEffect(() => {
    const tick = (): void => {
      void invoke<Job[]>('crawl:jobs')
        .then(setJobs)
        .catch(() => {})
    }
    tick()
    const t = setInterval(tick, 1000)
    return () => clearInterval(t)
  }, [])

  const toggle = (list: string[], v: string, fn: (x: string[]) => void): void =>
    fn(list.includes(v) ? list.filter((x) => x !== v) : [...list, v])

  const start = async (over: Record<string, unknown> = {}): Promise<void> => {
    if (!/^https?:\/\//.test(target)) return showToast('http(s) 주소에서만 크롤링할 수 있습니다')
    const body = {
      start_url: target,
      scope,
      max_depth: depth,
      max_pages: maxPages,
      page_formats: formats,
      file_types: types,
      custom_exts: custom.split(/[,\s]+/).filter(Boolean),
      respect_robots: robots,
      engine: browserNet ? 'browser' : 'direct',
      make_zip: zip,
      delay_ms: delay,
      include,
      exclude,
      mode: 'run',
      ...over
    }
    const r = await safeInvoke<Job>('crawl:start', body)
    if (r) showToast(`🕸 작업 시작: ${r.output_dir}`)
  }

  const oneClick: [string, string, Record<string, unknown>][] = [
    [
      '📄',
      '이 페이지의 문서 전부 받기',
      { scope: 'page', max_depth: 0, page_formats: [], file_types: [...DOCS, 'text', 'archive'] }
    ],
    [
      '📚',
      '하위 페이지 전체 → Markdown + 합본',
      { scope: 'subpath', max_depth: 3, page_formats: ['md', 'merged'], file_types: [] }
    ],
    [
      '🗄',
      '하위 페이지 + 문서 전부 (ZIP)',
      {
        scope: 'subpath',
        max_depth: 3,
        page_formats: ['md', 'html', 'merged'],
        file_types: [...DOCS, 'text', 'archive'],
        make_zip: true
      }
    ],
    [
      '📑',
      '하위 페이지 → PDF',
      { scope: 'subpath', max_depth: 2, page_formats: ['pdf'], file_types: [] }
    ],
    [
      '🖼',
      '이 페이지의 이미지 전부',
      { scope: 'page', max_depth: 0, page_formats: [], file_types: ['image'] }
    ]
  ]

  const openFiles = async (job: Job): Promise<void> => {
    const s = await safeInvoke<Job>('crawl:status', job.id, true)
    if (!s) return
    setOpenJob(s)
    setPicked(new Set((s.files ?? []).filter((f) => f.status === 'found').map((f) => f.url)))
  }

  const box = 'rounded border border-neutral-300 px-1 py-0.5'

  return (
    <div className="h-full overflow-y-auto p-2 text-xs">
      <label className="block font-semibold">시작 주소</label>
      <input
        className={`${box} mb-2 w-full`}
        value={target}
        onChange={(e) => setUrl(e.target.value)}
      />

      <div className="mb-1 font-semibold">⚡ 한 번에 받기</div>
      <div className="mb-3 grid gap-1">
        {oneClick.map(([icon, label, over]) => (
          <button
            key={label}
            className="rounded border border-neutral-200 bg-white px-2 py-1.5 text-left hover:bg-indigo-50"
            onClick={() => void start(over)}
          >
            {icon} {label}
          </button>
        ))}
      </div>

      <details open className="mb-2 rounded border border-neutral-200 bg-white p-2">
        <summary className="cursor-pointer font-semibold">세부 설정</summary>
        <div className="mt-2 flex flex-wrap gap-2">
          {[
            ['page', '이 페이지만'],
            ['subpath', '하위 경로만'],
            ['domain', '사이트 전체']
          ].map(([v, l]) => (
            <label key={v}>
              <input type="radio" checked={scope === v} onChange={() => setScope(v)} /> {l}
            </label>
          ))}
        </div>
        <div className="mt-1 flex gap-3">
          <label>
            깊이{' '}
            <input
              type="number"
              min={0}
              max={10}
              className={`${box} w-12`}
              value={depth}
              onChange={(e) => setDepth(+e.target.value)}
            />
          </label>
          <label>
            최대 페이지{' '}
            <input
              type="number"
              min={1}
              className={`${box} w-16`}
              value={maxPages}
              onChange={(e) => setMaxPages(+e.target.value)}
            />
          </label>
        </div>

        <div className="mt-2 font-semibold">페이지 저장 형식</div>
        <div className="grid grid-cols-2">
          {PAGE_FORMATS.map(([v, l]) => (
            <label key={v}>
              <input
                type="checkbox"
                checked={formats.includes(v)}
                onChange={() => toggle(formats, v, setFormats)}
              />{' '}
              {l}
            </label>
          ))}
        </div>

        <div className="mt-2 font-semibold">
          받을 파일 종류{' '}
          <button
            className="font-normal text-indigo-600"
            onClick={() => setTypes(types.length ? [] : allTypes)}
          >
            ({types.length ? '모두 해제' : '모두 선택'})
          </button>
        </div>
        <div className="grid grid-cols-2">
          {allTypes.map((v) => (
            <label key={v}>
              <input
                type="checkbox"
                checked={types.includes(v)}
                onChange={() => toggle(types, v, setTypes)}
              />{' '}
              {TYPE_LABEL[v] ?? v}
            </label>
          ))}
        </div>
        <input
          className={`${box} mt-1 w-full`}
          placeholder="추가 확장자 (예: dwg, stp)"
          value={custom}
          onChange={(e) => setCustom(e.target.value)}
        />

        <div className="mt-2 font-semibold">고급</div>
        <label className="block">
          <input type="checkbox" checked={robots} onChange={(e) => setRobots(e.target.checked)} />{' '}
          robots.txt 규칙 따르기 (권장)
        </label>
        <label
          className="block"
          title="Chrome과 같은 네트워크·쿠키로 받습니다. 방화벽이 프로그램 요청을 막는 사이트도 받을 수 있습니다"
        >
          <input
            type="checkbox"
            checked={browserNet}
            onChange={(e) => setBrowserNet(e.target.checked)}
          />{' '}
          브라우저 네트워크로 받기 (차단 사이트 대응, 권장)
        </label>
        <label className="block">
          <input type="checkbox" checked={zip} onChange={(e) => setZip(e.target.checked)} /> 끝나면
          ZIP으로 묶기
        </label>
        <label className="block">
          요청 간격(ms){' '}
          <input
            type="number"
            min={0}
            className={`${box} w-16`}
            value={delay}
            onChange={(e) => setDelay(+e.target.value)}
          />
        </label>
        <input
          className={`${box} mt-1 w-full`}
          placeholder="이 글자(정규식)가 들어간 주소만 포함 (예: /board/)"
          value={include}
          onChange={(e) => setInclude(e.target.value)}
        />
        <input
          className={`${box} mt-1 w-full`}
          placeholder="이 글자(정규식)가 들어간 주소 제외 (예: logout|print)"
          value={exclude}
          onChange={(e) => setExclude(e.target.value)}
        />

        <div className="mt-2 flex gap-1">
          <button
            className="flex-1 rounded border border-indigo-600 px-2 py-1.5 text-indigo-700"
            onClick={() => void start({ mode: 'scan' })}
          >
            🔍 먼저 스캔 (목록 확인)
          </button>
          <button
            className="flex-1 rounded bg-indigo-600 px-2 py-1.5 text-white"
            onClick={() => void start()}
          >
            ⬇ 바로 받기
          </button>
        </div>
        <p className="mt-1 text-[11px] text-neutral-500">
          로그인한 사이트는 현재 워크스페이스의 로그인 상태로 받습니다. 저장 폴더는 ⚙ 설정 →
          크롤러에서 바꿀 수 있습니다. 저작권과 사이트 이용 약관을 지켜 주세요.
        </p>
      </details>

      <div className="mb-1 mt-3 font-semibold">작업 목록</div>
      {jobs.length === 0 && <p className="text-neutral-500">아직 작업이 없습니다.</p>}
      {jobs.map((j) => (
        <div key={j.id} className="mb-2 rounded border border-neutral-200 bg-white p-2">
          <div className="flex items-center gap-1">
            <b
              className={
                j.state === 'error' ? 'text-red-600' : j.state === 'done' ? 'text-green-700' : ''
              }
            >
              {STATE[j.state] ?? j.state}
            </b>
            <span className="ml-auto text-neutral-400">{j.elapsed}s</span>
          </div>
          <div className="truncate text-neutral-500" title={j.start_url}>
            {j.start_url}
          </div>
          <div>
            페이지 {j.pages_done}
            {j.pages_queued ? ` (+${j.pages_queued})` : ''} · 파일 {j.files_done}/{j.files_found} ·{' '}
            {(j.bytes / 1048576).toFixed(1)}MB
            {j.pdf && ` · PDF ${j.pdf.done}/${j.pdf.total}`}
          </div>
          {j.current && <div className="truncate text-neutral-400">↳ {j.current}</div>}
          {j.message && <div className="text-neutral-600">{j.message}</div>}
          {j.errors.length > 0 && (
            <details>
              <summary className="cursor-pointer text-amber-700">알림 {j.errors.length}건</summary>
              {j.errors.map((e, i) => (
                <div key={i} className="truncate" title={e}>
                  {e}
                </div>
              ))}
            </details>
          )}
          <div className="mt-1 flex flex-wrap gap-1">
            {['running', 'downloading'].includes(j.state) && (
              <button
                className="rounded border px-1.5"
                onClick={() => invoke('crawl:cancel', j.id)}
              >
                ⏹ 중지
              </button>
            )}
            {j.state === 'scanned' && (
              <button
                className="rounded bg-indigo-600 px-1.5 text-white"
                onClick={() => void openFiles(j)}
              >
                📋 파일 고르기
              </button>
            )}
            <button
              className="rounded border px-1.5"
              onClick={() => invoke('crawl:open', j.output_dir)}
            >
              📂 폴더 열기
            </button>
            {j.zip_path && (
              <button
                className="rounded border px-1.5"
                onClick={() => invoke('crawl:open', j.zip_path)}
              >
                🗜 ZIP
              </button>
            )}
          </div>
        </div>
      ))}

      {openJob && (
        <FilePicker
          job={openJob}
          picked={picked}
          setPicked={setPicked}
          onClose={() => setOpenJob(null)}
          onDownload={async () => {
            await safeInvoke('crawl:download', openJob.id, [...picked])
            setOpenJob(null)
          }}
        />
      )}
    </div>
  )
}

function FilePicker(p: {
  job: Job
  picked: Set<string>
  setPicked: (s: Set<string>) => void
  onClose: () => void
  onDownload: () => void
}): React.JSX.Element {
  const files = (p.job.files ?? []).filter((f) => f.status === 'found')
  const groups = [...new Set(files.map((f) => f.category))]
  const flip = (urls: string[], on: boolean): void => {
    const s = new Set(p.picked)
    urls.forEach((u) => (on ? s.add(u) : s.delete(u)))
    p.setPicked(s)
  }
  return (
    <div className="mt-2 rounded border-2 border-indigo-300 bg-white p-2">
      <div className="mb-1 flex items-center">
        <b>
          받을 파일 선택 ({p.picked.size}/{files.length})
        </b>
        <button className="ml-auto" onClick={p.onClose}>
          ✕
        </button>
      </div>
      <div className="max-h-80 overflow-y-auto">
        {groups.map((g) => {
          const list = files.filter((f) => f.category === g)
          const all = list.every((f) => p.picked.has(f.url))
          return (
            <div key={g} className="mb-1">
              <label className="font-semibold">
                <input
                  type="checkbox"
                  checked={all}
                  onChange={() =>
                    flip(
                      list.map((f) => f.url),
                      !all
                    )
                  }
                />{' '}
                {TYPE_LABEL[g] ?? g} ({list.length})
              </label>
              {list.map((f) => (
                <label key={f.url} className="block truncate pl-4" title={f.url}>
                  <input
                    type="checkbox"
                    checked={p.picked.has(f.url)}
                    onChange={() => flip([f.url], !p.picked.has(f.url))}
                  />{' '}
                  {f.text || decodeURIComponent(f.url.split('/').pop() ?? f.url)}
                </label>
              ))}
            </div>
          )
        })}
      </div>
      <button
        className="mt-1 w-full rounded bg-indigo-600 py-1 text-white disabled:opacity-40"
        disabled={!p.picked.size}
        onClick={p.onDownload}
      >
        ⬇ 선택한 {p.picked.size}개 받기
      </button>
    </div>
  )
}
