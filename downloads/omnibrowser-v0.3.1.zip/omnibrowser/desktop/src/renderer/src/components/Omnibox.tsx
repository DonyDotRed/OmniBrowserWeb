import { useEffect, useRef, useState } from 'react'
import { invoke, requestAi, set, useApp } from '../stores/app'

interface Suggestion {
  url: string
  title: string
}

/** 주소창: 입력하면 방문 기록에서 추천 (한국어 부분 검색, 3.9절) */
export function Omnibox(): React.JSX.Element {
  const { tabs, activeId, focusAddressTick, panel } = useApp()
  const active = tabs.find((t) => t.id === activeId)
  const [draft, setDraft] = useState<string | null>(null) // null = 현재 탭 주소 표시
  const [items, setItems] = useState<Suggestion[]>([])
  const [sel, setSel] = useState(0)
  const input = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (focusAddressTick) {
      input.current?.focus()
      input.current?.select()
    }
  }, [focusAddressTick])

  // 입력이 멈추고 0.15초 뒤 기록 검색
  useEffect(() => {
    const q = draft?.trim() ?? ''
    if (!q) return // 입력이 비면 목록 자체를 표시하지 않음 (open = false)
    const timer = setTimeout(() => {
      invoke<Suggestion[]>('history:search', q)
        .then((r) => setItems(r.slice(0, 8)))
        .catch(() => setItems([]))
    }, 150)
    return () => clearTimeout(timer)
  }, [draft])

  const open = draft !== null && draft.trim() !== ''
  useEffect(() => {
    if (open && panel === 'none') set({ panel: 'suggest' })
    if (!open && panel === 'suggest') set({ panel: 'none' })
  }, [open, panel])

  const go = (target: string): void => {
    if (!target.trim()) return
    if (/^[?？]\s*\S/.test(target.trim())) {
      // "?질문" → AI에게 질문 (현재 페이지 내용을 근거 자료로 함께 보냄)
      requestAi(
        null,
        active?.url.startsWith('http') ? 'page' : 'none',
        undefined,
        target.trim().slice(1).trim()
      )
      setDraft(null)
      input.current?.blur()
      return
    }
    if (activeId === null) void invoke('tabs:create', target)
    else void invoke('nav:go', activeId, target)
    setDraft(null)
    input.current?.blur()
  }

  const options = open ? [{ url: draft!, title: '' }, ...items] : []

  return (
    <div className="relative flex-1">
      <input
        ref={input}
        className="w-full rounded-full border border-neutral-300 bg-neutral-50 px-4 py-1.5 outline-none focus:border-indigo-400 focus:bg-white"
        placeholder="주소 입력 · 검색 · ?로 시작하면 AI 질문 (Ctrl+L)"
        value={draft ?? active?.url ?? ''}
        onFocus={(e) => e.target.select()}
        onChange={(e) => {
          setDraft(e.target.value)
          setSel(0)
        }}
        onBlur={() => setTimeout(() => setDraft(null), 150)} // 추천 항목 클릭이 먼저 처리되도록
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.nativeEvent.isComposing) go(options[sel]?.url ?? draft ?? '')
          else if (e.key === 'Escape') {
            setDraft(null)
            input.current?.blur()
          } else if (e.key === 'ArrowDown') {
            e.preventDefault()
            setSel((s) => Math.min(s + 1, options.length - 1))
          } else if (e.key === 'ArrowUp') {
            e.preventDefault()
            setSel((s) => Math.max(s - 1, 0))
          }
        }}
      />
      {open && (
        <SuggestPortal>
          {options.map((o, i) => (
            <button
              key={`${o.url}-${i}`}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => go(o.url)}
              className={`block w-full truncate px-4 py-2 text-left ${i === sel ? 'bg-indigo-50' : 'hover:bg-neutral-50'}`}
            >
              {i === 0 ? (
                <span>
                  {/^[?？]/.test(o.url)
                    ? '🤖 AI에게 질문 (페이지 내용 포함): ' + o.url.slice(1)
                    : `🔍 ${o.url}`}
                </span>
              ) : (
                <span>
                  🕘 {o.title || o.url} <span className="text-xs text-neutral-400">{o.url}</span>
                </span>
              )}
            </button>
          ))}
        </SuggestPortal>
      )}
    </div>
  )
}

/** 추천 목록은 콘텐츠 영역 위쪽에 그린다 (웹페이지는 그동안 숨겨짐) */
function SuggestPortal({ children }: { children: React.ReactNode }): React.JSX.Element {
  return (
    <div className="absolute left-0 right-0 top-full z-50 mt-1 overflow-hidden rounded-lg border border-neutral-200 bg-white shadow-lg">
      {children}
    </div>
  )
}
