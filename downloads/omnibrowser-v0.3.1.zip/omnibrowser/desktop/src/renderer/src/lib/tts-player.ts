/** Main이 보내 주는 문장별 오디오를 차례로 재생 (TTS-03 문장 단위 스트리밍) */
import { set } from '../stores/app'

interface Chunk {
  index: number
  total: number
  text: string
  mime: string
  base64: string
}

const audio = new Audio()
audio.preservesPitch = true // 빠르게 읽어도 목소리 톤 유지
let queue: { url: string; chunk: Chunk }[] = []
let playing = false
let current: Chunk | null = null
let rate = 1

function toBlobUrl(c: Chunk): string {
  const bytes = Uint8Array.from(atob(c.base64), (ch) => ch.charCodeAt(0))
  return URL.createObjectURL(new Blob([bytes], { type: c.mime }))
}

function playNext(): void {
  const item = queue.shift()
  if (!item) {
    playing = false // 다음 문장이 아직 합성 중 → 도착하면 이어서 재생
    return
  }
  playing = true
  current = item.chunk
  audio.src = item.url
  audio.playbackRate = rate
  void audio.play()
  set({
    tts: {
      active: true,
      index: item.chunk.index + 1,
      total: item.chunk.total,
      text: item.chunk.text
    }
  })
}

audio.addEventListener('ended', () => {
  URL.revokeObjectURL(audio.src)
  if (!queue.length && current && current.index + 1 >= current.total) return stop() // 마지막 문장 끝
  playNext()
})

function stop(): void {
  audio.pause()
  queue.forEach((q) => URL.revokeObjectURL(q.url))
  queue = []
  playing = false
  current = null
  set({ tts: { active: false, index: 0, total: 0, text: '' } })
}

export function setTtsRate(r: number): void {
  rate = r
  audio.playbackRate = r
}

export function getTtsRate(): number {
  return rate
}

export function initTtsPlayer(): () => void {
  const offs = [
    window.omni.on('tts:start', (p) => {
      stop()
      const r = Number((p as { rate?: number }).rate)
      if (r > 0) setTtsRate(r)
      set({
        tts: { active: true, index: 0, total: (p as { total: number }).total, text: '합성 중…' }
      })
    }),
    window.omni.on('tts:chunk', (p) => {
      const c = p as Chunk
      queue.push({ url: toBlobUrl(c), chunk: c })
      if (!playing) playNext()
    }),
    window.omni.on('tts:stop', () => stop())
  ]
  return () => offs.forEach((off) => off())
}
