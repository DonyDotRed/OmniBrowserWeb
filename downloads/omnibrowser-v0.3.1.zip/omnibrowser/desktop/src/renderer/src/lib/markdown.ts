/**
 * AI 답변(Markdown) → 안전한 HTML.
 * AI는 웹페이지 내용을 읽고 답하므로, 악성 페이지가 AI 답변에 HTML·스크립트를 끼워 넣을 수 있다.
 * → DOMPurify로 스크립트·이벤트 속성을 모두 제거한 뒤에만 화면에 넣는다.
 */
import DOMPurify from 'dompurify'
import { marked } from 'marked'

marked.setOptions({ gfm: true, breaks: true })

export function renderMarkdown(md: string): string {
  const html = marked.parse(md, { async: false }) as string
  return DOMPurify.sanitize(html, {
    FORBID_TAGS: ['style', 'form', 'input', 'iframe'],
    FORBID_ATTR: ['style']
  })
}
