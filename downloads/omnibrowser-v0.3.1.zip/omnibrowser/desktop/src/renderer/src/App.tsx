import { useEffect } from 'react'
import { BlockedBar } from './components/BlockedBar'
import { CommandPalette } from './components/CommandPalette'
import { ContentArea } from './components/ContentArea'
import { FindBar } from './components/FindBar'
import { ReaderView } from './components/ReaderView'
import { RightPanel } from './components/RightPanel'
import { SettingsPanel } from './components/SettingsPanel'
import { Sidebar } from './components/Sidebar'
import { StatusBar } from './components/StatusBar'
import { Toolbar } from './components/Toolbar'
import { initTtsPlayer } from './lib/tts-player'
import {
  invoke,
  loadBookmarks,
  loadWorkspaces,
  requestAi,
  set,
  showToast,
  useApp,
  type TabInfo
} from './stores/app'

type TabsPayload = { list: TabInfo[]; activeId: number | null; workspaceId: string }

export default function App(): React.JSX.Element {
  const panel = useApp((s) => s.panel)

  // Main 이벤트 구독 — UI는 상태를 직접 바꾸지 않고 Main의 결과를 반영만 한다 (7.2절)
  useEffect(() => {
    const on = window.omni.on
    const offs = [
      on('tabs:state', (p) => {
        const s = p as TabsPayload
        set({ tabs: s.list, activeId: s.activeId, workspaceId: s.workspaceId, mediaRate: null })
      }),
      on('core:status', (s) => {
        set({ coreStatus: s as string })
        if (s === 'ready') {
          void loadWorkspaces()
          void loadBookmarks()
        }
      }),
      on('media:state', (p) => set({ mediaRate: (p as { rate: number }).rate })),
      on('find:result', (p) => set({ findResult: p as { active: number; matches: number } })),
      on('bookmarks:changed', () => void loadBookmarks()),
      on('ui:toast', (m) => showToast(String(m))),
      on('ui:focus-address', () => set((s) => ({ focusAddressTick: s.focusAddressTick + 1 }))),
      on('ui:find-open', () => set({ findOpen: true })),
      on('ui:ws-index', (i) => {
        const w = useApp.getState().workspaces[Number(i)]
        if (w) void invoke('ws:switch', w.id)
      }),
      on('ui:panel', (p) => set({ right: p as 'ai' | 'crawl' | 'notes' | 'downloads' })),
      on('ui:palette', () => set({ panel: 'palette' })),
      on('ui:reader', () => set((s) => ({ panel: s.panel === 'reader' ? 'none' : 'reader' }))),
      on('ui:sidebar', (m) => set({ sidebar: m as 'history' })),
      on('ui:crawl-url', (u) => set({ right: 'crawl', crawlUrl: String(u) })),
      on('ui:blocked', (b) => set({ blocked: b as { url: string; mode: string; chrome: string } })),
      on('ui:ai-request', (p) => {
        const r = p as {
          preset: string | null
          source: 'selection' | 'page' | 'text'
          text?: string
        }
        requestAi(r.preset, r.source, r.text)
      }),
      // AI 응답 조각 → 해당 메시지에 이어 붙이기 (패널이 닫혀 있어도 계속 받음)
      on('ai:chunk', (p) => {
        const { jobId, text } = p as { jobId: string; text: string }
        set((s) => ({
          chat: s.chat.map((m) => (m.jobId === jobId ? { ...m, content: m.content + text } : m))
        }))
      }),
      on('ai:done', (p) => {
        const { jobId, error } = p as { jobId: string; error?: string }
        set((s) => ({
          chat: s.chat.map((m) => (m.jobId === jobId ? { ...m, streaming: false, error } : m))
        }))
      }),
      initTtsPlayer()
    ]
    // 이벤트는 UI가 뜨기 전에 이미 지나갔을 수 있으므로 현재 값을 한 번 당겨 온다
    void invoke<{ status: string }>('core:get-status').then((s) => {
      set({ coreStatus: s.status })
      if (s.status === 'ready') {
        void loadWorkspaces()
        void loadBookmarks()
      }
    })
    void invoke<TabsPayload>('tabs:list').then((s) =>
      set({ tabs: s.list, activeId: s.activeId, workspaceId: s.workspaceId })
    )
    return () => offs.forEach((off) => off())
  }, [])

  // 패널이 열려 있으면 웹페이지를 잠시 숨겨 패널이 보이게 함
  useEffect(() => {
    void invoke('tabs:set-covered', panel !== 'none')
  }, [panel])

  return (
    <div className="flex h-screen flex-col bg-neutral-50 text-sm text-neutral-900">
      <Toolbar />
      <BlockedBar />
      <FindBar />
      <div className="flex min-h-0 flex-1">
        <Sidebar />
        <ContentArea>
          {panel === 'settings' && <SettingsPanel />}
          {panel === 'reader' && <ReaderView />}
          {panel === 'palette' && <CommandPalette />}
        </ContentArea>
        <RightPanel />
      </div>
      <StatusBar />
    </div>
  )
}
