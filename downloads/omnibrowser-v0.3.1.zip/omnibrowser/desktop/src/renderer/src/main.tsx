import './assets/main.css'

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'

// 오버레이 뷰(#/overlay)는 Phase 3 명령 팔레트용 — 지금은 빈 투명 화면
const isOverlay = location.hash.startsWith('#/overlay')

createRoot(document.getElementById('root')!).render(
  <StrictMode>{isOverlay ? <div /> : <App />}</StrictMode>
)
