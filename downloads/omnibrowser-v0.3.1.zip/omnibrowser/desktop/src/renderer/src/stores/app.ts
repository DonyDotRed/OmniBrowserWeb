import { create } from 'zustand'

export interface TabInfo {
  id: number
  workspaceId: string
  url: string
  title: string
  favicon: string
  loading: boolean
  audible: boolean
  muted: boolean
  canGoBack: boolean
  canGoForward: boolean
  zoom: number
}
export interface Workspace {
  id: string
  name: string
  color: string
}
export interface Bookmark {
  id: string
  title: string
  url: string
}
export type Panel = 'none' | 'suggest' | 'settings' | 'palette' | 'reader'
export type RightPanel = null | 'ai' | 'crawl' | 'notes' | 'downloads'

export interface ChatMsg {
  role: 'user' | 'assistant'
  content: string
  label?: string // 화면 표시용 (예: "📝 요약 · 페이지 전체")
  jobId?: string
  streaming?: boolean
  error?: string
}

interface AppState {
  tabs: TabInfo[]
  activeId: number | null
  workspaceId: string
  workspaces: Workspace[]
  bookmarks: Bookmark[]
  coreStatus: string
  mediaRate: number | null
  toast: string | null
  panel: Panel
  sidebar: 'tabs' | 'bookmarks' | 'history'
  right: RightPanel
  chat: ChatMsg[]
  aiSource: { title: string; url: string; chars: number } | null
  aiRequest: {
    preset: string | null
    source: 'selection' | 'page' | 'text' | 'none'
    text?: string
    question?: string
    n: number // 같은 요청을 다시 보내도 반응하도록 증가하는 번호
  } | null
  crawlUrl: string | null
  blocked: { url: string; mode: string; chrome: string } | null // 차단 화면 감지 안내
  findOpen: boolean
  findResult: { active: number; matches: number } | null
  focusAddressTick: number // 값이 바뀌면 주소창에 포커스
  tts: { active: boolean; index: number; total: number; text: string }
}

export const useApp = create<AppState>(() => ({
  tabs: [],
  activeId: null,
  workspaceId: 'default',
  workspaces: [{ id: 'default', name: '개인용', color: '#4F46E5' }],
  bookmarks: [],
  coreStatus: 'starting',
  mediaRate: null,
  toast: null,
  panel: 'none',
  sidebar: 'tabs',
  findOpen: false,
  findResult: null,
  focusAddressTick: 0,
  tts: { active: false, index: 0, total: 0, text: '' },
  right: null,
  chat: [],
  aiSource: null,
  aiRequest: null,
  crawlUrl: null,
  blocked: null
}))

export const set = useApp.setState
export const invoke = window.omni.invoke

let toastTimer: ReturnType<typeof setTimeout> | undefined
export function showToast(message: string): void {
  set({ toast: message })
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => set({ toast: null }), 5000)
}

export async function loadWorkspaces(): Promise<void> {
  try {
    set({ workspaces: await invoke<Workspace[]>('ws:list') })
  } catch {
    // Core 준비 전: 기본 워크스페이스만 표시
  }
}

export async function loadBookmarks(): Promise<void> {
  try {
    set({ bookmarks: await invoke<Bookmark[]>('bookmarks:list') })
  } catch {
    // Core 준비 전
  }
}

/** 오류가 나도 앱이 멈추지 않게: 실패 메시지는 상태바 알림으로 */
export async function safeInvoke<T>(
  channel: Parameters<typeof invoke>[0],
  ...args: unknown[]
): Promise<T | null> {
  try {
    return await invoke<T>(channel, ...args)
  } catch (e) {
    showToast(
      String((e as Error).message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')
    )
    return null
  }
}

let reqSeq = 0
/** AI 패널을 열고 작업 요청 (우클릭 메뉴·주소창 ?·리더 모드 등에서 사용) */
export function requestAi(
  preset: string | null,
  source: 'selection' | 'page' | 'text' | 'none',
  text?: string,
  question?: string
): void {
  set({ right: 'ai', aiRequest: { preset, source, text, question, n: ++reqSeq } })
}
