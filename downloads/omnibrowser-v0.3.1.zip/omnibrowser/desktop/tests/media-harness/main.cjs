/* eslint-disable */ // 테스트 도구(일반 JS)라 TS용 검사 규칙에서 제외
/**
 * 탭 preload(out/preload/tab.js) 자동 테스트 — 실제 Electron에서 실행.
 * 실행: cd desktop → uv run npm run test:media   (결과: ✅/❌ 목록, 실패 시 종료 코드 1)
 */
const { app, BrowserWindow, WebContentsView, ipcMain } = require('electron')
const path = require('path')

const SITE_RATE = 1.75 // Main이 "이 사이트에서 기억한 배속"으로 돌려줄 값
let failed = 0
const check = (name, actual, expected) => {
  const ok = Math.abs(actual - expected) < 0.001
  if (!ok) failed++
  console.log(`${ok ? '✅' : '❌'} ${name}: ${actual} (기대값 ${expected})`)
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

app.whenReady().then(async () => {
  const win = new BrowserWindow({ width: 800, height: 600 })
  const view = new WebContentsView({
    webPreferences: {
      preload: path.join(__dirname, '../../out/preload/tab.js'),
      sandbox: true,
      contextIsolation: true,
      nodeIntegrationInSubFrames: true
    }
  })
  win.contentView.addChildView(view)
  view.setBounds({ x: 0, y: 0, width: 800, height: 600 })
  const wc = view.webContents

  // 실제 Main(index.ts)과 같은 중계 규칙
  const toFrames = (ch, ...a) => wc.mainFrame.framesInSubtree.forEach((f) => f.send(ch, ...a))
  ipcMain.on('media:key', (_e, k) => toFrames('media:key', k))
  ipcMain.on('media:state', () => {})
  ipcMain.handle('media:get-site-rate', () => SITE_RATE)
  ipcMain.handle('media:get-favorite-rate', () => 1.5)

  await wc.loadFile(path.join(__dirname, 'page.html'))
  const top = wc.mainFrame
  const rate = async () =>
    Number(await top.frames[0].executeJavaScript('document.getElementById("a").playbackRate'))
  const key = async (code, shift = false) => {
    await top.executeJavaScript(
      `window.dispatchEvent(new KeyboardEvent('keydown', { code: '${code}', shiftKey: ${shift} }))`
    )
    await sleep(200)
  }

  await sleep(1500)
  check('첫 재생 시 사이트 기억 배속 적용', await rate(), SITE_RATE)
  await key('KeyD')
  check('D: +0.1 (바깥 프레임에서 누르고 iframe 영상에 적용)', await rate(), 1.85)
  await key('KeyD', true)
  check('Shift+D: +0.5', await rate(), 2.35)
  await key('KeyR')
  check('R: 1.0x로', await rate(), 1)
  await key('KeyR')
  check('R 한 번 더: 직전 배속 복귀', await rate(), 2.35)
  await top.frames[0].executeJavaScript('document.getElementById("a").playbackRate = 1')
  await sleep(200)
  check('사이트가 1.0으로 되돌려도 재적용', await rate(), 2.35)
  await top.executeJavaScript("document.body.appendChild(document.createElement('input')).focus()")
  await key('KeyD')
  check('입력창에 포커스가 있으면 무시', await rate(), 2.35)
  await top.executeJavaScript('document.activeElement.blur()')
  for (let i = 0; i < 100; i++) await key('KeyD', true)
  check('최대 10x 제한', await rate(), 10)
  toFrames('media:set-rate', 0.01)
  await sleep(200)
  check('최소 0.1x 제한 (상태바 지정 경로)', await rate(), 0.1)

  console.log(failed ? `\n❌ ${failed}개 실패` : '\n✅ 모두 통과')
  app.exit(failed ? 1 : 0)
})
