#!/usr/bin/env bash
# setup.sh
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v uv >/dev/null 2>&1; then
  curl -LsSf https://astral.sh/uv/install.sh | sh
  export PATH="$HOME/.local/bin:$PATH"
fi
uv sync --extra tts-local --extra ai
[ -f .env ] || cp .env.example .env
uv run poe setup-ui
uv run poe doctor
echo "설치 완료! ./run.sh 로 실행하세요."
