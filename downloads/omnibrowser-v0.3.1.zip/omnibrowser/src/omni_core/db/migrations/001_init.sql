-- 공통: id TEXT(UUID), updated_at INTEGER(ms), deleted INTEGER(0/1)

CREATE TABLE workspaces (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  color       TEXT NOT NULL DEFAULT '#4F46E5',
  icon        TEXT,
  template    TEXT NOT NULL DEFAULT 'personal',   -- work | study | personal | ephemeral
  partition   TEXT NOT NULL UNIQUE,               -- 예: persist:ws-<id>
  sort_order  INTEGER NOT NULL DEFAULT 0,
  updated_at  INTEGER NOT NULL,
  deleted     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE history (
  id           TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  url          TEXT NOT NULL,
  title        TEXT NOT NULL DEFAULT '',
  visit_count  INTEGER NOT NULL DEFAULT 1,
  last_visit   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  deleted      INTEGER NOT NULL DEFAULT 0,
  UNIQUE (workspace_id, url)
);
CREATE INDEX idx_history_recent ON history(workspace_id, last_visit DESC);

-- 한국어 부분 검색을 위해 trigram 토크나이저 사용 ('방사선' 검색 시 '방사선방호'도 찾음)
-- 주의: trigram은 3글자 이상 검색어에만 동작 → 1~2글자는 LIKE 검색으로 대체
CREATE VIRTUAL TABLE history_fts USING fts5(
  title, url, content='history', content_rowid='rowid', tokenize='trigram'
);
CREATE TRIGGER history_ai AFTER INSERT ON history BEGIN
  INSERT INTO history_fts(rowid, title, url) VALUES (new.rowid, new.title, new.url);
END;
CREATE TRIGGER history_ad AFTER DELETE ON history BEGIN
  INSERT INTO history_fts(history_fts, rowid, title, url) VALUES ('delete', old.rowid, old.title, old.url);
END;
CREATE TRIGGER history_au AFTER UPDATE ON history BEGIN
  INSERT INTO history_fts(history_fts, rowid, title, url) VALUES ('delete', old.rowid, old.title, old.url);
  INSERT INTO history_fts(rowid, title, url) VALUES (new.rowid, new.title, new.url);
END;

CREATE TABLE bookmarks (
  id         TEXT PRIMARY KEY,
  parent_id  TEXT REFERENCES bookmarks(id),
  kind       TEXT NOT NULL CHECK (kind IN ('folder', 'link')),
  title      TEXT NOT NULL,
  url        TEXT,
  position   REAL NOT NULL DEFAULT 0,      -- 실수형: 두 항목 사이에 끼워 넣기 쉬움
  updated_at INTEGER NOT NULL,
  deleted    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE settings (
  key        TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE site_settings (
  origin       TEXT NOT NULL,              -- 예: https://www.youtube.com
  workspace_id TEXT,                       -- NULL = 모든 워크스페이스 공통
  key          TEXT NOT NULL,              -- 예: media.rate, zoom, autoplay, gesture.enabled
  value_json   TEXT NOT NULL,
  updated_at   INTEGER NOT NULL,
  deleted      INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (origin, workspace_id, key)
);

CREATE TABLE media_positions (
  url_hash     TEXT PRIMARY KEY,           -- SHA-256(정규화 URL)
  url          TEXT NOT NULL,
  title        TEXT,
  position_sec REAL NOT NULL,
  duration_sec REAL,
  rate         REAL NOT NULL DEFAULT 1.0,
  completed    INTEGER NOT NULL DEFAULT 0,
  updated_at   INTEGER NOT NULL,
  deleted      INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE notes (
  id           TEXT PRIMARY KEY,
  kind         TEXT NOT NULL CHECK (kind IN ('note', 'highlight', 'timestamp')),
  url          TEXT NOT NULL,
  media_time   REAL,                       -- 타임스탬프 메모일 때 재생 시점(초)
  selector     TEXT,                       -- 하이라이트 위치 정보(JSON)
  quote        TEXT,                       -- 선택한 원문
  body         TEXT NOT NULL DEFAULT '',
  image_path   TEXT,                       -- 캡처 이미지(로컬 경로)
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  deleted      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_notes_url ON notes(url);

CREATE TABLE reading_list (
  id         TEXT PRIMARY KEY,
  url        TEXT NOT NULL UNIQUE,
  title      TEXT,
  excerpt    TEXT,
  is_read    INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  deleted    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE session_snapshots (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER NOT NULL,
  reason     TEXT NOT NULL,                -- auto | quit | manual
  payload    TEXT NOT NULL                 -- 창·탭·분할 레이아웃 JSON
);

CREATE TABLE downloads (
  id         TEXT PRIMARY KEY,
  url        TEXT NOT NULL,
  file_path  TEXT,
  state      TEXT NOT NULL,                -- progressing | completed | cancelled | interrupted
  bytes      INTEGER,
  created_at INTEGER NOT NULL
);

CREATE TABLE tts_cache (
  cache_key    TEXT PRIMARY KEY,           -- SHA-256(엔진|음성|언어|문장)
  provider     TEXT NOT NULL,
  file_path    TEXT NOT NULL,
  chars        INTEGER NOT NULL,
  bytes        INTEGER NOT NULL,
  created_at   INTEGER NOT NULL,
  last_used_at INTEGER NOT NULL
);

CREATE TABLE api_usage (
  id         TEXT PRIMARY KEY,
  provider   TEXT NOT NULL,                -- openai | anthropic | elevenlabs | ...
  kind       TEXT NOT NULL,                -- tts | ai | ocr
  units      INTEGER NOT NULL,             -- 글자 수 또는 토큰 수
  est_cost   REAL,                         -- 사용자 입력 단가 기준 추정치
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  deleted    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE sync_state (
  entity      TEXT PRIMARY KEY,
  last_pulled INTEGER NOT NULL DEFAULT 0,
  last_pushed INTEGER NOT NULL DEFAULT 0
);

-- 기본 워크스페이스 (history 등의 외래키가 참조)
INSERT INTO workspaces (id, name, template, partition, updated_at)
VALUES ('default', '개인용', 'personal', 'persist:ws-default', 0);
