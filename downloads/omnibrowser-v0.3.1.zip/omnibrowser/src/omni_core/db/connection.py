"""모든 DB 접근은 connect()를 통과한다 → 나중에 SQLCipher로 바꿀 때 여기만 수정."""
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from importlib import resources
from pathlib import Path

_db_path: Path | None = None


def init_db(path: Path) -> None:
    global _db_path
    _db_path = path
    with connect() as con:
        con.execute("PRAGMA journal_mode=WAL")            # 읽기·쓰기 동시성 향상
        current = con.execute("PRAGMA user_version").fetchone()[0]
        files = sorted(
            (f for f in resources.files("omni_core.db.migrations").iterdir()
             if f.name.endswith(".sql")),
            key=lambda f: f.name,
        )
        for f in files:                                    # 001_init.sql, 002_xxx.sql ...
            version = int(f.name.split("_", 1)[0])
            if version > current:
                con.executescript(f.read_text(encoding="utf-8"))
                con.execute(f"PRAGMA user_version = {version}")


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    if _db_path is None:
        raise RuntimeError("init_db()가 먼저 호출되어야 합니다")
    con = sqlite3.connect(_db_path, timeout=10)
    con.row_factory = sqlite3.Row                         # row["컬럼명"]으로 접근
    con.execute("PRAGMA foreign_keys = ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
