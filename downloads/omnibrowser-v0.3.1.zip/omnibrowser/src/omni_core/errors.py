from fastapi import Request
from fastapi.responses import JSONResponse


class OmniError(Exception):
    def __init__(self, code: str, message: str, hint: str = "", status: int = 400):
        super().__init__(message)
        self.code, self.message, self.hint, self.status = code, message, hint, status


async def omni_error_handler(_: Request, e: OmniError) -> JSONResponse:
    return JSONResponse(
        status_code=e.status,
        content={"error": {"code": e.code, "message": e.message, "hint": e.hint}},
    )
