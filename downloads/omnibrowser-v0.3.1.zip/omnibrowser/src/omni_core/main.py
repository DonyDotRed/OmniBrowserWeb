from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from fastapi.middleware.trustedhost import TrustedHostMiddleware

from . import __version__
from .config import get_settings
from .db.connection import init_db
from .errors import OmniError, omni_error_handler
from .routers import (
    ai,
    bookmarks,
    crawl,
    health,
    history,
    notes,
    secrets,
    sessions,
    settings,
    site_settings,
    tts,
    workspaces,
)
from .security import require_token
from .watchdog import start_watchdog


def create_app() -> FastAPI:
    s = get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        init_db(s.db_path)
        if s.watchdog:
            start_watchdog(timeout_sec=30)
        yield

    app = FastAPI(
        title="OmniBrowser Core", version=__version__, lifespan=lifespan,
        docs_url="/docs" if s.dev_mode else None, redoc_url=None,
        openapi_url="/openapi.json" if s.dev_mode else None,
    )
    # Host 헤더 검사: DNS 리바인딩 공격 방지 (포트 번호는 자동으로 무시됨)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost"])
    app.add_exception_handler(OmniError, omni_error_handler)

    app.include_router(health.router)                      # /health 는 인증 없음
    guarded = [Depends(require_token)]
    for prefix, module in [
        ("/history", history),
        ("/tts", tts),
        ("/settings", settings),
        ("/site-settings", site_settings),
        ("/bookmarks", bookmarks),
        ("/sessions", sessions),
        ("/workspaces", workspaces),
        ("/secrets", secrets),
        ("/ai", ai),
        ("/crawl", crawl),
        ("/notes", notes),
    ]:
        app.include_router(module.router, prefix=prefix, dependencies=guarded)
    return app
