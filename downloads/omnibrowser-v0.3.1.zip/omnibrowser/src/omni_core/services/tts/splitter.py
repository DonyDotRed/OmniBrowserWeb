"""긴 글 → 문장 목록. 문장 단위로 합성·재생해야 첫 소리가 빨리 나온다 (TTS-03)."""
import re

# 문장 끝: . ! ? … 。 뒤에 공백/줄바꿈, 또는 빈 줄
_END = re.compile(r"(?<=[.!?…。])[\"'”’)\]]*\s+|\n\s*\n")
MAX_LEN = 300  # 한 번에 합성할 최대 글자 수


def split_sentences(text: str, max_len: int = MAX_LEN) -> list[str]:
    text = re.sub(r"[ \t]+", " ", text.replace("\r", "")).strip()
    out: list[str] = []
    for part in _END.split(text):
        part = " ".join(part.split())  # 문장 안의 줄바꿈 정리
        while len(part) > max_len:  # 너무 긴 문장은 쉼표·공백 근처에서 자름
            i = max(part.rfind(",", 0, max_len), part.rfind(" ", 0, max_len))
            cut = i + 1 if i > max_len // 2 else max_len  # 적당한 끊을 곳이 없으면 글자 수로
            out.append(part[:cut].strip())
            part = part[cut:].strip()
        if part:
            out.append(part)
    return out
