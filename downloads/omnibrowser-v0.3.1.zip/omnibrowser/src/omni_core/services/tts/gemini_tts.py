"""Google Gemini TTS (클라우드): generateContent에 음성 출력(AUDIO)을 요청한다.
응답은 base64로 인코딩된 16비트 PCM(보통 24kHz, 모노) → WAV 헤더를 붙여 저장."""
import base64
import re
import wave
from pathlib import Path

import httpx

from ...errors import OmniError
from ...prefs import get_setting
from ...secrets_store import get_secret

VOICES = [
    "Kore", "Puck", "Charon", "Fenrir", "Leda", "Orus", "Aoede", "Zephyr", "Callirrhoe", "Autonoe",
    "Enceladus", "Iapetus", "Umbriel", "Algieba", "Despina", "Erinome", "Algenib", "Rasalgethi",
    "Laomedeia", "Achernar", "Alnilam", "Schedar", "Gacrux", "Pulcherrima", "Achird",
    "Zubenelgenubi", "Vindemiatrix", "Sadachbia", "Sadaltager", "Sulafat",
]


class GeminiTTS:
    name, media_type, ext = "gemini", "audio/wav", "wav"

    def tag(self) -> str:
        return f"{get_setting('tts.gemini.model')}|{get_setting('tts.gemini.style')}"

    async def synthesize(self, text: str, voice: str, lang: str, out: Path) -> None:
        key = get_secret("gemini")
        if not key:
            raise OmniError("GEMINI_KEY_MISSING", "Gemini API 키가 등록되지 않았습니다.",
                            "설정 → AI에서 Gemini 키를 등록하세요 (AI와 TTS가 같은 키 사용).")
        model = get_setting("tts.gemini.model") or "gemini-3.1-flash-tts-preview"
        style = (get_setting("tts.gemini.style") or "").strip()
        prompt = f"{style}\n\n{text}" if style else text  # 스타일 지시 + 읽을 문장
        body = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice or "Kore"}}},
            },
        }
        async with httpx.AsyncClient(timeout=httpx.Timeout(90, connect=15)) as client:
            r = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                headers={"x-goog-api-key": key}, json=body,
            )
        if r.status_code != 200:
            hint = "모델 이름을 확인하세요 (설정 → 읽어주기 → 🔄 최신 목록)" if r.status_code == 404 else "API 키·사용 한도를 확인하세요."
            raise OmniError("GEMINI_TTS_FAILED", f"Gemini TTS 오류 ({r.status_code}): {r.text[:160]}", hint, 502)
        try:
            part = r.json()["candidates"][0]["content"]["parts"][0]["inlineData"]
        except (KeyError, IndexError) as e:
            raise OmniError("GEMINI_TTS_FAILED", "Gemini가 음성을 돌려주지 않았습니다.", "문장을 바꾸거나 다시 시도하세요.", 502) from e
        pcm = base64.b64decode(part["data"])
        m = re.search(r"rate=(\d+)", part.get("mimeType", ""))
        write_wav(out, pcm, int(m.group(1)) if m else 24000)


def write_wav(path: Path, pcm: bytes, rate: int, channels: int = 1, width: int = 2) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(width)
        w.setframerate(rate)
        w.writeframes(pcm)
