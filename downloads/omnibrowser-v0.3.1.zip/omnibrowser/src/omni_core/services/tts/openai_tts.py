from pathlib import Path

import httpx

from ...config import get_settings
from ...errors import OmniError
from ...prefs import get_setting
from ...secrets_store import get_secret

VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse", "marin", "cedar"]


class OpenAITTS:
    name, media_type, ext = "openai", "audio/mpeg", "mp3"

    def tag(self) -> str:
        return str(get_setting("tts.openai.model") or "")

    async def synthesize(self, text: str, voice: str, lang: str, out: Path) -> None:
        key = get_secret("openai")
        if not key:
            raise OmniError("OPENAI_KEY_MISSING", "OpenAI API 키가 등록되지 않았습니다.",
                            "설정 → TTS → API 키에서 등록하세요.")
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                "https://api.openai.com/v1/audio/speech",
                headers={"Authorization": f"Bearer {key}"},
                json={"model": get_setting("tts.openai.model") or get_settings().openai_tts_model, "voice": voice or "alloy",
                      "input": text, "response_format": "mp3"},
            )
        if r.status_code != 200:
            raise OmniError("OPENAI_TTS_FAILED", f"OpenAI TTS 오류 ({r.status_code})",
                            "API 키·잔액·모델명을 확인하세요.", status=502)
        out.write_bytes(r.content)
