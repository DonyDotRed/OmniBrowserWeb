"""Supertonic 3: ONNX 기반 온디바이스(로컬·무료·오프라인) TTS.

모델 폴더는 설정(tts.local.model_dir)으로 바꿀 수 있다 → D 드라이브 등 다른 폴더나
다른 PC에서 복사해 온 모델을 그대로 사용. 비워 두면 기본 위치(사용자 폴더/.cache/supertonic3).
"""
import shutil
import threading
from pathlib import Path

from starlette.concurrency import run_in_threadpool

from ...config import get_settings
from ...errors import OmniError
from ...prefs import get_setting

DEFAULT_VOICES = [f"{g}{i}" for g in "MF" for i in range(1, 6)]
JOB: dict = {"state": "idle", "message": "", "target": ""}  # 다운로드·복사 진행 상태


def _not_installed() -> OmniError:
    return OmniError(
        "TTS_ENGINE_NOT_INSTALLED", "로컬 TTS(Supertonic)가 설치되지 않았습니다.",
        "setup.bat을 다시 실행하거나 'uv sync --extra tts-local' 후 앱을 재시작하세요.", 503,
    )


def normalize_dir(path: str) -> Path | None:
    """사용자가 onnx 하위 폴더를 골라도 모델 루트 폴더로 맞춘다"""
    if not path:
        return None
    p = Path(path).expanduser()
    if p.name.lower() == "onnx" and (p / "tts.json").exists():
        p = p.parent
    return p


def shared_dir(model: str) -> Path:
    """Supertonic 패키지의 공용 기본 위치 (사용자 폴더/.cache/supertonic3).
    같은 PC의 다른 Supertonic 앱도 이 폴더를 쓰므로 OmniBrowser는 여기에 쓰지 않는다."""
    try:
        from supertonic.config import get_model_cache_dir
    except ImportError as e:
        raise _not_installed() from e
    return get_model_cache_dir(model)


def default_dir(model: str) -> Path:
    """OmniBrowser 전용 기본 모델 폴더 (%APPDATA%/OmniBrowser/core/models/<모델>).
    v0.3까지는 공용 폴더를 함께 써서, 다른 Supertonic 앱과 동시에 실행하면 모델 다운로드 임시 폴더
    (.supertonic3.tmp)와 '기존 폴더 삭제 후 교체' 단계가 충돌해 한쪽이 기동 중 종료될 수 있었다."""
    return get_settings().data_dir / "models" / model


def _lock(d: Path):
    """여러 프로세스(다른 OmniBrowser 실행 등)가 같은 폴더를 동시에 받거나 복사하지 않도록 파일 잠금"""
    from filelock import FileLock

    d.parent.mkdir(parents=True, exist_ok=True)
    return FileLock(str(d.parent / f".{d.name}.lock"), timeout=600)


def ensure_model(model: str, d: Path, auto_download: bool) -> str:
    """모델 준비: 이미 있으면 그대로 → 공용 폴더에 완성된 모델이 있으면 복사(인터넷 불필요) → 다운로드.
    돌려주는 값: 어떻게 준비했는지 (로그·화면 안내용)"""
    from supertonic.loader import download_model, has_all_onnx_modules

    if d.exists() and has_all_onnx_modules(d):
        return "ready"
    with _lock(d):
        if d.exists() and has_all_onnx_modules(d):  # 잠금을 기다리는 동안 다른 쪽이 준비함
            return "ready"
        src = shared_dir(model)
        if src.exists() and has_all_onnx_modules(src) and src.resolve() != d.resolve():
            tmp = d.parent / f".{d.name}.copying"
            shutil.rmtree(tmp, ignore_errors=True)
            shutil.copytree(src, tmp)  # 공용 폴더는 읽기만 함
            shutil.rmtree(d, ignore_errors=True)
            tmp.rename(d)
            return "copied"
        if not auto_download:
            return "missing"
        download_model(d, model)  # 임시 폴더도 OmniBrowser 전용 위치(.<모델>.tmp)에 만들어짐
        return "downloaded"


def resolve(model: str | None = None, model_dir: str | None = None) -> tuple[str, Path]:
    model = model or get_setting("tts.local.model") or "supertonic-3"
    d = normalize_dir(model_dir if model_dir is not None else (get_setting("tts.local.model_dir") or ""))
    return model, d or default_dir(model)


def status(model: str | None = None, model_dir: str | None = None) -> dict:
    try:
        from supertonic.config import AVAILABLE_MODELS
        from supertonic.loader import has_all_onnx_modules
    except ImportError:
        return {"engine_installed": False, "job": JOB}
    model, d = resolve(model, model_dir)
    installed = d.exists() and has_all_onnx_modules(d)
    voices: list[str] = []
    if installed:
        vs = d / "voice_styles"
        voices = sorted(f.stem for f in vs.glob("*.json")) if vs.exists() else []
    size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) if installed else 0
    return {
        "engine_installed": True,
        "model": model,
        "models": list(AVAILABLE_MODELS),
        "dir": str(d),
        "default_dir": str(default_dir(model)),
        "shared_dir": str(shared_dir(model)),  # 다른 Supertonic 앱과 공용 (OmniBrowser는 읽기·복사만)
        "shared_installed": shared_dir(model).exists() and has_all_onnx_modules(shared_dir(model)),
        "custom": bool(get_setting("tts.local.model_dir")),
        "installed": installed,
        "voices": voices or DEFAULT_VOICES,
        "size_mb": round(size / 1_048_576, 1),
        "job": JOB,
    }


def _bg(target: str, fn, *args) -> None:
    if JOB["state"] == "running":
        raise OmniError("TTS_JOB_BUSY", "이미 모델 다운로드·복사가 진행 중입니다.")
    JOB.update(state="running", message="진행 중…", target=target)

    def run() -> None:
        try:
            fn(*args)
            JOB.update(state="done", message="완료")
        except Exception as e:  # 네트워크 차단, 권한 없음 등
            JOB.update(state="error", message=f"{type(e).__name__}: {str(e).splitlines()[0][:200]}")

    threading.Thread(target=run, daemon=True).start()


def start_download(model: str | None, model_dir: str | None) -> None:
    """지정 폴더로 모델 내려받기 (Hugging Face)"""
    try:
        import supertonic  # noqa: F401
    except ImportError as e:
        raise _not_installed() from e
    model, d = resolve(model, model_dir)
    _bg(str(d), ensure_model, model, d, True)  # 공용 폴더에 있으면 복사, 없으면 다운로드


def start_copy(dst: str) -> None:
    """현재 모델 폴더를 새 폴더로 복사 (복사가 끝나면 UI가 새 폴더를 설정으로 저장)"""
    model, src = resolve()
    target = normalize_dir(dst)
    if not target:
        raise OmniError("TTS_BAD_DIR", "복사할 폴더를 고르세요.")
    if not src.exists():
        raise OmniError("TTS_MODEL_MISSING", "복사할 모델이 아직 없습니다.", "먼저 모델을 내려받으세요.")
    if target.resolve() == src.resolve():
        raise OmniError("TTS_BAD_DIR", "같은 폴더입니다.")
    _bg(str(target), shutil.copytree, src, target, dirs_exist_ok=True)


class SupertonicTTS:
    name, media_type, ext = "supertonic", "audio/wav", "wav"

    def __init__(self) -> None:
        self._engine = None  # 첫 요청 때 로드 (앱 시작을 느리게 하지 않음)
        self._loaded_key: tuple[str, str] | None = None
        self._lock = threading.Lock()

    def tag(self) -> str:
        model, d = resolve()
        return f"{model}|{d}"

    def reset(self) -> None:
        with self._lock:
            self._engine, self._loaded_key = None, None

    def _load(self):
        model, d = resolve()
        key = (model, str(d))
        with self._lock:
            if self._engine is not None and self._loaded_key == key:
                return self._engine
            try:
                from supertonic import TTS
            except ImportError as e:
                raise _not_installed() from e
            try:
                how = ensure_model(model, d, bool(get_setting("tts.local.auto_download", True)))
                if how == "missing":
                    raise FileNotFoundError("모델 파일 없음 (자동 받기 꺼짐)")
                self._engine = TTS(model=model, model_dir=d, auto_download=False)
                self._loaded_key = key
            except Exception as e:  # 네트워크 차단, 모델 없음 등
                raise OmniError(
                    "TTS_MODEL_UNAVAILABLE",
                    f"Supertonic 모델을 불러오지 못했습니다 ({str(e).splitlines()[0][:120]})",
                    f"모델 폴더: {d} — 설정 → 읽어주기에서 폴더를 확인하거나 '이 폴더로 모델 받기'를 누르세요.", 503,
                ) from e
            return self._engine

    def _run(self, text: str, voice: str, lang: str, out: Path) -> None:
        tts = self._load()
        names = getattr(tts, "voice_style_names", []) or DEFAULT_VOICES
        style = tts.get_voice_style(voice_name=voice if voice in names else names[0])
        wav, _duration = tts.synthesize(text, voice_style=style, lang=lang)
        tts.save_audio(wav, str(out))

    async def synthesize(self, text: str, voice: str, lang: str, out: Path) -> None:
        # CPU를 많이 쓰는 작업은 별도 스레드에서 → 서버가 다른 요청을 계속 처리
        await run_in_threadpool(self._run, text, voice, lang, out)
