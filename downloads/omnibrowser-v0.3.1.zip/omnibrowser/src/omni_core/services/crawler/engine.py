"""웹 크롤러 · 일괄 다운로더 (CRW-01~12)

- 시작 주소에서 링크를 따라가며(너비 우선) 페이지를 모으고, 선택한 종류의 파일(PDF·HWP·DOCX·XLSX…)을 찾는다.
- 모드: scan(목록만 만들기) → 사용자가 고른 파일만 download, 또는 한 번에 run(찾으면서 바로 저장).
- 페이지 저장 형식: html(원본), md(본문 Markdown), txt(본문 텍스트), json(구조화), merged(전체 합본 .md)
- 예절: robots.txt 준수(기본), 요청 간 지연, 동시 요청 수 제한, 페이지·용량 상한.
"""
import asyncio
import csv
import hashlib
import json
import re
import time
import urllib.robotparser
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import unquote, urldefrag, urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

FILE_TYPES: dict[str, list[str]] = {
    "pdf": ["pdf"],
    "hwp": ["hwp", "hwpx"],
    "word": ["doc", "docx", "odt", "rtf"],
    "excel": ["xls", "xlsx", "csv", "ods"],
    "ppt": ["ppt", "pptx", "odp"],
    "text": ["txt", "md"],
    "archive": ["zip", "7z", "rar", "tar", "gz", "tgz"],
    "image": ["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp"],
    "media": ["mp3", "mp4", "wav", "m4a", "webm", "mov", "avi"],
    "data": ["json", "xml", "epub"],
}
PAGE_FORMATS = {"html", "md", "txt", "json", "merged"}
HTML_TYPES = ("text/html", "application/xhtml+xml")
WIN_RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


@dataclass
class CrawlOptions:
    start_url: str
    scope: str = "subpath"  # page(이 페이지만) | subpath(하위 경로) | domain(같은 사이트 전체)
    max_depth: int = 2
    max_pages: int = 200
    page_formats: list[str] = field(default_factory=lambda: ["md"])
    file_types: list[str] = field(default_factory=lambda: ["pdf", "hwp", "word", "excel", "ppt"])
    custom_exts: list[str] = field(default_factory=list)
    mode: str = "run"  # scan | run
    output_dir: str = ""
    cookies: str = ""  # 브라우저 로그인 상태를 그대로 쓰기 위한 Cookie 헤더
    user_agent: str = "Mozilla/5.0"
    respect_robots: bool = True
    delay_ms: int = 300
    concurrency: int = 4
    max_file_mb: int = 300
    max_total_mb: int = 5000
    include: str = ""  # 이 문자열(정규식)이 들어간 주소만 (비우면 전체)
    exclude: str = ""  # 이 문자열(정규식)이 들어간 주소는 제외
    make_zip: bool = False
    # 브라우저 네트워크로 받기: Electron(Main)의 가져오기 서비스 주소·토큰.
    # 비우면 Python(httpx)으로 직접 받음. 브라우저 경유 시 Chrome과 같은 TLS·헤더·쿠키로 요청 → 방화벽 차단 회피
    fetch_via: str = ""
    fetch_token: str = ""


@dataclass
class FoundFile:
    url: str
    ext: str
    category: str
    source: str  # 발견한 페이지
    text: str  # 링크 글자
    size: int | None = None
    status: str = "found"  # found | done | skipped | error
    path: str = ""


class CrawlJob:
    def __init__(self, opts: CrawlOptions, base_output: Path):
        self.id = uuid.uuid4().hex[:10]
        self.opts = opts
        start = urlparse(opts.start_url)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.root = Path(opts.output_dir or base_output) / safe_name(f"{start.netloc}_{stamp}")
        self.state = "queued"
        self.message = ""
        self.pages: list[dict] = []  # {url, title, depth, saved:[...]}
        self.files: dict[str, FoundFile] = {}
        self.errors: list[str] = []
        self.current = ""
        self.bytes = 0
        self.queued = 0
        self.started = time.time()
        self.finished: float | None = None
        self.zip_path = ""
        self._cancel = asyncio.Event()
        self._robots: dict[str, urllib.robotparser.RobotFileParser | None] = {}
        exts = {e for t in opts.file_types for e in FILE_TYPES.get(t, [])}
        exts |= {e.lower().lstrip(".") for e in opts.custom_exts if e.strip()}
        self.exts = exts
        self._include = re.compile(opts.include) if opts.include else None
        self._exclude = re.compile(opts.exclude) if opts.exclude else None
        base_path = start.path if start.path.endswith("/") else start.path.rsplit("/", 1)[0] + "/"
        self._prefix = f"{start.scheme}://{start.netloc}{base_path}"

    # ───────── 상태 ─────────
    def cancel(self) -> None:
        self._cancel.set()

    def status(self, with_files: bool = False) -> dict:
        files = list(self.files.values())
        d = {
            "id": self.id,
            "state": self.state,
            "message": self.message,
            "start_url": self.opts.start_url,
            "mode": self.opts.mode,
            "output_dir": str(self.root),
            "zip_path": self.zip_path,
            "pages_done": len(self.pages),
            "pages_queued": self.queued,
            "files_found": len(files),
            "files_done": sum(f.status == "done" for f in files),
            "bytes": self.bytes,
            "current": self.current,
            "errors": self.errors[-30:],
            "elapsed": round((self.finished or time.time()) - self.started, 1),
        }
        if with_files:
            d["files"] = [f.__dict__ for f in files[:3000]]
        return d

    # ───────── 범위·규칙 ─────────
    def in_scope(self, url: str) -> bool:
        u = urlparse(url)
        s = urlparse(self.opts.start_url)
        if u.scheme not in ("http", "https"):
            return False
        if self.opts.scope == "domain":
            ok = u.netloc == s.netloc
        elif self.opts.scope == "subpath":
            ok = url.startswith(self._prefix)
        else:  # page
            ok = False
        if ok and self._include and not self._include.search(url):
            return False
        if self._exclude and self._exclude.search(url):
            return False
        return ok

    def file_ext(self, url: str) -> str | None:
        name = unquote(urlparse(url).path.rsplit("/", 1)[-1]).lower()
        if "." not in name:
            return None
        ext = name.rsplit(".", 1)[-1]
        return ext if ext in self.exts else None

    async def allowed(self, client: httpx.AsyncClient, url: str) -> bool:
        if not self.opts.respect_robots:
            return True
        u = urlparse(url)
        host = f"{u.scheme}://{u.netloc}"
        if host not in self._robots:
            rp = urllib.robotparser.RobotFileParser()
            try:
                r = await self._get(client, f"{host}/robots.txt", timeout=10)
                rp.parse(r.text.splitlines() if r.status_code == 200 else [])
            except httpx.HTTPError:
                rp.parse([])
            self._robots[host] = rp
        rp = self._robots[host]
        return rp is None or rp.can_fetch(self.opts.user_agent, url)

    # ───────── 요청 (직접 또는 브라우저 경유) ─────────
    def _req(self, url: str) -> tuple[str, dict, dict]:
        if self.opts.fetch_via:
            base = httpx.URL(self.opts.fetch_via)  # 주소에 붙은 ?p=(워크스페이스)를 유지하며 url 추가
            params = {**dict(base.params), "url": url}
            return str(base.copy_with(query=None)), params, {"X-Omni-Token": self.opts.fetch_token}
        return url, {}, {}

    def _final(self, r: httpx.Response, url: str) -> str:
        return r.headers.get("x-final-url", url) if self.opts.fetch_via else str(r.url)

    async def _get(self, client: httpx.AsyncClient, url: str, **kw) -> httpx.Response:
        target, params, headers = self._req(url)
        return await client.get(target, params=params, headers=headers, **kw)

    # ───────── 실행 ─────────
    def _client(self) -> httpx.AsyncClient:
        headers = {"User-Agent": self.opts.user_agent, "Accept-Language": "ko,en;q=0.8"}
        if self.opts.cookies:
            headers["Cookie"] = self.opts.cookies
        return httpx.AsyncClient(headers=headers, follow_redirects=True, timeout=httpx.Timeout(30, connect=15))

    async def run(self) -> None:
        self.state = "running"
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            async with self._client() as client:
                await self._crawl(client)
                if self.opts.mode == "run" and not self._cancel.is_set():
                    await self._download(client, [f.url for f in self.files.values()])
            if self._cancel.is_set():
                self.state, self.message = "cancelled", "사용자가 중지했습니다."
            else:
                self.state = "scanned" if self.opts.mode == "scan" else "done"
                self.message = self._summary()
            self.finished = time.time()
            self._write_outputs()  # 최종 상태가 _crawl.json에 기록되도록 마지막에
        except Exception as e:  # 예상 못 한 오류도 상태로 알려 줌
            self.state, self.message = "error", f"{type(e).__name__}: {e}"
        finally:
            self.current = ""
            self.finished = self.finished or time.time()

    async def download_selected(self, urls: list[str]) -> None:
        """scan 후 사용자가 고른 파일만 받기"""
        self.state, self._cancel = "downloading", asyncio.Event()
        self.finished = None
        try:
            async with self._client() as client:
                await self._download(client, urls)
            self.state = "cancelled" if self._cancel.is_set() else "done"
            self.message = self._summary()
            self.finished = time.time()
            self._write_outputs()
        except Exception as e:
            self.state, self.message = "error", f"{type(e).__name__}: {e}"
        finally:
            self.current = ""
            self.finished = self.finished or time.time()

    def _summary(self) -> str:
        done = sum(f.status == "done" for f in self.files.values())
        return f"페이지 {len(self.pages)}개, 파일 {done}/{len(self.files)}개, {self.bytes / 1_048_576:.1f}MB"

    async def _crawl(self, client: httpx.AsyncClient) -> None:
        start = urldefrag(self.opts.start_url)[0]
        queue: asyncio.Queue[tuple[str, int]] = asyncio.Queue()
        seen = {start}
        await queue.put((start, 0))
        self.queued = 1
        sem = asyncio.Semaphore(max(1, self.opts.concurrency))

        async def worker() -> None:
            while not self._cancel.is_set():
                try:
                    url, depth = await asyncio.wait_for(queue.get(), timeout=1.0)
                except TimeoutError:
                    if queue.empty() and active[0] == 0:
                        return
                    continue
                active[0] += 1
                try:
                    if len(self.pages) >= self.opts.max_pages:
                        continue
                    async with sem:
                        links = await self._visit(client, url, depth)
                    for link in links:
                        if link in seen or depth + 1 > self.opts.max_depth:
                            continue
                        if self.in_scope(link) and not self.file_ext(link):
                            seen.add(link)
                            self.queued += 1
                            await queue.put((link, depth + 1))
                finally:
                    active[0] -= 1
                    self.queued = max(0, self.queued - 1)
                    queue.task_done()

        active = [0]
        await asyncio.gather(*(worker() for _ in range(max(1, self.opts.concurrency))))

    async def _visit(self, client: httpx.AsyncClient, url: str, depth: int) -> list[str]:
        self.current = url
        if not await self.allowed(client, url):
            self.errors.append(f"robots.txt 금지: {url}")
            return []
        await asyncio.sleep(self.opts.delay_ms / 1000)
        try:
            r = await self._get(client, url)
        except httpx.HTTPError as e:
            self.errors.append(f"접속 실패: {url} ({type(e).__name__})")
            return []
        ctype = r.headers.get("content-type", "").split(";")[0].strip().lower()
        if r.status_code != 200 or ctype not in HTML_TYPES:
            if r.status_code != 200:
                self.errors.append(f"HTTP {r.status_code}: {url}")
            return []
        html = r.text
        final_url = self._final(r, url)
        soup = BeautifulSoup(html, "lxml")
        title = (soup.title.string or "").strip() if soup.title and soup.title.string else final_url
        links: list[str] = []
        for tag, attr in (("a", "href"), ("area", "href"), ("iframe", "src"), ("embed", "src"),
                          ("object", "data"), ("source", "src"), ("img", "src"), ("video", "src"), ("audio", "src")):
            for el in soup.find_all(tag):
                raw = el.get(attr)
                if not raw or raw.startswith(("javascript:", "mailto:", "tel:", "data:")):
                    continue
                link = urldefrag(urljoin(final_url, raw.strip()))[0]
                ext = self.file_ext(link)
                if ext and link not in self.files:
                    text = el.get_text(" ", strip=True)[:120] if tag == "a" else el.get("alt", "")[:120]
                    cat = next((c for c, es in FILE_TYPES.items() if ext in es), "custom")
                    self.files[link] = FoundFile(link, ext, cat, final_url, text)
                elif tag in ("a", "area", "iframe"):
                    links.append(link)
        page = {"url": final_url, "title": title, "depth": depth, "saved": []}
        self._save_page(page, html)
        self.pages.append(page)
        return links

    # ───────── 저장 ─────────
    def _rel(self, url: str, ext: str) -> Path:
        """주소 → 폴더 구조를 살린 안전한 상대 경로 (Windows 금지 문자·예약어·길이 처리)"""
        u = urlparse(url)
        parts = [safe_name(unquote(p)) for p in u.path.split("/") if p]
        if not parts or u.path.endswith("/"):
            parts.append("index")
        stem = parts[-1].rsplit(".", 1)[0] if "." in parts[-1] else parts[-1]
        if u.query:
            stem += "_" + hashlib.md5(u.query.encode()).hexdigest()[:6]
        parts[-1] = f"{stem[:80]}.{ext}"
        rel = Path(safe_name(u.netloc), *parts)
        if len(str(rel)) > 180:  # 경로가 너무 길면 짧게
            rel = Path(safe_name(u.netloc), f"{stem[:40]}_{hashlib.md5(url.encode()).hexdigest()[:8]}.{ext}")
        return rel

    def _save_page(self, page: dict, html: str) -> None:
        fmts = set(self.opts.page_formats) & PAGE_FORMATS
        if not fmts:
            return
        md = txt = None
        if fmts & {"md", "merged", "json", "txt"}:
            md, txt = extract_markdown(html, page["url"])
            page["_md"] = md if "merged" in fmts else None
        for fmt in fmts - {"merged"}:
            rel = self._rel(page["url"], fmt)
            out = self.root / "pages" / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            if fmt == "html":  # 이미지·CSS는 원본 사이트에서 불러오도록 <base> 추가
                content = re.sub(r"(<head[^>]*>)", rf'\1<base href="{page["url"]}">', html, count=1, flags=re.I)
            elif fmt == "md":
                content = f"# {page['title']}\n\n원본: {page['url']}\n\n{md}"
            elif fmt == "txt":
                content = f"{page['title']}\n{page['url']}\n\n{txt}"
            else:
                content = json.dumps({"url": page["url"], "title": page["title"], "depth": page["depth"],
                                      "text": txt, "markdown": md}, ensure_ascii=False, indent=2)
            out.write_text(content, encoding="utf-8")
            self.bytes += out.stat().st_size
            page["saved"].append(str(out.relative_to(self.root)))

    async def _download(self, client: httpx.AsyncClient, urls: list[str]) -> None:
        sem = asyncio.Semaphore(max(1, self.opts.concurrency))
        max_file = self.opts.max_file_mb * 1_048_576
        max_total = self.opts.max_total_mb * 1_048_576

        async def one(url: str) -> None:
            f = self.files.get(url)
            if not f or f.status == "done" or self._cancel.is_set():
                return
            if self.bytes > max_total:
                f.status = "skipped"
                return
            async with sem:
                if not await self.allowed(client, url):
                    f.status = "skipped"
                    self.errors.append(f"robots.txt 금지: {url}")
                    return
                self.current = url
                out = self.root / "files" / self._rel(url, f.ext)
                out.parent.mkdir(parents=True, exist_ok=True)
                tmp = out.with_suffix(out.suffix + ".part")
                try:
                    target, params, headers = self._req(url)
                    async with client.stream("GET", target, params=params, headers=headers) as r:
                        if r.status_code != 200:
                            raise httpx.HTTPStatusError(f"HTTP {r.status_code}", request=r.request, response=r)
                        name = filename_from_disposition(r.headers.get("content-disposition", ""))
                        if name:  # 서버가 알려 준 실제 파일 이름 사용 (한글 이름 포함)
                            out = out.with_name(safe_name(name))
                        size = 0
                        with tmp.open("wb") as fh:
                            async for chunk in r.aiter_bytes(65536):
                                size += len(chunk)
                                if size > max_file or self._cancel.is_set():
                                    raise ValueError("파일 크기 상한 초과" if size > max_file else "중지됨")
                                fh.write(chunk)
                    tmp.replace(out)
                    f.status, f.size, f.path = "done", size, str(out.relative_to(self.root))
                    self.bytes += size
                except Exception as e:
                    tmp.unlink(missing_ok=True)
                    f.status = "error"
                    self.errors.append(f"다운로드 실패: {url} ({e})")
                await asyncio.sleep(self.opts.delay_ms / 1000)

        await asyncio.gather(*(one(u) for u in urls))

    def _write_outputs(self) -> None:
        """목록 파일(manifest), 전체 합본 Markdown, 선택 시 ZIP"""
        self.root.mkdir(parents=True, exist_ok=True)
        with (self.root / "_목록_pages.csv").open("w", newline="", encoding="utf-8-sig") as fh:  # 엑셀 한글 호환
            w = csv.writer(fh)
            w.writerow(["깊이", "제목", "주소", "저장 파일"])
            for p in self.pages:
                w.writerow([p["depth"], p["title"], p["url"], " | ".join(p["saved"])])
        if self.files:
            with (self.root / "_목록_files.csv").open("w", newline="", encoding="utf-8-sig") as fh:
                w = csv.writer(fh)
                w.writerow(["종류", "확장자", "상태", "크기(바이트)", "링크 글자", "주소", "발견 페이지", "저장 경로"])
                for f in self.files.values():
                    w.writerow([f.category, f.ext, f.status, f.size or "", f.text, f.url, f.source, f.path])
        if "merged" in self.opts.page_formats and self.pages:
            parts = [f"# {urlparse(self.opts.start_url).netloc} 전체 합본\n\n시작 주소: {self.opts.start_url}\n\n## 목차\n"]
            parts += [f"{i}. [{p['title']}]({p['url']})" for i, p in enumerate(self.pages, 1)]
            for p in self.pages:
                if p.get("_md"):
                    parts.append(f"\n\n---\n\n# {p['title']}\n\n원본: {p['url']}\n\n{p['_md']}")
            (self.root / "_전체합본.md").write_text("\n".join(parts), encoding="utf-8")
        (self.root / "_crawl.json").write_text(
            json.dumps({**self.status(), "options": self.opts.__dict__ | {"cookies": "(생략)", "fetch_token": "(생략)"}}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        if self.opts.make_zip:
            zpath = self.root.with_suffix(".zip")
            with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
                for fp in self.root.rglob("*"):
                    if fp.is_file():
                        z.write(fp, fp.relative_to(self.root.parent))
            self.zip_path = str(zpath)


def extract_markdown(html: str, url: str = "") -> tuple[str, str]:
    """본문 추출: trafilatura(광고·메뉴 제거) → 실패 시 BeautifulSoup 전체 글자"""
    import trafilatura

    md = trafilatura.extract(html, url=url or None, output_format="markdown", include_links=True,
                             include_tables=True, include_images=False, favor_recall=True) or ""
    txt = trafilatura.extract(html, url=url or None, include_tables=True, favor_recall=True) or ""
    if not md.strip():
        soup = BeautifulSoup(html, "lxml")
        for t in soup(["script", "style", "noscript"]):
            t.decompose()
        txt = "\n".join(line.strip() for line in soup.get_text("\n").splitlines() if line.strip())
        md = txt
    return md, txt or md


def safe_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .") or "_"
    if name.split(".")[0].lower() in WIN_RESERVED:
        name = "_" + name
    return name[:120]


def filename_from_disposition(cd: str) -> str | None:
    m = re.search(r"filename\*\s*=\s*[^']*''([^;]+)", cd, re.I)
    if m:
        return unquote(m.group(1).strip('"'))
    m = re.search(r'filename\s*=\s*"?([^";]+)"?', cd, re.I)
    if not m:
        return None
    raw = m.group(1)
    try:  # 일부 한국 서버는 EUC-KR 바이트를 latin-1로 보냄
        return raw.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        try:
            return raw.encode("latin-1").decode("cp949")
        except (UnicodeEncodeError, UnicodeDecodeError):
            return raw
