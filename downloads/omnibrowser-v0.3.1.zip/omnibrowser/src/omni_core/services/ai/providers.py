"""AI 제공자 3종(OpenAI · Anthropic Claude · Google Gemini)을 같은 방식으로 호출.

SDK 없이 httpx로 REST API를 직접 호출한다 → 의존성이 적고, 세 제공자의 스트리밍을 한 형식(텍스트 조각)으로 통일.
모델 이름은 자주 바뀌므로 기본값은 설정으로 바꿀 수 있고, /ai/models 로 실제 목록을 불러올 수 있다.
"""
import json
import re
from collections.abc import AsyncIterator
from dataclasses import dataclass

import httpx

from ...config import get_settings
from ...errors import OmniError
from ...secrets_store import get_secret


@dataclass
class ProviderInfo:
    name: str
    label: str
    default_model: str
    key_url: str  # API 키 발급 페이지


PROVIDERS: dict[str, ProviderInfo] = {
    "openai": ProviderInfo("openai", "OpenAI (GPT)", "gpt-5.4-mini", "https://platform.openai.com/api-keys"),
    "anthropic": ProviderInfo("anthropic", "Anthropic (Claude)", "claude-haiku-4-5-20251001", "https://console.anthropic.com/settings/keys"),
    "gemini": ProviderInfo("gemini", "Google (Gemini)", "gemini-3.6-flash", "https://aistudio.google.com/apikey"),
}
MAX_OUTPUT_TOKENS = 8000
TIMEOUT = httpx.Timeout(120, connect=15)


def available_providers() -> list[str]:
    names = list(PROVIDERS)
    if get_settings().allow_mock_ai:
        names.append("mock")
    return names


def _key(provider: str) -> str:
    key = get_secret(provider)
    if not key:
        label = PROVIDERS[provider].label
        raise OmniError(
            "AI_KEY_MISSING", f"{label} API 키가 등록되지 않았습니다.",
            f"설정 → AI에서 키를 등록하세요 (발급: {PROVIDERS[provider].key_url})",
        )
    return key


def _raise_for(provider: str, status: int, body: str) -> None:
    hint = {
        401: "API 키가 올바른지 확인하세요.",
        403: "API 키 권한 또는 지역 제한을 확인하세요.",
        404: "모델 이름이 올바른지 확인하세요 (설정 → AI → 모델 목록 불러오기).",
        429: "사용량 한도 초과이거나 너무 자주 요청했습니다. 잠시 후 다시 시도하거나 요금제·잔액을 확인하세요.",
    }.get(status, "잠시 후 다시 시도하세요.")
    try:
        detail = json.loads(body).get("error", {})
        msg = detail.get("message") if isinstance(detail, dict) else str(detail)
    except (ValueError, AttributeError):
        msg = body[:200]
    raise OmniError("AI_REQUEST_FAILED", f"{PROVIDERS[provider].label} 오류 {status}: {msg}", hint, 502)


async def _sse_lines(resp: httpx.Response) -> AsyncIterator[dict]:
    """Server-Sent Events의 data: 줄을 JSON으로 풀어서 하나씩 돌려준다."""
    async for line in resp.aiter_lines():
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if not data or data == "[DONE]":
            continue
        try:
            yield json.loads(data)
        except ValueError:
            continue


async def stream_chat(
    provider: str, model: str | None, system: str, messages: list[dict]
) -> AsyncIterator[str]:
    """messages: [{"role": "user"|"assistant", "content": "..."}] → 응답 텍스트 조각을 차례로 yield"""
    if provider == "mock":
        async for piece in _mock(system, messages):
            yield piece
        return
    if provider not in PROVIDERS:
        raise OmniError("AI_UNKNOWN_PROVIDER", f"알 수 없는 AI 제공자: {provider}")
    key = _key(provider)
    model = model or PROVIDERS[provider].default_model

    if provider == "openai":
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {key}"}
        body = {
            "model": model,
            "stream": True,
            "max_completion_tokens": MAX_OUTPUT_TOKENS,
            "messages": [{"role": "system", "content": system}, *messages],
        }
    elif provider == "anthropic":
        url = "https://api.anthropic.com/v1/messages"
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01"}
        body = {"model": model, "stream": True, "max_tokens": MAX_OUTPUT_TOKENS, "system": system, "messages": messages}
    else:  # gemini
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse"
        headers = {"x-goog-api-key": key}
        body = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [
                {"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
                for m in messages
            ],
            "generationConfig": {"maxOutputTokens": MAX_OUTPUT_TOKENS},
        }

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        async with client.stream("POST", url, headers=headers, json=body) as resp:
            if resp.status_code != 200:
                _raise_for(provider, resp.status_code, (await resp.aread()).decode("utf-8", "replace"))
            async for ev in _sse_lines(resp):
                text = _extract(provider, ev)
                if text:
                    yield text


def _extract(provider: str, ev: dict) -> str:
    if provider == "openai":
        choices = ev.get("choices") or [{}]
        return (choices[0].get("delta") or {}).get("content") or ""
    if provider == "anthropic":
        if ev.get("type") == "content_block_delta":
            return (ev.get("delta") or {}).get("text") or ""
        if ev.get("type") == "error":
            raise OmniError("AI_REQUEST_FAILED", f"Claude 오류: {ev.get('error', {}).get('message')}", status=502)
        return ""
    parts = ((ev.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
    return "".join(p.get("text", "") for p in parts if not p.get("thought"))


def _ver(s: str) -> tuple:
    """'gemini-3.6-flash' → (3, 6) 처럼 버전 숫자 추출 (정렬용)"""
    m = re.search(r"(\d+(?:\.\d+)*)", s)
    return tuple(int(x) for x in m.group(1).split(".")) if m else ()


async def list_models(provider: str, kind: str = "chat") -> list[dict]:
    """제공자가 실제로 제공하는 모델 목록 [{id, name, created}] (최신순).
    kind = chat(텍스트 생성) | tts(음성 합성)"""
    if provider == "mock":
        return [{"id": "mock-1", "name": "Mock", "created": 0}]
    key = _key(provider)
    out: list[dict] = []
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        if provider == "openai":
            r = await client.get("https://api.openai.com/v1/models", headers={"Authorization": f"Bearer {key}"})
            if r.status_code == 200:
                for m in r.json().get("data", []):
                    i = m["id"]
                    is_tts = "tts" in i
                    if kind == "tts" and not is_tts:
                        continue
                    skip = ("embedding", "whisper", "tts", "dall-e", "image", "audio", "realtime",
                            "moderation", "transcribe", "search", "davinci", "babbage", "codex")
                    if kind == "chat" and (not i.startswith(("gpt", "o1", "o3", "o4", "o5", "chatgpt")) or any(s in i for s in skip)):
                        continue
                    out.append({"id": i, "name": i, "created": int(m.get("created") or 0)})
        elif provider == "anthropic":
            r = await client.get(
                "https://api.anthropic.com/v1/models?limit=100",
                headers={"x-api-key": key, "anthropic-version": "2023-06-01"},
            )
            if r.status_code == 200 and kind == "chat":
                for m in r.json().get("data", []):
                    ts = 0
                    try:
                        from datetime import datetime

                        ts = int(datetime.fromisoformat(m.get("created_at", "").replace("Z", "+00:00")).timestamp())
                    except ValueError:
                        pass
                    out.append({"id": m["id"], "name": m.get("display_name") or m["id"], "created": ts})
        else:
            r = await client.get(
                "https://generativelanguage.googleapis.com/v1beta/models?pageSize=500", headers={"x-goog-api-key": key}
            )
            if r.status_code == 200:
                for m in r.json().get("models", []):
                    if "generateContent" not in m.get("supportedGenerationMethods", []):
                        continue
                    i = m["name"].removeprefix("models/")
                    is_tts = "tts" in i
                    if (kind == "tts") != is_tts or (kind == "chat" and any(s in i for s in ("image", "embedding", "aqa", "live"))):
                        continue
                    out.append({"id": i, "name": m.get("displayName") or i, "created": 0})
    if r.status_code != 200:
        _raise_for(provider, r.status_code, r.text)
    out.sort(key=lambda m: (m["created"], _ver(m["id"]), m["id"]), reverse=True)
    return out


# 제공자별 "가성비 기본 모델" 계열: 목록에서 이 계열의 가장 높은 버전을 추천한다
_FAMILY = {
    ("gemini", "chat"): r"^gemini-(\d+(?:\.\d+)?)-flash$",
    ("openai", "chat"): r"^gpt-(\d+(?:\.\d+)?)-mini$",
    ("anthropic", "chat"): r"^claude-haiku-",
    ("gemini", "tts"): r"^gemini-(\d+(?:\.\d+)?)-flash(-preview)?-tts(-preview)?$",
    ("openai", "tts"): r"^gpt-.*mini-tts$",
}


def recommend(provider: str, models: list[dict], kind: str = "chat") -> str | None:
    pat = _FAMILY.get((provider, kind))
    if not models:
        return None
    if not pat:
        return models[0]["id"]
    cands = [m for m in models if re.search(pat, m["id"]) and "preview" not in m["id"].replace("tts-preview", "")]
    if not cands:
        cands = [m for m in models if re.search(pat, m["id"])]
    if not cands:
        return None
    cands.sort(key=lambda m: (m["created"], _ver(m["id"]), len(m["id"]) * -1), reverse=True)
    return cands[0]["id"]


async def _mock(system: str, messages: list[dict]) -> AsyncIterator[str]:
    """테스트용 가짜 AI: 네트워크 없이 파이프라인(스트리밍·구간 번역)을 검증한다."""
    text = messages[-1]["content"]
    if "⟦" in text:  # 구간 번역 형식: 표시(⟦n⟧)를 유지하고 앞에 [번역]을 붙인다
        body = text.split("\n\n", 1)[-1]
        for num, seg in re.findall(r"⟦(\d+)⟧\s*([^⟦]*)", body):
            yield f"⟦{num}⟧ [번역] {seg.strip()}\n"
        return
    reply = f"[mock 응답] {text[:200]}"
    for i in range(0, len(reply), 12):
        yield reply[i : i + 12]
