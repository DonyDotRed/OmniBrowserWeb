"""AI 작업 프리셋: 버튼 하나로 번역·요약·정리 등을 실행 (AI-01~06)."""
from dataclasses import dataclass

LANGS = {"ko": "한국어", "en": "영어", "ja": "일본어", "zh": "중국어(간체)", "de": "독일어", "fr": "프랑스어", "es": "스페인어"}


@dataclass
class Preset:
    id: str
    label: str
    icon: str
    instruction: str  # {lang} 자리에 대상 언어가 들어감


PRESETS: list[Preset] = [
    Preset("summarize", "요약", "📝", "다음 내용을 {lang}로 요약하세요. 먼저 한 문장 결론, 이어서 핵심 5~7개를 글머리표로. 숫자·고유명사는 정확히 유지하세요."),
    Preset("translate", "번역", "🌐", "다음 텍스트를 {lang}로 자연스럽고 정확하게 번역하세요. 원문의 문단·목록 구조를 유지하고 번역문만 출력하세요. 전문 용어는 처음 나올 때 괄호 안에 원어를 병기하세요."),
    Preset("organize", "정리 노트", "🗂", "다음 내용을 {lang} 학습 노트로 정리하세요. Markdown 제목(##)·소제목·글머리표를 쓰고, 비교할 항목이 있으면 표로 만드세요. 마지막에 '핵심 용어' 목록을 붙이세요."),
    Preset("keypoints", "핵심 3줄", "⚡", "다음 내용의 핵심을 {lang}로 정확히 3줄로 요약하세요."),
    Preset("explain", "쉽게 설명", "💡", "다음 내용을 해당 분야를 처음 접하는 사람도 이해하도록 {lang}로 쉽게 설명하세요. 비유와 예시를 하나씩 들어 주세요."),
    Preset("glossary", "용어 사전", "📚", "다음 내용에 나오는 전문 용어를 찾아 {lang}로 '용어 | 뜻 | 원어' 표로 정리하세요."),
    Preset("quiz", "퀴즈 만들기", "❓", "다음 내용으로 이해도 확인용 객관식 문제 5개를 {lang}로 만드세요. 각 문제 아래에 정답과 해설을 붙이세요."),
    Preset("proofread", "교정", "✍", "다음 글의 맞춤법·문법·어색한 표현을 교정하세요. 교정된 전체 글을 먼저 보여 주고, 이어서 주요 수정 사항을 '원문 → 수정 (이유)' 목록으로 보여 주세요."),
    Preset("action", "할 일 추출", "✅", "다음 내용에서 해야 할 일·마감일·담당자를 찾아 {lang} 체크리스트(- [ ])로 정리하세요. 없으면 없다고 답하세요."),
]
PRESET_MAP = {p.id: p for p in PRESETS}

SYSTEM_BASE = (
    "당신은 웹 브라우저에 내장된 AI 도우미입니다. 사용자가 보고 있는 웹페이지나 선택한 텍스트를 다룹니다. "
    "주어진 자료에 근거해 답하고, 자료에 없는 내용은 추측이라고 밝히세요. 답은 Markdown으로 작성하세요."
)

SEGMENT_SYSTEM = (
    "You are a professional translator embedded in a web browser. The user sends text segments, each starting "
    "with a marker like ⟦12⟧. Translate each segment into {lang}. Output every segment in the same order, each "
    "starting with its exact original marker, one per line. Do not merge, split, skip, or explain. Keep numbers, "
    "code, URLs and proper nouns accurate."
)


def lang_name(code: str) -> str:
    return LANGS.get(code, code)
