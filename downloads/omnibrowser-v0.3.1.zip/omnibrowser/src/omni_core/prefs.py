"""설정값 읽기·쓰기 헬퍼 (라우터·서비스 공용). 저장소는 settings 테이블(JSON 값)."""
import json

from .db.connection import connect
from .routers.common import now_ms


def get_setting(key: str, default=None):
    from .routers.settings import DEFAULTS

    with connect() as con:
        row = con.execute("SELECT value_json FROM settings WHERE key = ?", (key,)).fetchone()
    if row:
        return json.loads(row["value_json"])
    return DEFAULTS.get(key, default)


def set_setting(key: str, value) -> None:
    with connect() as con:
        con.execute(
            """INSERT INTO settings (key, value_json, updated_at) VALUES (?, ?, ?)
               ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at""",
            (key, json.dumps(value, ensure_ascii=False), now_ms()),
        )
