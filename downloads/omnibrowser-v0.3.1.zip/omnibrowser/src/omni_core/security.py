import secrets

from fastapi import HTTPException, Security
from fastapi.security import APIKeyHeader

from .config import get_settings

_header = APIKeyHeader(name="X-Omni-Token", auto_error=False)


def require_token(token: str | None = Security(_header)) -> None:
    expected = get_settings().core_token
    # compare_digest: 비교 시간이 일정해 토큰 추측 공격(타이밍 공격)을 막음
    if not token or not secrets.compare_digest(token, expected):
        raise HTTPException(status_code=401, detail="invalid token")
