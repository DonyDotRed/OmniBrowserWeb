import os
import threading
import time

_last_beat = time.monotonic()


def beat() -> None:
    global _last_beat
    _last_beat = time.monotonic()


def start_watchdog(timeout_sec: int = 30) -> None:
    def loop() -> None:
        while True:
            time.sleep(5)
            if time.monotonic() - _last_beat > timeout_sec:
                os._exit(0)
    threading.Thread(target=loop, daemon=True).start()
