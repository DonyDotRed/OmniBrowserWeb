"""설정: 환경 변수(OMNI_*)와 .env 파일에서 읽음. 환경 변수가 .env보다 우선한다."""
from functools import lru_cache
from pathlib import Path

from platformdirs import user_data_dir
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="OMNI_", env_file=".env", extra="ignore")

    data_dir: Path = Path(user_data_dir("OmniBrowser", appauthor=False)) / "core"
    core_token: str = "dev-token-change-me"
    dev_mode: bool = False          # True: /docs 활성화, .env API 키 폴백 허용
    watchdog: bool = False          # Electron이 실행할 때 True로 전달 (heartbeat 감시)
    tts_cache_limit_mb: int = 1024
    openai_tts_model: str = "gpt-4o-mini-tts"   # 모델명은 설정으로 (하드코딩 금지)

    # 개발 모드 전용 API 키 폴백 (.env). 운영에서는 OS 키체인 사용
    openai_api_key: str | None = None
    anthropic_api_key: str | None = None
    gemini_api_key: str | None = None
    allow_mock_ai: bool = False     # 테스트용 가짜 AI 제공자 (개발·자동 테스트 전용)

    @property
    def db_path(self) -> Path:
        return self.data_dir / "omni.db"

    @property
    def cache_dir(self) -> Path:
        return self.data_dir / "cache"


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.cache_dir.mkdir(parents=True, exist_ok=True)   # data_dir도 함께 생성됨
    return s
