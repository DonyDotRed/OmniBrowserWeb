"""API 키 저장소: Windows 자격 증명 관리자 / macOS 키체인 / Linux Secret Service."""
import keyring
from keyring.errors import KeyringError, PasswordDeleteError

from .config import get_settings
from .errors import OmniError

SERVICE = "OmniBrowser"
_HINT = "OS 키체인을 쓸 수 없습니다. Windows·macOS는 기본 지원, Linux는 gnome-keyring 등을 설치하세요."


def set_secret(name: str, value: str) -> None:
    try:
        keyring.set_password(SERVICE, name, value)
    except KeyringError as e:
        raise OmniError("KEYRING_UNAVAILABLE", "API 키를 저장하지 못했습니다.", _HINT, 500) from e


def get_secret(name: str) -> str | None:
    try:
        value = keyring.get_password(SERVICE, name)
    except KeyringError:
        value = None                                       # 키체인 없음 → 아래 개발용 폴백으로
    s = get_settings()
    if value is None and s.dev_mode:                      # 개발 모드에서만 .env 폴백
        value = getattr(s, f"{name}_api_key", None)
    return value


def delete_secret(name: str) -> None:
    try:
        keyring.delete_password(SERVICE, name)
    except PasswordDeleteError:
        pass                                               # 이미 없으면 무시


def masked(name: str) -> str | None:
    v = get_secret(name)
    return f"{v[:3]}...{v[-4:]}" if v else None           # 키 원문은 절대 반환하지 않음
