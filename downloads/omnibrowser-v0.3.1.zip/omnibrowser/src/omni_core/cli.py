"""예: uv run omni-core --port 47800 --reload"""
import argparse
import os
from pathlib import Path

import uvicorn


def main() -> None:
    p = argparse.ArgumentParser(prog="omni-core", description="OmniBrowser Python Core")
    p.add_argument("--port", type=int, default=47800)
    p.add_argument("--data-dir", help="데이터 폴더 (Electron이 userData/core 경로를 전달)")
    p.add_argument("--reload", action="store_true", help="코드 변경 시 자동 재시작 (개발용)")
    args = p.parse_args()

    if args.data_dir:
        os.environ["OMNI_DATA_DIR"] = args.data_dir        # Settings가 읽도록 전달

    # 보안: 주소는 127.0.0.1로 고정 (외부 접속 불가). 옵션으로도 바꿀 수 없게 함
    if args.reload:
        src_dir = str(Path(__file__).resolve().parent)     # src/omni_core만 감시 (node_modules 제외)
        uvicorn.run("omni_core.main:create_app", factory=True, host="127.0.0.1",
                    port=args.port, reload=True, reload_dirs=[src_dir])
    else:
        from omni_core.main import create_app
        uvicorn.run(create_app(), host="127.0.0.1", port=args.port, log_level="info")
