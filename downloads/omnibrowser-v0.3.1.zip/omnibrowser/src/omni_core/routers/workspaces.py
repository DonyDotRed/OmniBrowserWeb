"""워크스페이스 (WS-01): 쿠키·로그인이 완전히 분리된 브라우징 공간"""
from fastapi import APIRouter
from pydantic import BaseModel, Field

from ..db.connection import connect
from ..errors import OmniError
from .common import new_id, now_ms

router = APIRouter(tags=["workspaces"])


class WorkspaceIn(BaseModel):
    name: str = Field(min_length=1, max_length=30)
    color: str = "#4F46E5"


@router.get("")
def list_workspaces() -> list[dict]:
    with connect() as con:
        rows = con.execute(
            """SELECT id, name, color, icon, template, partition FROM workspaces
               WHERE deleted = 0 ORDER BY sort_order, rowid"""
        ).fetchall()
    return [dict(r) for r in rows]


@router.post("")
def create(w: WorkspaceIn) -> dict:
    wid = new_id()[:12]
    with connect() as con:
        order = con.execute("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM workspaces").fetchone()[0]
        con.execute(
            """INSERT INTO workspaces (id, name, color, partition, sort_order, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (wid, w.name, w.color, f"persist:ws-{wid}", order, now_ms()),
        )
    return {"id": wid, "name": w.name, "color": w.color, "partition": f"persist:ws-{wid}"}


@router.delete("/{workspace_id}")
def delete(workspace_id: str) -> dict:
    if workspace_id == "default":
        raise OmniError("WS_DEFAULT_LOCKED", "기본 워크스페이스는 삭제할 수 없습니다.")
    with connect() as con:
        con.execute(
            "UPDATE workspaces SET deleted = 1, updated_at = ? WHERE id = ?", (now_ms(), workspace_id)
        )
    return {"ok": True}
