"""AI 도우미 API: 번역·요약·정리 등 프리셋 실행, 페이지 질문(Q&A), 페이지 구간 번역, 모델 목록."""
import re
import time
import uuid
from collections.abc import AsyncIterator

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..db.connection import connect
from ..errors import OmniError
from ..prefs import get_setting, set_setting
from ..secrets_store import get_secret
from ..services.ai.presets import PRESET_MAP, PRESETS, SEGMENT_SYSTEM, SYSTEM_BASE, lang_name
from ..services.ai.providers import (
    PROVIDERS,
    available_providers,
    list_models,
    recommend,
    stream_chat,
)
from .common import now_ms

router = APIRouter(tags=["ai"])


def _setting(key: str, default):
    return get_setting(key, default)


def _resolve(provider: str | None, model: str | None) -> tuple[str, str | None]:
    p = provider or _setting("ai.provider", "gemini")
    if p not in available_providers():
        raise OmniError("AI_UNKNOWN_PROVIDER", f"알 수 없는 AI 제공자: {p}")
    chosen = model or _setting(f"ai.model.{p}", "") or None
    if not chosen and p in PROVIDERS and _setting("ai.auto_latest", True):
        # 모델 칸이 비어 있고, 갱신한 목록에 기본 모델이 없으면(단종) 추천 최신 모델로 대체
        cached = get_setting(_cache_key(p, "chat"))
        if cached and cached.get("models"):
            ids = {m["id"] for m in cached["models"]}
            if PROVIDERS[p].default_model not in ids and cached.get("recommended"):
                chosen = cached["recommended"]
    return p, chosen


def _check_budget(extra_chars: int) -> None:
    """월간 사용량 한도 (AI-07, 리스크 R6): 글자 수 기준 대략적 비용 가드"""
    limit = int(_setting("ai.monthly_char_limit", 3_000_000))
    if limit <= 0:
        return
    t = time.localtime()
    month_start = int(time.mktime((t.tm_year, t.tm_mon, 1, 0, 0, 0, 0, 0, -1)) * 1000)
    with connect() as con:
        used = con.execute(
            "SELECT COALESCE(SUM(units), 0) FROM api_usage WHERE kind = 'ai' AND created_at >= ?", (month_start,)
        ).fetchone()[0]
    if used + extra_chars > limit:
        raise OmniError(
            "AI_MONTHLY_LIMIT", f"이번 달 AI 사용 한도({limit:,}자)에 도달했습니다. (사용: {used:,}자)",
            "설정 → AI → 월 사용 한도를 늘리거나 다음 달에 다시 사용하세요.", 429,
        )


def _log_usage(provider: str, chars: int) -> None:
    if provider == "mock":
        return
    now = now_ms()
    with connect() as con:
        con.execute(
            "INSERT INTO api_usage (id, provider, kind, units, created_at, updated_at) VALUES (?, ?, 'ai', ?, ?, ?)",
            (uuid.uuid4().hex, provider, chars, now, now),
        )


class Msg(BaseModel):
    role: str = Field(pattern="^(user|assistant)$")
    content: str


class RunIn(BaseModel):
    preset: str | None = None  # summarize | translate | ... | None(자유 질문)
    instruction: str | None = None  # 사용자가 직접 쓴 지시 (preset 대신)
    input: str = ""  # 대상 텍스트 (선택 영역 또는 페이지 본문)
    question: str | None = None  # 페이지에 대한 질문 / 이어지는 대화
    history: list[Msg] = []
    lang: str | None = None
    page_title: str = ""
    page_url: str = ""
    provider: str | None = None
    model: str | None = None


@router.get("/providers")
def providers() -> list[dict]:
    out = []
    for name in available_providers():
        info = PROVIDERS.get(name)
        out.append({
            "name": name,
            "label": info.label if info else "테스트용 가짜 AI",
            "default_model": info.default_model if info else "mock-1",
            "key_url": info.key_url if info else "",
            "has_key": name == "mock" or get_secret(name) is not None,
            "model": _setting(f"ai.model.{name}", ""),
        })
    return out


@router.get("/usage")
def usage() -> dict:
    """이번 달 제공자별 사용량(글자 수)과 한도"""
    t = time.localtime()
    month_start = int(time.mktime((t.tm_year, t.tm_mon, 1, 0, 0, 0, 0, 0, -1)) * 1000)
    with connect() as con:
        rows = con.execute(
            """SELECT provider, SUM(units) AS chars, COUNT(*) AS calls FROM api_usage
               WHERE kind = 'ai' AND created_at >= ? GROUP BY provider""",
            (month_start,),
        ).fetchall()
    return {"limit": int(_setting("ai.monthly_char_limit", 3_000_000)), "by_provider": [dict(r) for r in rows]}


@router.get("/presets")
def presets() -> list[dict]:
    return [{"id": p.id, "label": p.label, "icon": p.icon} for p in PRESETS]


def _cache_key(provider: str, kind: str) -> str:
    return f"cache.models.{kind}.{provider}"


async def models_for(provider: str, kind: str = "chat", refresh: bool = False) -> dict:
    """모델 목록 (캐시 우선). refresh=True면 회사 API에서 최신 목록을 다시 받아 저장"""
    cached = get_setting(_cache_key(provider, kind))
    if cached and not refresh:
        return cached
    lst = await list_models(provider, kind)
    data = {
        "provider": provider,
        "kind": kind,
        "updated": now_ms(),
        "models": lst,
        "recommended": recommend(provider, lst, kind),
    }
    set_setting(_cache_key(provider, kind), data)
    return data


@router.get("/models")
async def models(provider: str, kind: str = "chat", refresh: bool = False) -> dict:
    data = await models_for(provider, kind, refresh)
    info = PROVIDERS.get(provider)
    return {**data, "default": info.default_model if info and kind == "chat" else None,
            "current": _setting(f"ai.model.{provider}", "") if kind == "chat" else None}


@router.post("/models/refresh")
async def refresh_all(only_stale: bool = False) -> dict:
    """키가 등록된 모든 회사의 대화·음성 모델 목록을 최신으로 갱신.
    only_stale=True: 24시간 이내에 갱신한 것은 건너뜀 (앱 시작 시 자동 갱신용)"""
    result: dict = {}
    for name in PROVIDERS:
        if get_secret(name) is None:
            result[name] = {"skipped": "키 없음"}
            continue
        for kind in ("chat", "tts"):
            if name == "anthropic" and kind == "tts":
                continue
            cached = get_setting(_cache_key(name, kind))
            if only_stale and cached and now_ms() - cached.get("updated", 0) < 86_400_000:
                continue
            try:
                d = await models_for(name, kind, refresh=True)
                result.setdefault(name, {})[kind] = {"count": len(d["models"]), "recommended": d["recommended"]}
            except OmniError as e:
                result.setdefault(name, {})[kind] = {"error": e.message}
    return result


def _build(req: RunIn) -> tuple[str, list[dict], int]:
    lang = lang_name(req.lang or _setting("ai.lang", "ko"))
    max_in = int(_setting("ai.max_input_chars", 60_000))
    text = req.input.strip()
    note = ""
    if len(text) > max_in:
        text, note = text[:max_in], f"\n\n(자료가 길어 앞부분 {max_in:,}자만 사용했습니다.)"
    source = f"[제목] {req.page_title}\n[주소] {req.page_url}\n\n{text}{note}" if text else ""

    system = SYSTEM_BASE
    messages: list[dict] = [m.model_dump() for m in req.history]
    if req.preset or req.instruction:
        instr = PRESET_MAP[req.preset].instruction if req.preset in PRESET_MAP else (req.instruction or "")
        if not source:
            raise OmniError("AI_NO_INPUT", "처리할 텍스트가 없습니다.", "텍스트를 선택하거나 '페이지 전체'를 대상으로 고르세요.")
        messages.append({"role": "user", "content": f"{instr.format(lang=lang)}\n\n---\n{source}"})
    else:
        if not req.question:
            raise OmniError("AI_NO_INPUT", "질문을 입력하세요.")
        if source:  # 페이지 내용을 배경 자료로 제공 (Q&A)
            system += f"\n\n다음은 사용자가 보고 있는 자료입니다. 이 자료를 근거로 {lang}로 답하세요.\n<자료>\n{source}\n</자료>"
        messages.append({"role": "user", "content": req.question})
    chars = len(system) + sum(len(m["content"]) for m in messages)
    return system, messages, chars


@router.post("/stream")
async def run_stream(req: RunIn) -> StreamingResponse:
    """응답을 글자 조각으로 흘려보낸다 (text/plain). 첫 조각을 미리 받아 오류는 일반 JSON 오류로 돌려준다."""
    provider, model = _resolve(req.provider, req.model)
    system, messages, chars = _build(req)
    _check_budget(chars)
    agen = stream_chat(provider, model, system, messages)
    try:
        first = await agen.__anext__()
    except StopAsyncIteration:
        first = ""

    async def body() -> AsyncIterator[str]:
        out = len(first)
        yield first
        try:
            async for piece in agen:
                out += len(piece)
                yield piece
        except OmniError as e:
            yield f"\n\n⚠ {e.message} — {e.hint}"
        except Exception as e:  # 네트워크 끊김 등
            yield f"\n\n⚠ 응답이 중간에 끊겼습니다: {e}"
        finally:
            _log_usage(provider, chars + out)

    return StreamingResponse(body(), media_type="text/plain; charset=utf-8")


class Segment(BaseModel):
    id: int
    text: str


class SegmentsIn(BaseModel):
    segments: list[Segment] = Field(max_length=200)
    lang: str | None = None
    provider: str | None = None
    model: str | None = None


_SEG = re.compile(r"⟦(\d+)⟧\s*(.*?)(?=\s*⟦\d+⟧|\Z)", re.S)


@router.post("/translate-segments")
async def translate_segments(req: SegmentsIn) -> dict:
    """페이지 제자리 번역(AI-08)용: 표시(⟦n⟧)가 붙은 구간들을 한 번에 번역하고 구간별로 돌려준다."""
    provider, model = _resolve(req.provider, req.model)
    lang = lang_name(req.lang or _setting("ai.lang", "ko"))
    joined = "\n".join(f"⟦{s.id}⟧ {' '.join(s.text.split())}" for s in req.segments)
    system = SEGMENT_SYSTEM.format(lang=lang)
    messages = [{"role": "user", "content": f"Translate into {lang}.\n\n{joined}"}]
    chars = len(system) + len(joined)
    _check_budget(chars)
    out = "".join([p async for p in stream_chat(provider, model, system, messages)])
    _log_usage(provider, chars + len(out))
    result = {int(n): t.strip() for n, t in _SEG.findall(out) if t.strip()}
    return {"translations": result, "missing": [s.id for s in req.segments if s.id not in result]}
