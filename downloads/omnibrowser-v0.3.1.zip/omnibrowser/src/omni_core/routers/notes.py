"""메모 (LRN-03): 페이지별 메모, AI 결과 저장, 전체 Markdown 내보내기"""
from fastapi import APIRouter
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

from ..db.connection import connect
from .common import new_id, now_ms

router = APIRouter(tags=["notes"])


class NoteIn(BaseModel):
    url: str
    body: str = Field(min_length=1)
    quote: str | None = None
    title: str | None = None  # 페이지 제목 (selector 칸에 함께 저장)


@router.get("")
def list_notes(url: str | None = None, q: str | None = None, limit: int = 200) -> list[dict]:
    sql = "SELECT id, url, quote, body, selector AS title, created_at FROM notes WHERE deleted = 0"
    args: list = []
    if url:
        sql += " AND url = ?"
        args.append(url)
    if q:
        sql += " AND (body LIKE ? OR quote LIKE ? OR selector LIKE ?)"
        args += [f"%{q}%"] * 3
    sql += " ORDER BY created_at DESC LIMIT ?"
    with connect() as con:
        return [dict(r) for r in con.execute(sql, (*args, limit)).fetchall()]


@router.post("")
def add(n: NoteIn) -> dict:
    t = now_ms()
    nid = new_id()
    with connect() as con:
        con.execute(
            """INSERT INTO notes (id, kind, url, quote, body, selector, created_at, updated_at)
               VALUES (?, 'note', ?, ?, ?, ?, ?, ?)""",
            (nid, n.url, n.quote, n.body, n.title, t, t),
        )
    return {"id": nid}


@router.delete("/{note_id}")
def delete(note_id: str) -> dict:
    with connect() as con:
        con.execute("UPDATE notes SET deleted = 1, updated_at = ? WHERE id = ?", (now_ms(), note_id))
    return {"ok": True}


@router.get("/export", response_class=PlainTextResponse)
def export() -> str:
    """모든 메모를 페이지별로 묶은 Markdown"""
    import time

    rows = list_notes(limit=100_000)
    out = ["# OmniBrowser 메모 모음\n"]
    by_url: dict[str, list[dict]] = {}
    for r in rows:
        by_url.setdefault(r["url"], []).append(r)
    for url, items in by_url.items():
        out.append(f"\n## {items[0]['title'] or url}\n\n원본: {url}\n")
        for r in items:
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(r["created_at"] / 1000))
            if r["quote"]:
                out.append(f"> {r['quote']}\n")
            out.append(f"{r['body']}\n\n*{when}*\n")
    return "\n".join(out)
