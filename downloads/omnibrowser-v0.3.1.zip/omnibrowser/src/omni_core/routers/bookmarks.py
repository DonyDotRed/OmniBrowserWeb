"""북마크 (Phase 1: 폴더 없이 목록형. parent_id로 폴더 확장 가능)"""
from fastapi import APIRouter
from pydantic import BaseModel

from ..db.connection import connect
from ..errors import OmniError
from .common import new_id, now_ms

router = APIRouter(tags=["bookmarks"])


class BookmarkIn(BaseModel):
    title: str
    url: str
    parent_id: str | None = None


@router.get("")
def list_bookmarks() -> list[dict]:
    with connect() as con:
        rows = con.execute(
            """SELECT id, parent_id, kind, title, url, position FROM bookmarks
               WHERE deleted = 0 ORDER BY position, updated_at"""
        ).fetchall()
    return [dict(r) for r in rows]


@router.post("")
def add_bookmark(b: BookmarkIn) -> dict:
    t = now_ms()
    with connect() as con:
        exists = con.execute(
            "SELECT id FROM bookmarks WHERE url = ? AND deleted = 0", (b.url,)
        ).fetchone()
        if exists:  # 같은 주소는 한 번만
            return {"id": exists["id"], "created": False}
        pos = con.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM bookmarks").fetchone()[0]
        bid = new_id()
        con.execute(
            """INSERT INTO bookmarks (id, parent_id, kind, title, url, position, updated_at)
               VALUES (?, ?, 'link', ?, ?, ?, ?)""",
            (bid, b.parent_id, b.title or b.url, b.url, pos, t),
        )
    return {"id": bid, "created": True}


@router.delete("/{bookmark_id}")
def delete_bookmark(bookmark_id: str) -> dict:
    with connect() as con:
        cur = con.execute(
            "UPDATE bookmarks SET deleted = 1, updated_at = ? WHERE id = ? AND deleted = 0",
            (now_ms(), bookmark_id),
        )
    if cur.rowcount == 0:
        raise OmniError("BOOKMARK_NOT_FOUND", "북마크를 찾을 수 없습니다.", "목록을 새로고침하세요.", 404)
    return {"ok": True}
