"""크롤러 API: 작업 시작·상태·선택 다운로드·중지 (작업은 Core 안에서 백그라운드 실행)"""
import asyncio
from pathlib import Path

from fastapi import APIRouter
from pydantic import BaseModel, Field, field_validator

from ..errors import OmniError
from ..services.crawler.engine import FILE_TYPES, CrawlJob, CrawlOptions, extract_markdown

router = APIRouter(tags=["crawl"])
JOBS: dict[str, CrawlJob] = {}
TASKS: set[asyncio.Task] = set()  # 태스크가 가비지 컬렉션되지 않게 보관


class CrawlIn(BaseModel):
    start_url: str
    scope: str = Field("subpath", pattern="^(page|subpath|domain)$")
    max_depth: int = Field(2, ge=0, le=10)
    max_pages: int = Field(200, ge=1, le=5000)
    page_formats: list[str] = ["md"]
    file_types: list[str] = ["pdf", "hwp", "word", "excel", "ppt"]
    custom_exts: list[str] = []
    mode: str = Field("run", pattern="^(scan|run)$")
    output_dir: str
    cookies: str = ""
    user_agent: str = "Mozilla/5.0"
    respect_robots: bool = True
    delay_ms: int = Field(300, ge=0, le=10_000)
    concurrency: int = Field(4, ge=1, le=16)
    max_file_mb: int = Field(300, ge=1)
    max_total_mb: int = Field(5000, ge=1)
    include: str = ""
    exclude: str = ""
    make_zip: bool = False
    fetch_via: str = ""
    fetch_token: str = ""

    @field_validator("start_url")
    @classmethod
    def http_only(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")):
            raise ValueError("http(s) 주소만 크롤링할 수 있습니다")
        return v


def _spawn(coro) -> None:
    task = asyncio.create_task(coro)
    TASKS.add(task)
    task.add_done_callback(TASKS.discard)


@router.get("/file-types")
def file_types() -> dict[str, list[str]]:
    return FILE_TYPES


@router.post("/start")
async def start(body: CrawlIn) -> dict:
    running = [j for j in JOBS.values() if j.state in ("running", "downloading")]
    if len(running) >= 3:
        raise OmniError("CRAWL_BUSY", "동시에 3개까지 실행할 수 있습니다.", "진행 중인 작업이 끝나거나 중지한 뒤 다시 시도하세요.", 429)
    opts = CrawlOptions(**body.model_dump())
    job = CrawlJob(opts, Path(body.output_dir))
    JOBS[job.id] = job
    _spawn(job.run())
    return job.status()


@router.get("/jobs")
def jobs() -> list[dict]:
    return [j.status() for j in sorted(JOBS.values(), key=lambda j: -j.started)]


def _job(job_id: str) -> CrawlJob:
    job = JOBS.get(job_id)
    if not job:
        raise OmniError("CRAWL_NOT_FOUND", "작업을 찾을 수 없습니다.", "앱을 다시 시작하면 이전 작업 목록은 사라집니다.", 404)
    return job


@router.get("/{job_id}")
def status(job_id: str, files: bool = False) -> dict:
    return _job(job_id).status(with_files=files)


@router.get("/{job_id}/pages")
def pages(job_id: str) -> list[dict]:
    """방문한 페이지 목록 (브라우저 PDF 저장 등에 사용)"""
    return [{"url": p["url"], "title": p["title"], "depth": p["depth"]} for p in _job(job_id).pages]


class SelectIn(BaseModel):
    urls: list[str]


@router.post("/{job_id}/download")
async def download(job_id: str, body: SelectIn) -> dict:
    job = _job(job_id)
    if job.state in ("running", "downloading"):
        raise OmniError("CRAWL_BUSY", "작업이 아직 진행 중입니다.")
    _spawn(job.download_selected(body.urls))
    return {"ok": True}


@router.post("/{job_id}/cancel")
def cancel(job_id: str) -> dict:
    _job(job_id).cancel()
    return {"ok": True}


class HtmlIn(BaseModel):
    html: str
    url: str = ""


@router.post("/to-markdown")
def to_markdown(body: HtmlIn) -> dict:
    """현재 페이지를 Markdown으로 저장·복사할 때 사용"""
    md, txt = extract_markdown(body.html, body.url)
    return {"markdown": md, "text": txt}
