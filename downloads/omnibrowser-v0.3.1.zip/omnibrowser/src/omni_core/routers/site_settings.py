"""사이트별 설정. 예) https://www.youtube.com 의 media.rate = 1.75

origin에는 "https://..."처럼 슬래시가 들어가므로 쿼리 문자열(?origin=)로 받는다.
workspace_id가 없으면(NULL) 모든 워크스페이스 공통 설정.
"""
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from ..db.connection import connect
from .common import dumps, loads, now_ms

router = APIRouter(tags=["site-settings"])


class SiteValueIn(BaseModel):
    origin: str
    key: str
    value: Any
    workspace_id: str | None = None


@router.get("")
def get_site(origin: str, workspace_id: str | None = None) -> dict[str, Any]:
    """공통 설정 위에 워크스페이스 전용 설정을 덮어써서 돌려준다."""
    with connect() as con:
        rows = con.execute(
            """SELECT key, value_json, workspace_id FROM site_settings
               WHERE origin = ? AND deleted = 0 AND (workspace_id IS NULL OR workspace_id = ?)
               ORDER BY workspace_id IS NOT NULL""",  # 공통(NULL) 먼저, 전용이 나중에 덮어씀
            (origin, workspace_id),
        ).fetchall()
    return {r["key"]: loads(r["value_json"]) for r in rows}


@router.put("")
def put_site(body: SiteValueIn) -> dict:
    with connect() as con:
        # workspace_id가 NULL일 수 있어 ON CONFLICT 대신 "지우고 넣기"
        con.execute(
            "DELETE FROM site_settings WHERE origin = ? AND key = ? AND workspace_id IS ?",
            (body.origin, body.key, body.workspace_id),
        )
        con.execute(
            """INSERT INTO site_settings (origin, workspace_id, key, value_json, updated_at)
               VALUES (?, ?, ?, ?, ?)""",
            (body.origin, body.workspace_id, body.key, dumps(body.value), now_ms()),
        )
    return {"ok": True}


@router.get("/all")
def list_all() -> list[dict]:
    """설정 화면의 '사이트별 설정 모아보기'용"""
    with connect() as con:
        rows = con.execute(
            """SELECT origin, workspace_id, key, value_json, updated_at FROM site_settings
               WHERE deleted = 0 ORDER BY origin, key"""
        ).fetchall()
    return [{**dict(r), "value": loads(r["value_json"])} for r in rows]


@router.delete("")
def delete_site(origin: str, key: str | None = None) -> dict:
    with connect() as con:
        if key:
            con.execute("DELETE FROM site_settings WHERE origin = ? AND key = ?", (origin, key))
        else:
            con.execute("DELETE FROM site_settings WHERE origin = ?", (origin,))
    return {"ok": True}
