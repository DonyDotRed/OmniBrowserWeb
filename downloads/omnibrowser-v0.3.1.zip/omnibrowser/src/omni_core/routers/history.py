import time
import uuid

from fastapi import APIRouter, Query
from pydantic import BaseModel

from ..db.connection import connect

router = APIRouter(tags=["history"])


class VisitIn(BaseModel):
    workspace_id: str = "default"
    url: str
    title: str = ""


def now_ms() -> int:
    return int(time.time() * 1000)


@router.post("")
def add_visit(v: VisitIn) -> dict:
    t = now_ms()
    with connect() as con:
        con.execute(
            """INSERT INTO history (id, workspace_id, url, title, last_visit, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(workspace_id, url) DO UPDATE SET
                 title = excluded.title, visit_count = visit_count + 1,
                 last_visit = excluded.last_visit, updated_at = excluded.updated_at, deleted = 0""",
            (uuid.uuid4().hex, v.workspace_id, v.url, v.title, t, t),
        )
    return {"ok": True}


@router.get("")
def search(q: str = "", workspace_id: str | None = None,
           limit: int = Query(50, ge=1, le=500)) -> list[dict]:
    sql = "SELECT h.url, h.title, h.visit_count, h.last_visit FROM history h"
    where: list[str] = ["h.deleted = 0"]
    params: list = []
    if len(q) >= 3:                                        # trigram FTS: 3글자 이상
        sql += " JOIN history_fts ON history_fts.rowid = h.rowid"
        where.append("history_fts MATCH ?")
        params.append('"' + q.replace('"', '""') + '"')    # 특수문자로 인한 구문 오류 방지
    elif q:                                                # 1~2글자: LIKE
        where.append("(h.title LIKE ? OR h.url LIKE ?)")
        params += [f"%{q}%", f"%{q}%"]
    if workspace_id:
        where.append("h.workspace_id = ?")
        params.append(workspace_id)
    sql += " WHERE " + " AND ".join(where) + " ORDER BY h.last_visit DESC LIMIT ?"
    params.append(limit)
    with connect() as con:
        return [dict(r) for r in con.execute(sql, params)]


@router.delete("")
def delete_range(from_ms: int = 0, to_ms: int | None = None) -> dict:
    """기간별 기록 삭제 (from_ms~to_ms, 밀리초). 인자가 없으면 전체 삭제."""
    with connect() as con:
        cur = con.execute(
            "DELETE FROM history WHERE last_visit >= ? AND last_visit <= ?",
            (from_ms, to_ms if to_ms is not None else now_ms()),
        )
    return {"deleted": cur.rowcount}
