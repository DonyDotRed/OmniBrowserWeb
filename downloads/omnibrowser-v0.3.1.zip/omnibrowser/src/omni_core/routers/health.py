from fastapi import APIRouter, Depends

from .. import __version__
from ..security import require_token
from ..watchdog import beat

router = APIRouter(tags=["health"])


@router.get("/health")
def health() -> dict:
    return {"status": "ok", "version": __version__, "db_mode": "local"}


@router.post("/health/heartbeat", dependencies=[Depends(require_token)])
def heartbeat() -> dict:
    beat()
    return {"ok": True}
