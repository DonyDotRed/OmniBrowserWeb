"""전역 설정: key → JSON 값. 예) tts.provider = "supertonic" """
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from ..db.connection import connect
from .common import dumps, loads, now_ms

router = APIRouter(tags=["settings"])

# 저장된 값이 없을 때 쓰는 기본값 (UI는 항상 이 키들을 받는다)
DEFAULTS: dict[str, Any] = {
    "tts.provider": "supertonic",  # supertonic | openai | gemini
    "tts.voice": "",  # (v0.1 호환) 엔진별 음성은 아래 tts.voice.<엔진>
    "tts.voice.supertonic": "M1",
    "tts.voice.openai": "alloy",
    "tts.voice.gemini": "Kore",
    "tts.openai.model": "gpt-4o-mini-tts",
    "tts.gemini.model": "gemini-3.1-flash-tts-preview",
    "tts.gemini.style": "",  # 예: "차분하고 또박또박 읽어 주세요"
    "tts.local.model": "supertonic-3",
    "tts.local.model_dir": "",  # 비우면 OmniBrowser 전용 폴더 (데이터 폴더/models/<모델>)
    "tts.local.auto_download": True,
    "tts.lang": "ko",
    "tts.rate": 1.0,
    "media.favorite_rate": 1.5,
    "start.url": "https://www.google.com",
    # AI
    "ai.provider": "gemini",  # gemini | openai | anthropic
    "ai.model.openai": "",  # 비우면 기본 모델
    "ai.model.anthropic": "",
    "ai.model.gemini": "",
    "ai.lang": "ko",  # 번역·요약 결과 언어
    "ai.monthly_char_limit": 3_000_000,  # 월 사용 한도(글자 수, 0 = 무제한)
    "ai.max_input_chars": 60_000,  # 한 번에 보낼 최대 글자 수
    "ai.translate_max_segments": 400,
    "ai.models_auto_refresh": True,  # 하루 한 번 모델 목록 자동 갱신
    "ai.auto_latest": True,  # 모델 칸이 비어 있고 기본 모델이 사라졌으면 추천 최신 모델 사용  # 페이지 번역 시 최대 구간 수 (비용 가드)
    # 브라우저
    "browser.user_agent": "chrome",  # chrome | edge | custom | electron (사이트 호환성)
    "browser.user_agent_custom": "",  # custom일 때 사용할 UA 문자열
    "browser.block_detect": True,  # "Web Page Blocked" 같은 차단 화면 자동 감지 안내
    "privacy.adblock": False,
    "reader.font_size": 19,
    # 크롤러
    "crawl.output_dir": "",  # 비우면 다운로드 폴더 안의 OmniBrowser
    "crawl.respect_robots": True,
}


class ValueIn(BaseModel):
    value: Any


@router.get("")
def get_all() -> dict[str, Any]:
    with connect() as con:
        saved = {
            r["key"]: loads(r["value_json"])
            for r in con.execute("SELECT key, value_json FROM settings WHERE key NOT LIKE 'cache.%'")
        }  # cache.* 는 내부 캐시(모델 목록 등) → 설정 화면에 보내지 않음
    return {**DEFAULTS, **saved}


@router.put("/{key}")
def put(key: str, body: ValueIn) -> dict:
    with connect() as con:
        con.execute(
            """INSERT INTO settings (key, value_json, updated_at) VALUES (?, ?, ?)
               ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json,
                                              updated_at = excluded.updated_at""",
            (key, dumps(body.value), now_ms()),
        )
    return {"ok": True}
