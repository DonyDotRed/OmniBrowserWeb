"""라우터 공용 도우미."""
import json
import time
import uuid
from typing import Any


def now_ms() -> int:
    return int(time.time() * 1000)


def new_id() -> str:
    return uuid.uuid4().hex


def dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


def loads(text: str) -> Any:
    return json.loads(text)
