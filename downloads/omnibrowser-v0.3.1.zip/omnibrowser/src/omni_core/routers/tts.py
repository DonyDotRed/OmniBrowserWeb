import hashlib
import sqlite3
import time
import uuid
from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ..config import get_settings
from ..db.connection import connect
from ..errors import OmniError
from ..prefs import get_setting
from ..services.tts import supertonic_local as local
from ..services.tts.gemini_tts import VOICES as GEMINI_VOICES
from ..services.tts.gemini_tts import GeminiTTS
from ..services.tts.openai_tts import VOICES as OPENAI_VOICES
from ..services.tts.openai_tts import OpenAITTS
from ..services.tts.splitter import split_sentences

router = APIRouter(tags=["tts"])
SUPERTONIC = local.SupertonicTTS()
PROVIDERS = {p.name: p for p in (SUPERTONIC, OpenAITTS(), GeminiTTS())}
LABELS = {"supertonic": "Supertonic 3 (로컬·무료·오프라인)", "openai": "OpenAI TTS (클라우드)", "gemini": "Google Gemini TTS (클라우드)"}


class TTSRequest(BaseModel):
    provider: str = "supertonic"
    voice: str = ""
    lang: str = "ko"
    text: str = Field(min_length=1, max_length=2000)       # 긴 글은 문장 단위로 나눠 요청


def _trim_cache(con: sqlite3.Connection) -> None:
    """캐시가 설정 용량(tts_cache_limit_mb)을 넘으면 가장 오래 안 쓴 파일부터 삭제."""
    limit = get_settings().tts_cache_limit_mb * 1024 * 1024
    total = con.execute("SELECT COALESCE(SUM(bytes), 0) FROM tts_cache").fetchone()[0]
    if total <= limit:
        return
    for row in con.execute("SELECT cache_key, file_path, bytes FROM tts_cache ORDER BY last_used_at").fetchall():
        Path(row["file_path"]).unlink(missing_ok=True)
        con.execute("DELETE FROM tts_cache WHERE cache_key = ?", (row["cache_key"],))
        total -= row["bytes"]
        if total <= limit:
            break


@router.post("/synthesize")
async def synthesize(req: TTSRequest) -> FileResponse:
    p = PROVIDERS.get(req.provider)
    if p is None:
        raise OmniError("TTS_UNKNOWN_PROVIDER", f"알 수 없는 TTS 엔진: {req.provider}")
    voice = req.voice or get_setting(f"tts.voice.{p.name}") or ""
    # 모델·스타일·모델 폴더가 바뀌면 다른 소리이므로 캐시 키에 포함
    key = hashlib.sha256(f"{p.name}|{p.tag()}|{voice}|{req.lang}|{req.text}".encode()).hexdigest()
    out = get_settings().cache_dir / f"{key}.{p.ext}"
    now = int(time.time() * 1000)
    if not out.exists():                                    # 캐시에 없을 때만 합성 (= 비용 발생)
        tmp = out.with_name(f"{key}.tmp.{p.ext}")           # 실패 시 깨진 파일이 캐시에 남지 않도록
        await p.synthesize(req.text, voice, req.lang, tmp)
        tmp.replace(out)
        with connect() as con:
            con.execute("INSERT OR REPLACE INTO tts_cache VALUES (?, ?, ?, ?, ?, ?, ?)",
                        (key, p.name, str(out), len(req.text), out.stat().st_size, now, now))
            if p.name != "supertonic":                          # 클라우드 엔진: 사용량 기록 (TTS-08)
                con.execute(
                    """INSERT INTO api_usage (id, provider, kind, units, created_at, updated_at)
                       VALUES (?, ?, 'tts', ?, ?, ?)""",
                    (uuid.uuid4().hex, p.name, len(req.text), now, now),
                )
            _trim_cache(con)
    else:
        with connect() as con:
            con.execute("UPDATE tts_cache SET last_used_at = ? WHERE cache_key = ?", (now, key))
    return FileResponse(out, media_type=p.media_type)


class SplitIn(BaseModel):
    text: str = Field(min_length=1, max_length=200_000)


@router.post("/split")
def split(body: SplitIn) -> dict:
    """긴 글을 문장 목록으로 나눈다. UI는 문장마다 /synthesize를 호출해 이어서 재생."""
    return {"sentences": split_sentences(body.text)}


@router.get("/providers")
def providers() -> list[dict]:
    return [{"name": name, "label": LABELS[name], "local": name == "supertonic"} for name in PROVIDERS]


@router.get("/voices")
def voices(provider: str) -> list[str]:
    if provider == "openai":
        return OPENAI_VOICES
    if provider == "gemini":
        return GEMINI_VOICES
    return local.status().get("voices", local.DEFAULT_VOICES)


@router.get("/models")
async def models(provider: str, refresh: bool = False) -> dict:
    """클라우드 TTS 모델 목록 (AI 모델 목록과 같은 캐시·갱신 방식)"""
    from .ai import models_for

    return await models_for(provider, "tts", refresh)


# ───────── 로컬 모델(Supertonic) 폴더 관리 ─────────
@router.get("/local/status")
def local_status(model: str | None = None, dir: str | None = None) -> dict:
    """dir를 주면 그 폴더를 검사(저장 전 미리 확인), 없으면 현재 설정 기준"""
    return local.status(model, dir)


class LocalIn(BaseModel):
    model: str | None = None
    dir: str | None = None


@router.post("/local/download")
def local_download(body: LocalIn) -> dict:
    local.start_download(body.model, body.dir)
    return local.status(body.model, body.dir)


@router.post("/local/copy")
def local_copy(body: LocalIn) -> dict:
    local.start_copy(body.dir or "")
    return {"ok": True}


@router.post("/local/reload")
def local_reload() -> dict:
    """설정에서 모델·폴더를 바꾼 뒤 엔진을 다시 불러오도록"""
    SUPERTONIC.reset()
    return local.status()
