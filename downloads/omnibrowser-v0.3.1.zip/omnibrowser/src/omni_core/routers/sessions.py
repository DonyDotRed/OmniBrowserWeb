"""세션 스냅샷: 열린 탭·워크스페이스 상태를 저장했다가 다음 실행 때 복원 (TAB-05)"""
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from ..db.connection import connect
from .common import dumps, loads, now_ms

router = APIRouter(tags=["sessions"])
KEEP = 20  # 최근 20개만 보관 (복구용)


class SessionIn(BaseModel):
    reason: str = "auto"  # auto | quit | manual
    payload: dict[str, Any]


@router.get("/latest")
def latest() -> dict | None:
    with connect() as con:
        r = con.execute(
            "SELECT created_at, reason, payload FROM session_snapshots ORDER BY id DESC LIMIT 1"
        ).fetchone()
    if r is None:
        return None
    return {"created_at": r["created_at"], "reason": r["reason"], "payload": loads(r["payload"])}


@router.put("/latest")
def save(s: SessionIn) -> dict:
    with connect() as con:
        con.execute(
            "INSERT INTO session_snapshots (created_at, reason, payload) VALUES (?, ?, ?)",
            (now_ms(), s.reason, dumps(s.payload)),
        )
        con.execute(
            """DELETE FROM session_snapshots WHERE id NOT IN
               (SELECT id FROM session_snapshots ORDER BY id DESC LIMIT ?)""",
            (KEEP,),
        )
    return {"ok": True}
