"""API 키 관리: 원문은 OS 키체인에만. 조회 시에는 마스킹된 값만 돌려준다."""
from fastapi import APIRouter
from pydantic import BaseModel, Field

from .. import secrets_store
from ..errors import OmniError

router = APIRouter(tags=["secrets"])
ALLOWED = {"openai", "anthropic", "gemini", "elevenlabs"}


class SecretIn(BaseModel):
    value: str = Field(min_length=8, max_length=400)


def _check(name: str) -> None:
    if name not in ALLOWED:
        raise OmniError("SECRET_UNKNOWN", f"알 수 없는 키 이름: {name}", f"사용 가능: {sorted(ALLOWED)}")


@router.get("/{name}")
def get(name: str) -> dict:
    _check(name)
    masked = secrets_store.masked(name)
    return {"name": name, "exists": masked is not None, "masked": masked}


@router.put("/{name}")
def put(name: str, body: SecretIn) -> dict:
    _check(name)
    secrets_store.set_secret(name, body.value.strip())
    return {"ok": True, "masked": secrets_store.masked(name)}


@router.delete("/{name}")
def delete(name: str) -> dict:
    _check(name)
    secrets_store.delete_secret(name)
    return {"ok": True}
